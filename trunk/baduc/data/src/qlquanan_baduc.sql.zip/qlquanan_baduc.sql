-- phpMyAdmin SQL Dump
-- version 4.0.8
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 27, 2013 at 09:59 AM
-- Server version: 5.1.72-cll
-- PHP Version: 5.3.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `qlquanan_baduc`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_app`
--

CREATE TABLE IF NOT EXISTS `tbl_app` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(125) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(50) CHARACTER SET utf8 NOT NULL,
  `banner` varchar(125) CHARACTER SET utf8 NOT NULL,
  `prefix` varchar(50) CHARACTER SET utf8 NOT NULL,
  `alias` varchar(256) CHARACTER SET utf8 NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_activity` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `type` tinyint(4) NOT NULL,
  `page_view` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_app`
--

INSERT INTO `tbl_app` (`id`, `name`, `phone`, `address`, `email`, `banner`, `prefix`, `alias`, `date_created`, `date_modified`, `date_activity`, `type`, `page_view`) VALUES
(1, 'Karaoke Ba Đức', '0945 03 07 09', 'Phó Cơ Điều P3 - TPVL', '', 'data/images/banner/logo.png', 'tbl_', 'tbl_', '2012-06-30 10:00:00', '0000-00-00 00:00:00', '2012-12-26 00:28:02', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

CREATE TABLE IF NOT EXISTS `tbl_category` (
  `id` int(25) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `picture` binary(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=28 ;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`id`, `name`, `picture`) VALUES
(3, 'Mực', NULL),
(8, 'Cá biển', NULL),
(11, 'BIA', NULL),
(12, 'Cá sông', NULL),
(13, 'Lẩu', NULL),
(15, 'Nghêu - sò ', NULL),
(16, 'BÒ', NULL),
(17, 'Xào', NULL),
(18, 'Rượu', NULL),
(19, 'Gỏi', NULL),
(20, 'Cơm', NULL),
(21, 'Tôm - hàu', NULL),
(22, 'Tự nhâp', NULL),
(23, 'NƯỚC GIẢI KHÁT', NULL),
(24, 'Khai Vị', NULL),
(25, 'Cua - Ghẹ', NULL),
(26, 'Gà', NULL),
(27, 'Se Sẻ', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_collect_customer`
--

CREATE TABLE IF NOT EXISTS `tbl_collect_customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idcustomer` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_customer_collect_1` (`idcustomer`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_collect_general`
--

CREATE TABLE IF NOT EXISTS `tbl_collect_general` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_term` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_collect_1` (`id_term`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

--
-- Dumping data for table `tbl_collect_general`
--

INSERT INTO `tbl_collect_general` (`id`, `id_term`, `date`, `value`, `note`) VALUES
(5, 2, '2013-05-18', 10, 'd'),
(6, 3, '2013-12-04', 10000000, 'Bổ sung tiền quỹ');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_config`
--

CREATE TABLE IF NOT EXISTS `tbl_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `param` varchar(125) COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=10 ;

--
-- Dumping data for table `tbl_config`
--

INSERT INTO `tbl_config` (`id`, `param`, `value`) VALUES
(5, 'DISCOUNT', '0'),
(6, 'ROW_PER_PAGE', '12'),
(7, 'GUEST_VISIT', '9247'),
(8, 'EVERY_5_MINUTES', '2000'),
(9, 'CATEGORY_AUTO', '22');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_course`
--

CREATE TABLE IF NOT EXISTS `tbl_course` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idcategory` int(25) DEFAULT NULL,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `shortname` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `unit` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `price1` bigint(20) NOT NULL,
  `price2` bigint(20) NOT NULL,
  `price3` bigint(20) NOT NULL,
  `price4` bigint(20) NOT NULL,
  `picture` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `prepare` int(11) NOT NULL,
  `is_discount` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `foreign_field` (`idcategory`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=387 ;

--
-- Dumping data for table `tbl_course`
--

INSERT INTO `tbl_course` (`id`, `idcategory`, `name`, `shortname`, `unit`, `price1`, `price2`, `price3`, `price4`, `picture`, `prepare`, `is_discount`) VALUES
(15, 11, 'SG special lon', 'SG lon xanh', 'Lon', 13000, 13000, 13000, 13000, '', 0, 0),
(107, 3, 'Mực hấp gừng', 'hấp gừng', 'Dĩa', 1, 1, 1, 1, '', 0, 0),
(108, 3, 'Mực chiên nước mắm', 'chiên nước mắm', 'Dĩa', 1, 1, 1, 1, '', 0, 0),
(111, 3, 'Mực Nướng Sa Tế', 'MNST', 'Kg', 1, 1, 1, 1, '', 0, 0),
(115, 11, 'SG special chai', 'SG chai xanh', 'Chai', 12000, 12000, 12000, 12000, '', 0, 0),
(116, 11, 'SG đỏ', 'SG đỏ', 'Chai', 9000, 9000, 9000, 9000, '', 0, 0),
(165, 18, 'Phú Lễ', 'Phú Lễ', 'Chai', 85000, 85000, 85000, 85000, '', 0, 0),
(166, 18, 'Volka lớn', 'Volka lớn', 'Chai', 105000, 105000, 105000, 105000, '', 0, 1),
(167, 18, 'Volka nhỏ', 'Volka nhỏ', 'Chai', 65000, 65000, 65000, 65000, '', 0, 1),
(186, 11, '333 lon', '333 lon', 'Lon', 11000, 11000, 11000, 11000, '', 0, 0),
(187, 11, '333 chai', '333 chai', 'Chai', 11000, 11000, 11000, 11000, '', 0, 0),
(188, 11, 'Heneiken chai', 'Ken chai', 'Chai', 16000, 16000, 16000, 16000, '', 0, 0),
(189, 11, 'Heneiken lon', 'Ken lon', 'Lon', 19000, 19000, 19000, 19000, '', 0, 0),
(190, 11, 'Tiger nâu', 'Tiger nâu', 'Chai', 12000, 12000, 12000, 12000, '', 0, 0),
(191, 11, 'Tiger bạc', 'Tiger bạc', 'Chai', 14000, 14000, 14000, 14000, '', 0, 0),
(243, 22, 'gà ta quay', 'gà ta quay', 'Dĩa', 100000, 100000, 100000, 100000, '', 0, 0),
(244, 23, 'Lavie 500ml', 'Lavie 500ml', 'Chai', 10000, 10000, 10000, 10000, '', 1, 1),
(245, 23, 'Pepsi', 'Pepsi', 'Lon', 12000, 12000, 12000, 12000, '', 1, 1),
(246, 23, 'Sting', 'Sting', 'Lon', 12000, 12000, 12000, 12000, '', 1, 0),
(247, 22, 'khoai mon chien', '', 'Dĩa', 25000, 25000, 25000, 25000, '', 0, 0),
(248, 24, 'Cà Tím Nướng Mỡ Hành', 'CTNMH', 'Dĩa', 0, 0, 0, 0, '', 1, 0),
(249, 24, 'Khoai Môn Chiên Nước Mắm', 'KMCNM', 'Dĩa', 0, 0, 0, 0, '', 1, 0),
(250, 24, 'Khoai Tây Chiên', 'KTC', 'Dĩa', 0, 0, 0, 0, '', 1, 0),
(251, 24, 'Đậu Hủ Non Chiên Giòn', 'ĐHNCG', 'Dĩa', 0, 0, 0, 0, '', 1, 0),
(252, 24, 'Đậu Hủ Non Hấp Cải Thìa', 'ĐHNHCT', 'Dĩa', 0, 0, 0, 0, '', 1, 0),
(253, 24, 'Chả Giò Hải Sản', 'CGHS', 'Dĩa', 0, 0, 0, 0, '', 1, 0),
(254, 24, 'Tôm Sú Rang Muối Hồng Kông', 'TSRMHK', 'Dĩa', 0, 0, 0, 0, '', 1, 0),
(255, 24, 'Tôm Lăn Bột', 'TLB', 'Dĩa', 0, 0, 0, 0, '', 1, 0),
(256, 24, 'Khô Mực Rang Tiêu', 'KMRT', 'Dĩa', 1, 1, 1, 1, '', 1, 0),
(257, 24, 'Khô Mực Chiên Giòn', 'KMCG', 'Dĩa', 1, 1, 1, 1, '', 1, 0),
(258, 24, 'Khô Mực Nướng', 'KMN', 'Dĩa', 1, 1, 1, 1, '', 1, 0),
(259, 24, 'Rau Luộc + Trứng Hồng Đào', 'RL', 'Dĩa', 1, 1, 1, 1, '', 1, 0),
(260, 24, 'Rau Muống Xào Tỏi', 'RMXT', 'Dĩa', 1, 1, 1, 1, '', 1, 0),
(261, 24, 'Rau Luộc Kho Qụet', 'RLKQ', 'Dĩa', 1, 1, 1, 1, '', 1, 0),
(262, 24, 'Cơm Cháy Kho Qụet', 'CCKQ', 'Dĩa', 1, 1, 1, 1, '', 1, 0),
(263, 24, 'Salad Hải Sản', 'SLHS', 'Dĩa', 1, 1, 1, 1, '', 1, 0),
(264, 24, 'Salad Dầu Giấm', 'SLDG', 'Dĩa', 1, 1, 1, 1, '', 1, 0),
(265, 19, 'Gỏi Mực Thái', 'GMT', 'Dĩa', 1, 1, 1, 1, '', 1, 0),
(266, 19, 'Gỏi Dưa Leo Hải Sản', 'GDLHS', 'Dĩa', 1, 1, 1, 1, '', 1, 0),
(267, 19, 'Gỏi Tôm Thái', 'GTT', 'Dĩa', 1, 1, 1, 1, '', 1, 0),
(268, 17, 'Mì Xào Hải Sản', 'MXHS', 'Dĩa', 1, 1, 1, 1, '', 1, 0),
(269, 17, 'Mì Xào Tôm', 'MXT', 'Dĩa', 1, 1, 1, 1, '', 1, 0),
(270, 20, 'Cơm Chiên Hải Sản', 'CCHS', 'Dĩa', 1, 1, 1, 1, '', 15, 0),
(271, 20, 'Cơm Chiên Trứng', 'CCT', 'Dĩa', 1, 1, 1, 1, '', 10, 0),
(272, 20, 'Cơm Xào Hải Sản', 'CXHS', 'Dĩa', 1, 1, 1, 1, '', 10, 0),
(273, 8, 'Cá Bóng Mú Đen Ăn Sống Mù Tạt', 'CBM', 'Kg', 1, 1, 1, 1, '', 1, 0),
(274, 8, 'Cá Bóng Mú Đen Nướng Muối Ớt', 'CBMNMO', 'Kg', 1, 1, 1, 1, '', 15, 0),
(275, 8, 'Cá Bóng Mú Đen Nướng Sa Tế Cay', 'CBMNST', 'Kg', 1, 1, 1, 1, '', 15, 0),
(276, 8, 'Cá Bóng Mú Đen Chưng Tương', 'CBMCT', 'Kg', 1, 1, 1, 1, '', 15, 0),
(277, 8, 'Cá Bống Mú Đen Hấp Hồng kông', 'CBMHHK', 'Kg', 1, 1, 1, 1, '', 10, 0),
(278, 8, 'Cá Bống Mú Đen Hấp Tàu Xì', 'CBMHTX', 'Kg', 1, 1, 1, 1, '', 15, 0),
(279, 8, 'Cá Bống Mú Đen Hấp Kỳ Lân', 'CBMHKL', 'Kg', 1, 1, 1, 1, '', 10, 0),
(280, 8, 'Cá Bóng Mú Đen Nấu Lẩu', 'CBMNL', 'Kg', 1, 1, 1, 1, '', 10, 0),
(281, 8, 'Cá  Tầm Ăn Sống Mù Tạt', 'CTMT', 'Kg', 1, 1, 1, 1, '', 10, 0),
(282, 8, 'Cá Tầm Nướng Muối Ớt Cay', 'CTNMO', 'Kg', 1, 1, 1, 1, '', 15, 0),
(283, 8, 'Cá Tầm Nướng Xa Tế Cay', 'CTNXT', 'Kg', 1, 1, 1, 1, '', 15, 0),
(284, 8, 'Cá Tầm Chưng Tương', 'CTCT', 'Kg', 1, 1, 1, 1, '', 10, 0),
(285, 8, 'Cá Tầm Hấp Hồng Kông-Hấp Tàu Xì', 'CTHHK', 'Kg', 1, 1, 1, 1, '', 10, 0),
(286, 8, 'Cá Tầm Hấp Kỳ Lân', 'CTHKL', 'Kg', 1, 1, 1, 1, '', 10, 0),
(287, 8, 'Cá Tầm Nấu Lẩu', 'CTNL', 'Kg', 1, 1, 1, 1, '', 10, 0),
(288, 12, 'Cá Chạch Quế Chiên Nước Mắm', 'CCQCNM', 'Kg', 1, 1, 1, 1, '', 10, 0),
(289, 12, 'Cá Chạch Quế Chiên Giòn', 'CCQCG', 'Kg', 1, 1, 1, 1, '', 10, 0),
(290, 12, 'Cá Chạch Quế Nướng Muối Ớt', 'CCQNMO', 'Kg', 1, 1, 1, 1, '', 15, 0),
(292, 12, 'Cá Chạch Quế Nướng Xa Tế Cay', 'CCQNXT', 'Kg', 1, 1, 1, 1, '', 15, 0),
(293, 12, 'Cá Chạch Quế Nướng Mọi', 'CCQNM', 'Kg', 1, 1, 1, 1, '', 15, 0),
(294, 12, 'Cá Chạch Quế Hầm Xả', 'CCQHX', 'Kg', 1, 1, 1, 1, '', 10, 0),
(295, 12, 'Cá Chạch Quế Nấu Lẩu', 'CCQNL', 'Kg', 1, 1, 1, 1, '', 10, 0),
(296, 12, 'Cá Lăn Vàng Nướng Muối Ớt', 'CLVNMO', 'Kg', 1, 1, 1, 1, '', 10, 0),
(297, 12, 'Cá Lăn Vàng Nướng Sa Tế Cay', 'CLVNST', 'Kg', 1, 1, 1, 1, '', 10, 0),
(298, 12, 'Cá Lăn Vàng Hấp Nấm', 'CLVHN', 'Kg', 1, 1, 1, 1, '', 10, 0),
(299, 12, 'Cá Lăn Vàng Nấu Lẩu', 'CLVNL', 'Kg', 1, 1, 1, 1, '', 10, 0),
(300, 12, 'Cá Chép Giòn Ăn Sống Mù tạt', 'CCGMT', 'Kg', 1, 1, 1, 1, '', 10, 0),
(301, 12, 'Cá Chép Giòn Nướng Muối Ớt', 'CCGNMO', 'Kg', 1, 1, 1, 1, '', 15, 0),
(303, 12, 'Cá Chép Giòn Nướng xa Tế Cay', 'CCGNSTC', 'Kg', 1, 1, 1, 1, '', 15, 0),
(304, 12, 'Cá Chép Giòn Chưng Tương', 'CCGCT', 'Kg', 1, 1, 1, 1, '', 10, 0),
(305, 12, 'Cá Chép Giòn Hấp Hồng Kông+Tàu Xì', 'CCGHHK', 'Kg', 1, 1, 1, 1, '', 10, 0),
(306, 12, 'Cá Chép Giòn Hấp Kỳ Lân', 'CCGHKL', 'Kg', 1, 1, 1, 1, '', 10, 0),
(307, 12, 'Cá Chép Giòn Nấu Lẩu', 'CCGNL', 'Kg', 1, 1, 1, 1, '', 10, 0),
(308, 12, 'Cá Heo Nhỏ Ăn Sống Mù Tạt', 'CHNMT', 'Kg', 1, 1, 1, 1, '', 10, 0),
(309, 12, 'Cá Heo Nhỏ Nướng Muối Ớt', 'CHNNMO', 'Kg', 1, 1, 1, 1, '', 15, 0),
(310, 12, 'Cá Heo Nhỏ Nướng Sa Tế Cay', ' CHNNSTC', 'Kg', 1, 1, 1, 1, '', 15, 0),
(311, 12, 'Cá Heo Nhỏ Chưng Tương', 'CHNCT', 'Kg', 1, 1, 1, 1, '', 10, 0),
(312, 12, 'Cá Heo Nhỏ Hấp Hồng Kông-Hấp Tàu Xì', 'CHNHHK', 'Kg', 1, 1, 1, 1, '', 10, 0),
(313, 12, 'Cá Heo Nhỏ Hấp Kỳ Lân', 'CHNHKL', 'Kg', 1, 1, 1, 1, '', 10, 0),
(314, 12, 'Cá Heo Nhỏ Nấu Lẩu', 'CHNNL', 'Kg', 1, 1, 1, 1, '', 10, 0),
(315, 8, 'Cá Hồng Biển Ăn Sống Mù Tạt', 'CHBMT', 'Kg', 1, 1, 1, 1, '', 10, 0),
(316, 8, 'Cá Hồng Biển Nướng Muối Ớt', 'CHBNMO', 'Kg', 1, 1, 1, 1, '', 15, 0),
(317, 8, 'Cá Hồng Biển Nướng Sa Tế Cay', 'CHBNST', 'Kg', 1, 1, 1, 1, '', 15, 0),
(318, 8, 'Cá Hồng Biển Chưng Tương', 'CHBCT', 'Kg', 1, 1, 1, 1, '', 10, 0),
(319, 8, 'Cá Hồng Biển Hấp Hồng Kông-Hấp Tàu Xì', 'CHBH', 'Kg', 1, 1, 1, 1, '', 10, 0),
(320, 8, 'Cá Hồng Biển Hấp Kỳ Lân', 'CHBHKL', 'Kg', 1, 1, 1, 1, '', 10, 0),
(321, 8, 'Cá Hồng Biển Nấu Lẩu', 'CHBNL', 'Kg', 1, 1, 1, 1, '', 10, 0),
(322, 8, 'Cá Bốp Nướng Muối Ớt', 'CBNMO', 'Kg', 1, 1, 1, 1, '', 15, 0),
(323, 8, 'Cá Bốp Nướng Sa Tế Cay', 'CBNST', 'Kg', 1, 1, 1, 1, '', 15, 0),
(324, 8, 'Cá Bốp Lúc Lắc', 'CBLL', 'Kg', 1, 1, 1, 1, '', 15, 0),
(325, 8, 'Cá Bốp Chưng Tương ', 'CBCT', 'Kg', 1, 1, 1, 1, '', 15, 0),
(326, 8, 'Cá Bốp Nấu Lẩu', 'CBNL', 'Kg', 1, 1, 1, 1, '', 10, 0),
(327, 8, 'Cá Cam Nướng Sa Tế', 'CCNST', 'Kg', 1, 1, 1, 1, '', 15, 0),
(328, 8, 'Cá Cam Nướng Muối Ớt', 'CCNMO', 'Kg', 1, 1, 1, 1, '', 15, 0),
(329, 8, 'Cá Cam Hấp Hành', 'CCHH', 'Kg', 1, 1, 1, 1, '', 15, 0),
(330, 8, 'Cá Sapa Nướng Muối Ớt', 'CSPNMO', 'Kg', 1, 1, 1, 1, '', 15, 0),
(331, 8, 'Cá Sapa Nướng Sa Tế Cay', 'CSPNST', 'Kg', 1, 1, 1, 1, '', 15, 0),
(332, 8, 'Cá Bò Da Nướng Muối Ớt', 'CBDNMO', 'Kg', 1, 1, 1, 1, '', 15, 0),
(333, 8, 'Cá Bò Da Nướng Sa Tế Cay', 'CBDNST', 'Kg', 1, 1, 1, 1, '', 15, 0),
(334, 21, 'Tôm Lóng Ăn Sống Mù Tạt', 'TLMT', 'Kg', 1, 1, 1, 1, '', 10, 0),
(335, 21, 'Tôm Lóng Nướng Muối Ớt', 'TNMO', 'Kg', 1, 1, 1, 1, '', 15, 0),
(336, 21, 'Tôm Lóng Nướng Sa Tế Cay', 'TNST', 'Kg', 1, 1, 1, 1, '', 10, 0),
(337, 21, 'Tôm Lóng Hấp Bia- Hấp Nước Dừa', 'THB', 'Kg', 1, 1, 1, 1, '', 10, 0),
(338, 21, 'Tôm Đất Ăn Sống Mù Tạt', 'TMT', 'Kg', 1, 1, 1, 1, '', 5, 0),
(339, 21, 'Tôm Đất Nướng Muối Ớt', 'TDNMO', 'Kg', 1, 1, 1, 1, '', 10, 0),
(340, 21, 'Tôm Đất Hấp Bia-Hấp Nước Dừa', 'TDH', 'Kg', 1, 1, 1, 1, '', 10, 0),
(341, 25, 'Cua Rang Muối', 'CRM', 'Kg', 1, 1, 1, 1, '', 10, 0),
(342, 25, 'Cua Hấp Bia ', 'CHB', 'Kg', 1, 1, 1, 1, '', 5, 0),
(343, 25, 'Cua Hấp Nước Dừa', 'CHND', 'Kg', 1, 1, 1, 1, '', 5, 0),
(344, 25, 'Cua Luộc', 'CL', 'Kg', 1, 1, 1, 1, '', 5, 0),
(345, 25, 'Cua Nấu Lẩu', 'CNL', 'Kg', 1, 1, 1, 1, '', 4, 0),
(346, 25, 'Ghẹ Rang Muối', 'GRM', 'Kg', 1, 1, 1, 1, '', 3, 0),
(347, 25, 'Ghẹ Hấp Bia', 'GHB', 'Kg', 1, 1, 1, 1, '', 5, 0),
(348, 25, 'Ghẹ Hấp Nước Dừa', 'GHND', 'Kg', 1, 1, 1, 1, '', 5, 0),
(349, 25, 'Ghẹ Luộc', 'GL', 'Kg', 1, 1, 1, 1, '', 5, 0),
(350, 25, 'Ghẹ Nấu Lẩu', 'GNL', 'Kg', 1, 1, 1, 1, '', 5, 0),
(351, 15, 'Sò Huyết Rang Muối', 'SHRM', 'Kg', 1, 1, 1, 1, '', 5, 0),
(352, 15, 'Sò Huyết Rang Muối Hồng Kông', 'SHRMHK', 'Kg', 1, 1, 1, 1, '', 5, 0),
(353, 15, 'Sò Huyết Rang Me ', 'SHRM', 'Kg', 1, 1, 1, 1, '', 5, 0),
(354, 15, 'Sò Huyết Cháy Tỏi', 'SHCT', 'Kg', 1, 1, 1, 1, '', 5, 0),
(355, 15, 'Sò Huyết Lacost', 'SHLC', 'Kg', 1, 1, 1, 1, '', 5, 0),
(356, 15, 'Sò Huyết Tứ Xuyên', 'SGTX', 'Kg', 1, 1, 1, 1, '', 5, 0),
(357, 15, 'Sò Huyết Xào Rau Râm', 'SHXRR', 'Kg', 1, 1, 1, 1, '', 5, 0),
(358, 15, 'Sò Huyết Nướng Mọi', 'SHNM', 'Kg', 1, 1, 1, 1, '', 5, 0),
(359, 15, 'Nghêu Hấp Gừng', 'NHG', 'Kg', 1, 1, 1, 1, '', 1, 0),
(360, 15, 'Nghêu Hấp Thái', 'NHT', 'Kg', 1, 1, 1, 1, '', 1, 0),
(361, 21, 'Hàu Sữa Nướng Mỡ Hành', 'HSNMH', 'Con', 1, 1, 1, 1, '', 10, 0),
(362, 21, 'Hàu Sữa Ăn Sống Mù Tạt', 'HSMT', 'Con', 1, 1, 1, 1, '', 1, 0),
(363, 21, 'Hàu Sữa Nướng Phô Mai', 'HSNPM', 'Con', 1, 1, 1, 1, '', 1, 0),
(364, 21, 'Hàu Sữa Nướng Trứng Cúc', 'HSNTC', 'Con', 1, 1, 1, 1, '', 10, 0),
(365, 26, 'Gà Hấp Bia', 'GHB', 'Dĩa', 1, 1, 1, 1, '', 5, 0),
(366, 26, 'Gà Hấp Cải Thìa', 'GHCT', 'Dĩa', 1, 1, 1, 1, '', 5, 0),
(367, 26, 'Gà Nướng Muối Ớt', 'GNMO', 'Dĩa', 1, 1, 1, 1, '', 15, 0),
(368, 26, 'Cánh Gà Chiên Nước Mắm', 'CGCNM', 'Dĩa', 1, 1, 1, 1, '', 5, 0),
(369, 26, 'Chân Gà Chiên Nước Mắm', 'CGCNM', 'Dĩa', 1, 1, 1, 1, '', 5, 0),
(370, 13, 'Lẩu Gà Chanh ỚT', 'LGCO', 'Cái', 1, 1, 1, 1, '', 5, 0),
(371, 13, 'Lẩu Gà Lá Giang', 'LGLG', 'Cái', 1, 1, 1, 1, '', 5, 0),
(372, 16, 'Bò Lúc Lắc', 'BLL', 'Dĩa', 1, 1, 1, 1, '', 3, 0),
(373, 16, 'Bò Xào Chua Ngọt', 'BXCN', 'Dĩa', 1, 1, 1, 1, '', 5, 0),
(374, 16, 'Bò Xào Củ Hành', 'BXCH', 'Dĩa', 1, 1, 1, 1, '', 5, 0),
(375, 16, 'Bò Xào Khổ Qua', 'BXKQ', 'Dĩa', 1, 1, 1, 1, '', 5, 0),
(376, 16, 'Bò Tái Chanh', 'BTC', 'Dĩa', 1, 1, 1, 1, '', 3, 0),
(377, 16, 'Bò Nướng Muối Ớt', 'BNMO', 'Dĩa', 1, 1, 1, 1, '', 5, 0),
(378, 16, 'Bò Nướng Sa Tế', 'BNST', 'Dĩa', 1, 1, 1, 1, '', 5, 0),
(379, 16, 'Bò Né', 'BN1', 'Dĩa', 1, 1, 1, 1, '', 3, 0),
(380, 16, 'Bò Bốp Thấu', 'BBT', 'Dĩa', 1, 1, 1, 1, '', 5, 0),
(381, 3, 'Mực Nướng Muối Ớt', 'MNMO', 'Kg', 1, 1, 1, 1, '', 0, 0),
(382, 3, 'Mực Chiên Giòn', 'MCG', 'Kg', 1, 1, 1, 1, '', 0, 0),
(383, 17, 'Mực Xào Chua Ngọt', 'MXCN', 'Dĩa', 1, 1, 1, 1, '', 0, 0),
(384, 27, 'Se Sẻ Nướng Muối Ớt', 'SSN', 'Dĩa', 1, 1, 1, 1, '', 0, 0),
(385, 27, 'Se Sẻ Rôti', 'rôti', 'Dĩa', 1, 1, 1, 1, '', 0, 0),
(386, 27, 'Se Sẻ Nướng Sa Tế', 'Nướng Sa tế', 'Dĩa', 1, 1, 1, 1, '', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_course_log`
--

CREATE TABLE IF NOT EXISTS `tbl_course_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_table` int(11) NOT NULL,
  `id_course` int(11) NOT NULL,
  `date_time` datetime NOT NULL,
  `count` int(11) NOT NULL,
  `state` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `tbl_course_log`
--

INSERT INTO `tbl_course_log` (`id`, `id_table`, `id_course`, `date_time`, `count`, `state`) VALUES
(7, 1, 333, '2013-12-25 18:51:26', 1, 0),
(8, 1, 333, '2013-12-25 18:51:28', 1, 0),
(9, 1, 276, '2013-12-25 18:51:31', 1, 0),
(10, 1, 279, '2013-12-25 18:51:37', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_customer`
--

CREATE TABLE IF NOT EXISTS `tbl_customer` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  `card` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `discount` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=14 ;

--
-- Dumping data for table `tbl_customer`
--

INSERT INTO `tbl_customer` (`id`, `name`, `type`, `card`, `phone`, `address`, `note`, `discount`) VALUES
(1, 'KHÁCH VÃNG LAI', 0, '1', '', '', '', 0),
(12, 'Khách VIP1', 1, 'vip1', '0919 111 222', 'Vĩnh Long', '', 5),
(13, 'Khách VIP2', 1, 'vip2', '0949 959997', 'Đồng Tháp', '', 10);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_domain`
--

CREATE TABLE IF NOT EXISTS `tbl_domain` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Dumping data for table `tbl_domain`
--

INSERT INTO `tbl_domain` (`id`, `name`) VALUES
(1, 'PHÒNG LẠNH'),
(2, 'NHÀ TUM'),
(3, 'KHU NGOÀI TRỜI'),
(4, 'KHU HỘI TRƯỜNG');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_employee`
--

CREATE TABLE IF NOT EXISTS `tbl_employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `job` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `gender` tinyint(2) NOT NULL,
  `phone` varchar(13) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `salary_base` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Dumping data for table `tbl_employee`
--

INSERT INTO `tbl_employee` (`id`, `name`, `job`, `gender`, `phone`, `address`, `salary_base`) VALUES
(1, 'Nguyễn Văn A', 'Bảo vệ', 0, '0946 111 222', 'P4 - Vĩnh Long', 2000000),
(2, 'Nguyễn Văn B', 'Phục vụ', 0, '0932502838', 'Châu Thành, Đồng Tháp', 3000000),
(3, 'Nguyễn Văn C', 'Phục vụ', 0, '0', 'Sóc Trăng', 0),
(4, 'Nguyễn Văn D', 'Phục vụ', 1, '', 'Châu Thành, Đồng Tháp', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_guest`
--

CREATE TABLE IF NOT EXISTS `tbl_guest` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(16) CHARACTER SET latin1 NOT NULL,
  `entry_time` varchar(32) CHARACTER SET latin1 NOT NULL,
  `exit_time` varchar(32) CHARACTER SET latin1 NOT NULL,
  `agent` varchar(16) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=150 ;

--
-- Dumping data for table `tbl_guest`
--

INSERT INTO `tbl_guest` (`id`, `ip`, `entry_time`, `exit_time`, `agent`) VALUES
(149, '115.78.94.118', '1383319305', '1383322905', '115.78.94.118');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_notify`
--

CREATE TABLE IF NOT EXISTS `tbl_notify` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  `message` varchar(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order_import`
--

CREATE TABLE IF NOT EXISTS `tbl_order_import` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idsupplier` int(11) NOT NULL,
  `date` date NOT NULL,
  `description` varchar(50) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_order_import_1` (`idsupplier`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=350 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order_import_detail`
--

CREATE TABLE IF NOT EXISTS `tbl_order_import_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idorder` int(11) NOT NULL,
  `idresource` int(11) NOT NULL,
  `count` float NOT NULL,
  `price` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_order_import_detail_1` (`idorder`),
  KEY `tbl_order_import_detail_2` (`idresource`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=636 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_paid_customer`
--

CREATE TABLE IF NOT EXISTS `tbl_paid_customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idcustomer` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_customer_paid_1` (`idcustomer`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=19 ;

--
-- Dumping data for table `tbl_paid_customer`
--

INSERT INTO `tbl_paid_customer` (`id`, `idcustomer`, `date`, `value`, `note`) VALUES
(18, 1, '2013-05-16', 1, '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_paid_employee`
--

CREATE TABLE IF NOT EXISTS `tbl_paid_employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_employee` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(150) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_employee` (`id_employee`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `tbl_paid_employee`
--

INSERT INTO `tbl_paid_employee` (`id`, `id_employee`, `date`, `value`, `note`) VALUES
(1, 1, '2013-10-05', 100000, 'Ứng đợt 2'),
(2, 1, '2013-10-01', 200000, 'Ứng đợt 1');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_paid_general`
--

CREATE TABLE IF NOT EXISTS `tbl_paid_general` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_term` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_paid_1` (`id_term`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=167 ;

--
-- Dumping data for table `tbl_paid_general`
--

INSERT INTO `tbl_paid_general` (`id`, `id_term`, `date`, `value`, `note`) VALUES
(9, 10, '2013-04-01', 157000, 'Chi tiền chợ'),
(10, 10, '2013-04-02', 146000, 'Tiền chợ'),
(11, 10, '2013-04-03', 189000, 'Tiền chợ'),
(12, 10, '2013-04-04', 184000, 'Tiền chợ'),
(20, 11, '2013-04-06', 163000, 'Chi mua đồ điện '),
(21, 11, '2013-12-04', 250000, 'Mua CB'),
(22, 11, '2013-04-07', 57000, 'Trái cây cúng+bao kiếng trái cây'),
(66, 2, '2013-04-30', 2100000, 'Tạm tính'),
(111, 3, '2013-07-31', 1500000, 'Thuế TTĐB Tháng 07'),
(112, 1, '2013-07-31', 4000000, 'Tiền điện T07'),
(113, 2, '2013-07-31', 2000000, 'Tiền nước T07'),
(155, 3, '2013-08-31', 800000, 'Thuế TTĐB T08'),
(156, 3, '2013-09-30', 850000, 'Thuế TTĐB T09'),
(158, 1, '2013-08-31', 5800000, 'Tiền điện T08'),
(159, 1, '2013-09-30', 3700000, 'Tiền điện T09'),
(160, 2, '2013-08-31', 2200000, 'Tiền nước T08'),
(161, 2, '2013-09-30', 2300000, 'Tiền nước T09'),
(163, 1, '2013-05-31', 4700000, 'Tiền điện T05'),
(164, 1, '2013-06-30', 3900000, 'Tiền điện T06'),
(165, 2, '2013-05-31', 2350000, 'Tiền nước T05'),
(166, 2, '2013-06-30', 2260000, 'Tiền nước T06');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_paid_pay_roll`
--

CREATE TABLE IF NOT EXISTS `tbl_paid_pay_roll` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_employee` int(11) NOT NULL,
  `date` date NOT NULL,
  `value_base` int(11) NOT NULL,
  `value_sub` int(11) NOT NULL,
  `value_pre` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_paid_pay_roll_1` (`id_employee`),
  KEY `id_employee` (`id_employee`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_paid_supplier`
--

CREATE TABLE IF NOT EXISTS `tbl_paid_supplier` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idsupplier` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_supplier_paid_1` (`idsupplier`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=18 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_pay_roll`
--

CREATE TABLE IF NOT EXISTS `tbl_pay_roll` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_employee` int(11) NOT NULL,
  `date` date NOT NULL,
  `state` int(11) NOT NULL,
  `extra` int(11) NOT NULL,
  `late` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_employee` (`id_employee`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=63 ;

--
-- Dumping data for table `tbl_pay_roll`
--

INSERT INTO `tbl_pay_roll` (`id`, `id_employee`, `date`, `state`, `extra`, `late`) VALUES
(1, 1, '2013-10-01', 1, 0, 0),
(2, 1, '2013-10-02', 1, 0, 0),
(3, 1, '2013-10-03', 1, 0, 0),
(4, 1, '2013-10-04', 1, 0, 0),
(5, 1, '2013-10-05', 1, 0, 0),
(6, 1, '2013-10-06', 1, 0, 0),
(7, 1, '2013-10-07', 1, 0, 0),
(8, 1, '2013-10-08', 1, 0, 0),
(9, 1, '2013-10-09', 1, 0, 0),
(10, 1, '2013-10-10', 1, 0, 0),
(11, 1, '2013-10-11', 1, 0, 0),
(12, 1, '2013-10-12', 1, 0, 0),
(13, 1, '2013-10-13', 1, 0, 0),
(14, 1, '2013-10-14', 1, 0, 0),
(15, 1, '2013-10-31', 1, 0, 0),
(16, 1, '2013-10-30', 1, 0, 0),
(17, 1, '2013-10-15', 1, 0, 0),
(18, 1, '2013-10-16', 1, 0, 0),
(19, 1, '2013-10-17', 1, 0, 0),
(20, 1, '2013-10-18', 1, 0, 0),
(21, 1, '2013-10-19', 1, 0, 0),
(22, 1, '2013-10-25', 1, 0, 0),
(23, 1, '2013-10-27', 1, 0, 0),
(24, 1, '2013-10-24', 1, 0, 0),
(25, 1, '2013-10-21', 1, 0, 0),
(26, 1, '2013-10-20', 1, 0, 0),
(27, 1, '2013-10-23', 1, 0, 0),
(28, 1, '2013-10-22', 1, 0, 0),
(29, 1, '2013-10-26', 1, 0, 0),
(30, 1, '2013-10-28', 1, 0, 0),
(31, 1, '2013-10-29', 1, 0, 0),
(32, 2, '2013-10-01', 1, 0, 0),
(33, 2, '2013-10-02', 1, 0, 0),
(34, 2, '2013-10-03', 1, 0, 0),
(35, 2, '2013-10-04', 1, 0, 0),
(36, 2, '2013-10-05', 1, 0, 0),
(37, 2, '2013-10-06', 1, 0, 0),
(38, 2, '2013-10-07', 1, 0, 0),
(39, 2, '2013-10-08', 1, 0, 0),
(40, 2, '2013-10-09', 1, 0, 0),
(41, 2, '2013-10-10', 1, 0, 0),
(42, 2, '2013-10-11', 1, 0, 0),
(43, 2, '2013-10-12', 1, 0, 0),
(44, 2, '2013-10-13', 1, 0, 0),
(45, 2, '2013-10-14', 1, 0, 0),
(46, 2, '2013-10-15', 1, 0, 0),
(47, 2, '2013-10-16', 1, 0, 0),
(48, 2, '2013-10-17', 1, 0, 0),
(49, 2, '2013-10-18', 1, 0, 0),
(50, 2, '2013-10-19', 1, 0, 0),
(51, 2, '2013-10-20', 1, 0, 0),
(52, 2, '2013-10-21', 1, 0, 0),
(53, 2, '2013-10-22', 1, 0, 0),
(54, 2, '2013-10-23', 1, 0, 0),
(55, 2, '2013-10-24', 1, 0, 0),
(56, 2, '2013-10-25', 1, 0, 0),
(57, 2, '2013-10-26', 1, 0, 0),
(58, 2, '2013-10-27', 1, 0, 0),
(59, 2, '2013-10-28', 1, 0, 0),
(60, 2, '2013-10-29', 1, 0, 0),
(61, 2, '2013-10-30', 1, 0, 0),
(62, 2, '2013-10-31', 1, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_r2c`
--

CREATE TABLE IF NOT EXISTS `tbl_r2c` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_course` int(11) NOT NULL,
  `id_resource` int(11) NOT NULL,
  `value1` double NOT NULL,
  `value2` double NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_r2c_1` (`id_course`),
  KEY `tbl_r2c_2` (`id_resource`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=160 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_resource`
--

CREATE TABLE IF NOT EXISTS `tbl_resource` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `idsupplier` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `unit` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `price` int(10) NOT NULL,
  `description` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_resource_1` (`idsupplier`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=105 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_session`
--

CREATE TABLE IF NOT EXISTS `tbl_session` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idtable` int(11) NOT NULL,
  `iduser` int(11) NOT NULL,
  `idcustomer` int(11) NOT NULL,
  `idtemployee` int(11) NOT NULL,
  `datetime` datetime NOT NULL,
  `datetimeend` datetime DEFAULT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  `discount_value` int(11) NOT NULL,
  `discount_percent` int(11) NOT NULL,
  `surtax` int(11) NOT NULL,
  `payment` int(11) NOT NULL,
  `value` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idtable` (`idtable`),
  KEY `iduser` (`iduser`),
  KEY `tbl_session_3` (`idcustomer`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=28 ;

--
-- Dumping data for table `tbl_session`
--

INSERT INTO `tbl_session` (`id`, `idtable`, `iduser`, `idcustomer`, `idtemployee`, `datetime`, `datetimeend`, `note`, `status`, `discount_value`, `discount_percent`, `surtax`, `payment`, `value`) VALUES
(3, 1, 1, 1, 0, '2013-11-12 15:17:53', '2013-11-12 15:17:53', '', 1, 0, 0, 0, 0, 0),
(4, 1, 1, 1, 0, '2013-11-20 00:11:16', '2013-11-20 00:11:16', '', 1, 0, 0, 0, 0, 0),
(9, 1, 1, 1, 0, '2013-11-27 10:32:31', '2013-11-27 10:32:31', '', 1, 0, 0, 0, 0, 0),
(10, 2, 1, 1, 0, '2013-12-04 03:55:12', '2013-12-04 03:55:12', '', 1, 0, 0, 0, 0, 0),
(12, 2, 1, 1, 0, '2013-12-05 23:48:36', '2013-12-05 23:48:36', '', 1, 0, 0, 0, 0, 0),
(13, 14, 1, 1, 0, '2013-12-06 18:10:58', '2013-12-06 18:10:58', '', 1, 0, 0, 0, 0, 0),
(14, 1, 1, 1, 0, '2013-12-06 22:40:58', '2013-12-06 22:40:58', '', 1, 0, 10, 0, 0, 0),
(15, 2, 1, 1, 0, '2013-12-07 01:47:45', '2013-12-07 01:47:45', '', 1, 0, 0, 0, 0, 0),
(17, 15, 1, 12, 0, '2013-12-09 19:38:42', '2013-12-09 19:38:42', '', 1, 0, 5, 0, 0, 0),
(18, 33, 1, 1, 0, '2013-12-09 19:45:29', '2013-12-09 19:45:29', '', 1, 0, 0, 0, 0, 0),
(19, 32, 1, 1, 0, '2013-12-09 19:47:30', '2013-12-09 19:47:30', '', 1, 0, 0, 0, 0, 0),
(21, 14, 1, 1, 0, '2013-12-19 01:50:49', '2013-12-19 01:50:49', '', 1, 0, 0, 0, 0, 0),
(22, 15, 1, 1, 0, '2013-12-19 15:48:38', '2013-12-19 15:48:38', '', 1, 0, 0, 0, 0, 0),
(23, 1, 1, 1, 0, '2013-12-19 21:01:04', '2013-12-19 21:01:04', '', 1, 0, 0, 0, 0, 0),
(24, 16, 1, 12, 0, '2013-12-20 07:58:30', '2013-12-20 07:58:30', '', 1, 0, 5, 0, 0, 0),
(25, 28, 1, 13, 0, '2013-12-20 09:11:36', '2013-12-20 09:11:36', '', 1, 0, 10, 0, 0, 0),
(26, 1, 1, 12, 0, '2013-12-22 14:53:25', '2013-12-22 14:53:25', '', 1, 0, 10, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_session_detail`
--

CREATE TABLE IF NOT EXISTS `tbl_session_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idsession` int(11) NOT NULL,
  `idcourse` int(11) NOT NULL,
  `count` float NOT NULL,
  `price` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idsession` (`idsession`),
  KEY `idcourse` (`idcourse`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=86 ;

--
-- Dumping data for table `tbl_session_detail`
--

INSERT INTO `tbl_session_detail` (`id`, `idsession`, `idcourse`, `count`, `price`) VALUES
(7, 4, 165, 2, 12000),
(24, 12, 187, 4, 11000),
(25, 12, 165, 1, 85000),
(27, 13, 187, 20, 11000),
(28, 14, 187, 20, 11000),
(30, 14, 111, 1, 320000),
(33, 14, 188, 1, 16000),
(39, 18, 187, 1, 11000),
(42, 19, 165, 1, 85000),
(48, 21, 15, 1, 13000),
(51, 14, 15, 1, 13000),
(57, 15, 15, 1, 13000),
(58, 14, 243, 1, 100000),
(60, 23, 187, 1, 11000),
(61, 23, 188, 1, 16000),
(64, 23, 111, 1, 320000),
(68, 24, 15, 10, 13000),
(69, 24, 115, 10, 12000),
(72, 25, 116, 20, 9000),
(73, 26, 243, 1, 100000),
(74, 26, 187, 10, 11000);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_store`
--

CREATE TABLE IF NOT EXISTS `tbl_store` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(125) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_store`
--

INSERT INTO `tbl_store` (`id`, `name`, `note`) VALUES
(1, 'Kho nhà', 'Ghi chú gì đây ?');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_supplier`
--

CREATE TABLE IF NOT EXISTS `tbl_supplier` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `debt` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=28 ;

--
-- Dumping data for table `tbl_supplier`
--

INSERT INTO `tbl_supplier` (`id`, `name`, `phone`, `address`, `note`, `debt`) VALUES
(13, 'Cá sống-cua ghẹ', '', 'Can Tho', '', 0),
(14, 'Nước Đá', '', '', '', 0),
(15, 'Nghêu sò', '', '', '', 0),
(16, 'Rau quả', '', '', '', 0),
(17, 'Gia vị', '', '', '', 0),
(18, 'Gia cầm', '', '', '', 0),
(19, 'Hàng đông lạnh', '', '', '', 0),
(20, 'Gas...', '', '', '', 0),
(21, 'Bia..', '', '', '', 0),
(22, 'Nước ngọt', '', '', '', 0),
(23, 'Rượu ngoại', '', '', '', 0),
(24, 'Rượu nội', '', '', '', 0),
(25, 'Vật dụng bếp', '', '', '', 0),
(26, 'Vật dụng tổ bàn', '', '', '', 0),
(27, 'khăn giấy-tăm tre', '', '', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_table`
--

CREATE TABLE IF NOT EXISTS `tbl_table` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iddomain` int(11) NOT NULL,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `iduser` int(11) DEFAULT NULL,
  `type` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `iddomain` (`iddomain`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=44 ;

--
-- Dumping data for table `tbl_table`
--

INSERT INTO `tbl_table` (`id`, `iddomain`, `name`, `iduser`, `type`) VALUES
(1, 1, 'PL01', 1, '0'),
(2, 1, 'PL02', 1, '0'),
(14, 2, 'NT01', 1, '0'),
(15, 2, 'NT02', 1, '0'),
(16, 2, 'NT03', 1, '0'),
(26, 3, 'NT01', 1, '0'),
(27, 3, 'NT02', 1, '0'),
(28, 3, 'NT03', 1, '0'),
(29, 3, 'NT04', 1, '0'),
(30, 3, 'NT05', 1, '0'),
(31, 3, 'NT06', 1, '0'),
(32, 3, 'NT07', 1, '0'),
(33, 3, 'NT08', 1, '0'),
(34, 4, 'HT01', 1, '0'),
(35, 4, 'HT02', 1, '0'),
(36, 4, 'HT03', 1, '0'),
(37, 4, 'HT04', 1, '0'),
(38, 4, 'HT05', 1, '0'),
(39, 4, 'HT06', 1, '0'),
(40, 4, 'HT07', 1, '0'),
(41, 4, 'HT08', 1, '0'),
(42, 3, 'NGT09', 1, '0'),
(43, 3, 'NT10', 1, '0');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_term`
--

CREATE TABLE IF NOT EXISTS `tbl_term` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=12 ;

--
-- Dumping data for table `tbl_term`
--

INSERT INTO `tbl_term` (`id`, `name`, `type`) VALUES
(1, 'Tiền Điện', 0),
(2, 'Tiền Nước', 0),
(3, 'Thuế', 0),
(10, 'Tiền Ăn Nhân Viên', 0),
(11, 'CP Khác', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_term_collect`
--

CREATE TABLE IF NOT EXISTS `tbl_term_collect` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `tbl_term_collect`
--

INSERT INTO `tbl_term_collect` (`id`, `name`) VALUES
(2, 'Phụ Phẩm'),
(3, 'Đặc Biệt');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tracking`
--

CREATE TABLE IF NOT EXISTS `tbl_tracking` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_start` date NOT NULL,
  `date_end` date NOT NULL,
  `paid_general` int(11) NOT NULL,
  `paid_pay_roll` int(11) NOT NULL,
  `paid_import` int(11) NOT NULL,
  `collect_general` int(11) NOT NULL,
  `collect_customer` int(11) NOT NULL,
  `collect_selling_debt` int(11) NOT NULL,
  `collect_selling_nodebt` int(11) NOT NULL,
  `estate_rate` int(11) NOT NULL,
  `store_value` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=15 ;

--
-- Dumping data for table `tbl_tracking`
--

INSERT INTO `tbl_tracking` (`id`, `date_start`, `date_end`, `paid_general`, `paid_pay_roll`, `paid_import`, `collect_general`, `collect_customer`, `collect_selling_debt`, `collect_selling_nodebt`, `estate_rate`, `store_value`) VALUES
(10, '2013-10-01', '2013-10-31', 0, 0, 0, 0, 0, 0, 0, 0, 0),
(11, '2013-11-01', '2013-11-30', 0, 0, 0, 0, 0, 0, 0, 0, 0),
(12, '2013-12-01', '2013-12-31', 0, 0, 0, 0, 0, 0, 0, 0, 0),
(13, '2014-01-01', '2014-01-31', 0, 0, 0, 0, 0, 0, 0, 0, 0),
(14, '2014-02-01', '2014-02-28', 0, 0, 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tracking_course`
--

CREATE TABLE IF NOT EXISTS `tbl_tracking_course` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tracking` int(11) NOT NULL,
  `id_td` int(11) NOT NULL,
  `id_course` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `value` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=209 ;

--
-- Dumping data for table `tbl_tracking_course`
--

INSERT INTO `tbl_tracking_course` (`id`, `id_tracking`, `id_td`, `id_course`, `count`, `price`, `value`) VALUES
(197, 12, 67, 187, 40, 0, 0),
(198, 12, 67, 55, 5, 0, 0),
(199, 12, 67, 243, 1, 0, 0),
(200, 12, 67, 188, 1, 0, 0),
(201, 12, 67, 227, 6, 0, 0),
(202, 12, 67, 161, 2, 0, 0),
(203, 12, 67, 111, 1, 0, 0),
(204, 12, 67, 15, 1, 0, 0),
(205, 12, 66, 187, 4, 0, 0),
(206, 12, 66, 165, 1, 0, 0),
(207, 12, 66, 240, 1, 0, 0),
(208, 12, 66, 238, 2, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tracking_customer`
--

CREATE TABLE IF NOT EXISTS `tbl_tracking_customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tracking` int(11) NOT NULL,
  `id_customer` int(11) NOT NULL,
  `value_session1` int(11) NOT NULL,
  `value_session2` int(11) NOT NULL,
  `value_collect` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tracking_daily`
--

CREATE TABLE IF NOT EXISTS `tbl_tracking_daily` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tracking` int(11) NOT NULL,
  `date` date NOT NULL,
  `selling` bigint(20) NOT NULL,
  `import` bigint(20) NOT NULL,
  `store` bigint(20) NOT NULL,
  `paid` bigint(20) NOT NULL,
  `collect` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=152 ;

--
-- Dumping data for table `tbl_tracking_daily`
--

INSERT INTO `tbl_tracking_daily` (`id`, `id_tracking`, `date`, `selling`, `import`, `store`, `paid`, `collect`) VALUES
(1, 10, '2013-10-01', 0, 0, 0, 0, 0),
(2, 10, '2013-10-02', 0, 0, 0, 0, 0),
(3, 10, '2013-10-03', 0, 0, 0, 0, 0),
(4, 10, '2013-10-04', 0, 0, 0, 0, 0),
(5, 10, '2013-10-05', 0, 0, 0, 0, 0),
(6, 10, '2013-10-06', 0, 0, 0, 0, 0),
(7, 10, '2013-10-07', 0, 0, 0, 0, 0),
(8, 10, '2013-10-08', 0, 0, 0, 0, 0),
(9, 10, '2013-10-09', 0, 0, 0, 0, 0),
(10, 10, '2013-10-10', 0, 0, 0, 0, 0),
(11, 10, '2013-10-11', 0, 0, 0, 0, 0),
(12, 10, '2013-10-12', 0, 0, 0, 0, 0),
(13, 10, '2013-10-13', 0, 0, 0, 0, 0),
(14, 10, '2013-10-14', 0, 0, 0, 0, 0),
(15, 10, '2013-10-15', 0, 0, 0, 0, 0),
(16, 10, '2013-10-16', 0, 0, 0, 0, 0),
(17, 10, '2013-10-17', 0, 0, 0, 0, 0),
(18, 10, '2013-10-18', 0, 0, 0, 0, 0),
(19, 10, '2013-10-19', 0, 0, 0, 0, 0),
(20, 10, '2013-10-20', 0, 0, 0, 0, 0),
(21, 10, '2013-10-21', 0, 0, 0, 0, 0),
(22, 10, '2013-10-22', 0, 0, 0, 0, 0),
(23, 10, '2013-10-23', 0, 0, 0, 0, 0),
(24, 10, '2013-10-24', 0, 0, 0, 0, 0),
(25, 10, '2013-10-25', 0, 0, 0, 0, 0),
(26, 10, '2013-10-26', 0, 0, 0, 0, 0),
(27, 10, '2013-10-27', 0, 0, 0, 0, 0),
(28, 10, '2013-10-28', 0, 0, 0, 0, 0),
(29, 10, '2013-10-29', 0, 0, 0, 0, 0),
(30, 10, '2013-10-30', 0, 0, 0, 0, 0),
(31, 10, '2013-10-31', 0, 0, 0, 0, 0),
(32, 11, '2013-11-01', 0, 0, 0, 0, 0),
(33, 11, '2013-11-02', 0, 0, 0, 0, 0),
(34, 11, '2013-11-03', 0, 0, 0, 0, 0),
(35, 11, '2013-11-04', 0, 0, 0, 0, 0),
(36, 11, '2013-11-05', 0, 0, 0, 0, 0),
(37, 11, '2013-11-06', 0, 0, 0, 0, 0),
(38, 11, '2013-11-07', 0, 0, 0, 0, 0),
(39, 11, '2013-11-08', 0, 0, 0, 0, 0),
(40, 11, '2013-11-09', 0, 0, 0, 0, 0),
(41, 11, '2013-11-10', 0, 0, 0, 0, 0),
(42, 11, '2013-11-11', 0, 0, 0, 0, 0),
(43, 11, '2013-11-12', 0, 0, 0, 0, 0),
(44, 11, '2013-11-13', 0, 0, 0, 0, 0),
(45, 11, '2013-11-14', 0, 0, 0, 0, 0),
(46, 11, '2013-11-15', 0, 0, 0, 0, 0),
(47, 11, '2013-11-16', 0, 0, 0, 0, 0),
(48, 11, '2013-11-17', 0, 0, 0, 0, 0),
(49, 11, '2013-11-18', 0, 0, 0, 0, 0),
(50, 11, '2013-11-19', 0, 0, 0, 0, 0),
(51, 11, '2013-11-20', 0, 0, 0, 0, 0),
(52, 11, '2013-11-21', 0, 0, 0, 0, 0),
(53, 11, '2013-11-22', 0, 0, 0, 0, 0),
(54, 11, '2013-11-23', 0, 0, 0, 0, 0),
(55, 11, '2013-11-24', 0, 0, 0, 0, 0),
(56, 11, '2013-11-25', 0, 0, 0, 0, 0),
(57, 11, '2013-11-26', 0, 0, 0, 0, 0),
(58, 11, '2013-11-27', 0, 0, 0, 0, 0),
(59, 11, '2013-11-28', 0, 0, 0, 0, 0),
(60, 11, '2013-11-29', 0, 0, 0, 0, 0),
(61, 11, '2013-11-30', 0, 0, 0, 0, 0),
(62, 12, '2013-12-01', 0, 0, 0, 0, 0),
(63, 12, '2013-12-02', 0, 0, 0, 0, 0),
(64, 12, '2013-12-03', 0, 0, 0, 0, 0),
(65, 12, '2013-12-04', 0, 0, 0, 250000, 10000000),
(66, 12, '2013-12-05', 58000, 0, 0, 0, 0),
(67, 12, '2013-12-06', 620000, 0, 0, 0, 0),
(68, 12, '2013-12-07', 0, 0, 0, 0, 0),
(69, 12, '2013-12-08', 0, 0, 0, 0, 0),
(70, 12, '2013-12-09', 0, 0, 0, 0, 0),
(71, 12, '2013-12-10', 0, 0, 0, 0, 0),
(72, 12, '2013-12-11', 0, 0, 0, 0, 0),
(73, 12, '2013-12-12', 0, 0, 0, 0, 0),
(74, 12, '2013-12-13', 0, 0, 0, 0, 0),
(75, 12, '2013-12-14', 0, 0, 0, 0, 0),
(76, 12, '2013-12-15', 0, 0, 0, 0, 0),
(77, 12, '2013-12-16', 0, 0, 0, 0, 0),
(78, 12, '2013-12-17', 0, 0, 0, 0, 0),
(79, 12, '2013-12-18', 0, 0, 0, 0, 0),
(80, 12, '2013-12-19', 0, 0, 0, 0, 0),
(81, 12, '2013-12-20', 0, 0, 0, 0, 0),
(82, 12, '2013-12-21', 0, 0, 0, 0, 0),
(83, 12, '2013-12-22', 0, 0, 0, 0, 0),
(84, 12, '2013-12-23', 0, 0, 0, 0, 0),
(85, 12, '2013-12-24', 0, 0, 0, 0, 0),
(86, 12, '2013-12-25', 0, 0, 0, 0, 0),
(87, 12, '2013-12-26', 0, 0, 0, 0, 0),
(88, 12, '2013-12-27', 0, 0, 0, 0, 0),
(89, 12, '2013-12-28', 0, 0, 0, 0, 0),
(90, 12, '2013-12-29', 0, 0, 0, 0, 0),
(91, 12, '2013-12-30', 0, 0, 0, 0, 0),
(92, 12, '2013-12-31', 0, 0, 0, 0, 0),
(93, 13, '2014-01-01', 0, 0, 0, 0, 0),
(94, 13, '2014-01-02', 0, 0, 0, 0, 0),
(95, 13, '2014-01-03', 0, 0, 0, 0, 0),
(96, 13, '2014-01-04', 0, 0, 0, 0, 0),
(97, 13, '2014-01-05', 0, 0, 0, 0, 0),
(98, 13, '2014-01-06', 0, 0, 0, 0, 0),
(99, 13, '2014-01-07', 0, 0, 0, 0, 0),
(100, 13, '2014-01-08', 0, 0, 0, 0, 0),
(101, 13, '2014-01-09', 0, 0, 0, 0, 0),
(102, 13, '2014-01-10', 0, 0, 0, 0, 0),
(103, 13, '2014-01-11', 0, 0, 0, 0, 0),
(104, 13, '2014-01-12', 0, 0, 0, 0, 0),
(105, 13, '2014-01-13', 0, 0, 0, 0, 0),
(106, 13, '2014-01-14', 0, 0, 0, 0, 0),
(107, 13, '2014-01-15', 0, 0, 0, 0, 0),
(108, 13, '2014-01-16', 0, 0, 0, 0, 0),
(109, 13, '2014-01-17', 0, 0, 0, 0, 0),
(110, 13, '2014-01-18', 0, 0, 0, 0, 0),
(111, 13, '2014-01-19', 0, 0, 0, 0, 0),
(112, 13, '2014-01-20', 0, 0, 0, 0, 0),
(113, 13, '2014-01-21', 0, 0, 0, 0, 0),
(114, 13, '2014-01-22', 0, 0, 0, 0, 0),
(115, 13, '2014-01-23', 0, 0, 0, 0, 0),
(116, 13, '2014-01-24', 0, 0, 0, 0, 0),
(117, 13, '2014-01-25', 0, 0, 0, 0, 0),
(118, 13, '2014-01-26', 0, 0, 0, 0, 0),
(119, 13, '2014-01-27', 0, 0, 0, 0, 0),
(120, 13, '2014-01-28', 0, 0, 0, 0, 0),
(121, 13, '2014-01-29', 0, 0, 0, 0, 0),
(122, 13, '2014-01-30', 0, 0, 0, 0, 0),
(123, 13, '2014-01-31', 0, 0, 0, 0, 0),
(124, 14, '2014-02-01', 0, 0, 0, 0, 0),
(125, 14, '2014-02-02', 0, 0, 0, 0, 0),
(126, 14, '2014-02-03', 0, 0, 0, 0, 0),
(127, 14, '2014-02-04', 0, 0, 0, 0, 0),
(128, 14, '2014-02-05', 0, 0, 0, 0, 0),
(129, 14, '2014-02-06', 0, 0, 0, 0, 0),
(130, 14, '2014-02-07', 0, 0, 0, 0, 0),
(131, 14, '2014-02-08', 0, 0, 0, 0, 0),
(132, 14, '2014-02-09', 0, 0, 0, 0, 0),
(133, 14, '2014-02-10', 0, 0, 0, 0, 0),
(134, 14, '2014-02-11', 0, 0, 0, 0, 0),
(135, 14, '2014-02-12', 0, 0, 0, 0, 0),
(136, 14, '2014-02-13', 0, 0, 0, 0, 0),
(137, 14, '2014-02-14', 0, 0, 0, 0, 0),
(138, 14, '2014-02-15', 0, 0, 0, 0, 0),
(139, 14, '2014-02-16', 0, 0, 0, 0, 0),
(140, 14, '2014-02-17', 0, 0, 0, 0, 0),
(141, 14, '2014-02-18', 0, 0, 0, 0, 0),
(142, 14, '2014-02-19', 0, 0, 0, 0, 0),
(143, 14, '2014-02-20', 0, 0, 0, 0, 0),
(144, 14, '2014-02-21', 0, 0, 0, 0, 0),
(145, 14, '2014-02-22', 0, 0, 0, 0, 0),
(146, 14, '2014-02-23', 0, 0, 0, 0, 0),
(147, 14, '2014-02-24', 0, 0, 0, 0, 0),
(148, 14, '2014-02-25', 0, 0, 0, 0, 0),
(149, 14, '2014-02-26', 0, 0, 0, 0, 0),
(150, 14, '2014-02-27', 0, 0, 0, 0, 0),
(151, 14, '2014-02-28', 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tracking_store`
--

CREATE TABLE IF NOT EXISTS `tbl_tracking_store` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tracking` int(11) NOT NULL,
  `id_td` int(11) NOT NULL,
  `id_resource` int(11) NOT NULL,
  `count_old` float NOT NULL,
  `count_import` float NOT NULL,
  `count_export` float NOT NULL,
  `price` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1875 ;

--
-- Dumping data for table `tbl_tracking_store`
--

INSERT INTO `tbl_tracking_store` (`id`, `id_tracking`, `id_td`, `id_resource`, `count_old`, `count_import`, `count_export`, `price`) VALUES
(1860, 11, 65, 19, 0, 1, 0.3, 150000);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_unit`
--

CREATE TABLE IF NOT EXISTS `tbl_unit` (
  `id` int(25) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=25 ;

--
-- Dumping data for table `tbl_unit`
--

INSERT INTO `tbl_unit` (`id`, `name`) VALUES
(1, 'Ly'),
(2, 'Điếu'),
(3, 'Chai'),
(4, 'Lon'),
(5, 'Dĩa'),
(6, 'Thùng'),
(7, 'Két'),
(9, 'Bịch'),
(10, 'Gói'),
(20, 'Trái'),
(21, 'Cái'),
(22, 'Hủ'),
(23, 'Kg'),
(24, 'Con');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE IF NOT EXISTS `tbl_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pass` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gender` int(11) NOT NULL,
  `note` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `datecreate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dateupdate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `dateactivity` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `type` tinyint(4) NOT NULL,
  `code` varchar(13) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=6 ;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `name`, `email`, `pass`, `gender`, `note`, `datecreate`, `dateupdate`, `dateactivity`, `type`, `code`) VALUES
(1, 'Tuấn', 'tuanbuithanh@gmail.com', 'admin068368', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 4, ''),
(3, 'Khoa', 'lekhoa.bdc@gmail.com', 'lenguyen0945030709...', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 4, ''),
(4, 'Mai', 'maiphan.bdc@gmail.com', 'admin123456', 1, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 4, '');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_collect_customer`
--
ALTER TABLE `tbl_collect_customer`
  ADD CONSTRAINT `tbl_customer_collect_1` FOREIGN KEY (`idcustomer`) REFERENCES `tbl_customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_collect_general`
--
ALTER TABLE `tbl_collect_general`
  ADD CONSTRAINT `tbl_collect_general_1` FOREIGN KEY (`id_term`) REFERENCES `tbl_term_collect` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_course`
--
ALTER TABLE `tbl_course`
  ADD CONSTRAINT `tbl_course_1` FOREIGN KEY (`idcategory`) REFERENCES `tbl_category` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_order_import`
--
ALTER TABLE `tbl_order_import`
  ADD CONSTRAINT `tbl_order_import_1` FOREIGN KEY (`idsupplier`) REFERENCES `tbl_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_order_import_detail`
--
ALTER TABLE `tbl_order_import_detail`
  ADD CONSTRAINT `tbl_order_import_detail_1` FOREIGN KEY (`idorder`) REFERENCES `tbl_order_import` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_order_import_detail_2` FOREIGN KEY (`idresource`) REFERENCES `tbl_resource` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_paid_customer`
--
ALTER TABLE `tbl_paid_customer`
  ADD CONSTRAINT `tbl_customer_paid_1` FOREIGN KEY (`idcustomer`) REFERENCES `tbl_customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_paid_employee`
--
ALTER TABLE `tbl_paid_employee`
  ADD CONSTRAINT `tbl_paid_employee_ibfk_1` FOREIGN KEY (`id_employee`) REFERENCES `tbl_employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_paid_general`
--
ALTER TABLE `tbl_paid_general`
  ADD CONSTRAINT `tbl_paid_general_1` FOREIGN KEY (`id_term`) REFERENCES `tbl_term` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_paid_pay_roll`
--
ALTER TABLE `tbl_paid_pay_roll`
  ADD CONSTRAINT `tbl_paid_pay_roll_ibfk_1` FOREIGN KEY (`id_employee`) REFERENCES `tbl_employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_paid_supplier`
--
ALTER TABLE `tbl_paid_supplier`
  ADD CONSTRAINT `tbl_supplier_paid_1` FOREIGN KEY (`idsupplier`) REFERENCES `tbl_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_pay_roll`
--
ALTER TABLE `tbl_pay_roll`
  ADD CONSTRAINT `tbl_pay_roll_ibfk_1` FOREIGN KEY (`id_employee`) REFERENCES `tbl_employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_r2c`
--
ALTER TABLE `tbl_r2c`
  ADD CONSTRAINT `tbl_r2c_1` FOREIGN KEY (`id_course`) REFERENCES `tbl_course` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_r2c_2` FOREIGN KEY (`id_resource`) REFERENCES `tbl_resource` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_resource`
--
ALTER TABLE `tbl_resource`
  ADD CONSTRAINT `tbl_resource_1` FOREIGN KEY (`idsupplier`) REFERENCES `tbl_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_session`
--
ALTER TABLE `tbl_session`
  ADD CONSTRAINT `tbl_session_1` FOREIGN KEY (`idtable`) REFERENCES `tbl_table` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_session_2` FOREIGN KEY (`iduser`) REFERENCES `tbl_user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_session_3` FOREIGN KEY (`idcustomer`) REFERENCES `tbl_customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_session_detail`
--
ALTER TABLE `tbl_session_detail`
  ADD CONSTRAINT `tbl_session_detail_1` FOREIGN KEY (`idsession`) REFERENCES `tbl_session` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_session_detail_2` FOREIGN KEY (`idcourse`) REFERENCES `tbl_course` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_table`
--
ALTER TABLE `tbl_table`
  ADD CONSTRAINT `tbl_table_1` FOREIGN KEY (`iddomain`) REFERENCES `tbl_domain` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
