-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 25, 2013 at 03:59 AM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `qlquanan_baduc`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_app`
--

CREATE TABLE IF NOT EXISTS `tbl_app` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(125) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(50) CHARACTER SET utf8 NOT NULL,
  `banner` varchar(125) CHARACTER SET utf8 NOT NULL,
  `prefix` varchar(50) CHARACTER SET utf8 NOT NULL,
  `alias` varchar(256) CHARACTER SET utf8 NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_activity` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `type` tinyint(4) NOT NULL,
  `page_view` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_app`
--

INSERT INTO `tbl_app` (`id`, `name`, `phone`, `address`, `email`, `banner`, `prefix`, `alias`, `date_created`, `date_modified`, `date_activity`, `type`, `page_view`) VALUES
(1, 'Karaoke Ba Đức', '0945 03 07 09', 'Phó Cơ Điều P3 - TPVL', '', 'data/images/banner/logo.png', 'tbl_', 'tbl_', '2012-06-30 17:00:00', '0000-00-00 00:00:00', '2012-12-26 07:28:02', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

CREATE TABLE IF NOT EXISTS `tbl_category` (
  `id` int(25) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `picture` binary(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=23 ;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`id`, `name`, `picture`) VALUES
(3, 'Mực', NULL),
(8, 'Cá biển', NULL),
(11, 'Bia - nước ngọt', NULL),
(12, 'Cá sông', NULL),
(13, 'Lẩu', NULL),
(14, 'Chiên', NULL),
(15, 'Nghêu - sò - ốc', NULL),
(16, 'Bò', NULL),
(17, 'Xào', NULL),
(18, 'Rượu', NULL),
(19, 'Gỏi', NULL),
(20, 'Cơm', NULL),
(21, 'Tôm - hàu', NULL),
(22, 'Tự nhập', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_collect_customer`
--

CREATE TABLE IF NOT EXISTS `tbl_collect_customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idcustomer` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_customer_collect_1` (`idcustomer`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tbl_collect_customer`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_collect_general`
--

CREATE TABLE IF NOT EXISTS `tbl_collect_general` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_term` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_collect_1` (`id_term`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

--
-- Dumping data for table `tbl_collect_general`
--

INSERT INTO `tbl_collect_general` (`id`, `id_term`, `date`, `value`, `note`) VALUES
(5, 2, '2013-05-18', 10, 'd'),
(6, 3, '2013-12-04', 10000000, 'Bổ sung tiền quỹ');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_config`
--

CREATE TABLE IF NOT EXISTS `tbl_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `param` varchar(125) COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=10 ;

--
-- Dumping data for table `tbl_config`
--

INSERT INTO `tbl_config` (`id`, `param`, `value`) VALUES
(5, 'DISCOUNT', '0'),
(6, 'ROW_PER_PAGE', '12'),
(7, 'GUEST_VISIT', '9247'),
(8, 'EVERY_5_MINUTES', '2000'),
(9, 'CATEGORY_AUTO', '22');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_course`
--

CREATE TABLE IF NOT EXISTS `tbl_course` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idcategory` int(25) DEFAULT NULL,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `shortname` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `unit` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `price1` bigint(20) NOT NULL,
  `price2` bigint(20) NOT NULL,
  `price3` bigint(20) NOT NULL,
  `price4` bigint(20) NOT NULL,
  `picture` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `prepare` int(11) NOT NULL,
  `is_discount` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `foreign_field` (`idcategory`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=247 ;

--
-- Dumping data for table `tbl_course`
--

INSERT INTO `tbl_course` (`id`, `idcategory`, `name`, `shortname`, `unit`, `price1`, `price2`, `price3`, `price4`, `picture`, `prepare`, `is_discount`) VALUES
(15, 11, 'Sài gòn lon xanh', 'SG lon xanh', 'Lon', 13000, 13000, 13000, 13000, '', 1, 1),
(53, 8, 'Cá sòng nướng muối', 'Cá sòng n-muối', 'Dĩa', 0, 0, 0, 0, '', 0, 1),
(54, 8, 'Cá cam', 'Cá cam', 'Dĩa', 0, 0, 0, 0, '', 0, 1),
(55, 8, 'Cá bóp', 'Cá bóp', 'Dĩa', 0, 0, 0, 0, '', 0, 1),
(56, 8, 'Cá diễn', 'Cá diễn', 'Dĩa', 0, 0, 0, 0, '', 0, 1),
(107, 3, 'Mực hấp gừng', 'hấp gừng', 'Dĩa', 58000, 58000, 58000, 58000, '', 0, 1),
(108, 3, 'Mực chiên nước mắm', 'chiên nước mắm', 'Dĩa', 58000, 58000, 58000, 58000, '', 0, 1),
(110, 12, 'Cá chạnh cơm', 'Cá chạnh cơm', 'Dĩa', 0, 0, 0, 0, '', 0, 1),
(111, 3, 'Mực nướng', 'nướng', 'Kg', 320000, 320000, 320000, 320000, '', 0, 1),
(112, 3, 'Mực trứng Phú Quốc', 'trứng PQ', 'Dĩa', 95000, 95000, 95000, 95000, '', 0, 1),
(115, 11, 'Sài gòn chai xanh', 'SG chai xanh', 'Chai', 12000, 12000, 12000, 12000, '', 0, 1),
(116, 11, 'Sài gòn đỏ', 'SG đỏ', 'Chai', 9000, 9000, 9000, 9000, '', 0, 1),
(117, 12, 'Cá lăng vàng', 'Cá lăng vàng', 'Dĩa', 0, 0, 0, 0, '', 0, 1),
(118, 12, 'Cá ét', 'Cá ét', 'Dĩa', 0, 0, 0, 0, '', 0, 1),
(119, 12, 'Cá điêu hồng', 'Cá điêu hồng', 'Dĩa', 0, 0, 0, 0, '', 0, 1),
(120, 12, 'Cá lóc', 'Cá lóc', 'Dĩa', 0, 0, 0, 0, '', 0, 1),
(121, 12, 'Cá hô', 'Cá hô', 'Dĩa', 0, 0, 0, 0, '', 0, 1),
(122, 12, 'Cá ngát', 'Cá ngát', 'Dĩa', 0, 0, 0, 0, '', 0, 1),
(126, 8, 'Cá nhòng', 'Cá nhòng', 'Dĩa', 0, 0, 0, 0, '', 0, 1),
(127, 8, 'Cá xanh xương', 'Cá x-xương', 'Dĩa', 0, 0, 0, 0, '', 0, 1),
(128, 8, 'Cá đuối', 'Cá đuối', 'Dĩa', 0, 0, 0, 0, '', 0, 1),
(129, 8, 'Cá sapa', 'Cá sapa', 'Dĩa', 0, 0, 0, 0, '', 0, 1),
(136, 8, 'Cá trứng', 'Cá trứng', 'Dĩa', 0, 0, 0, 0, '', 0, 1),
(149, 13, 'Lẩu hải sản', 'hải sản', 'Cái', 105000, 105000, 105000, 105000, '', 20, 1),
(161, 13, 'Lẩu cá măng chua', 'cá măng chua', 'Cái', 105000, 105000, 105000, 105000, '', 15, 1),
(162, 13, 'Lẩu riêu Ba Đức', 'riêu Ba Đức', 'Cái', 135000, 135000, 135000, 135000, '', 18, 1),
(163, 13, 'Lẩu đầu cá hồi', 'đầu cá hồi', 'Cái', 98000, 98000, 98000, 98000, '', 12, 1),
(165, 18, 'Phú Lễ', 'Phú Lễ', 'Chai', 85000, 85000, 85000, 85000, '', 0, 1),
(166, 18, 'Volka lớn', 'Volka lớn', 'Chai', 105000, 105000, 105000, 105000, '', 0, 1),
(167, 18, 'Volka nhỏ', 'Volka nhỏ', 'Chai', 65000, 65000, 65000, 65000, '', 0, 1),
(169, 19, 'Gỏi củ hủ dừa sứa', 'củ hủ dừa sứa', 'Dĩa', 55000, 55000, 55000, 55000, '', 0, 1),
(170, 19, 'Gỏi củ hủ dừa tôm thịt', 'củ hủ dừa tôm thịt', 'Dĩa', 55000, 55000, 55000, 55000, '', 0, 1),
(171, 19, 'Gỏi rau muống đồng tôm thịt', 'rau m.đồng tôm thịt', 'Dĩa', 55000, 55000, 55000, 55000, '', 0, 1),
(172, 19, 'Gỏi rau muống đồng hải sản', 'rau m,đồng hải sản', 'Dĩa', 55000, 55000, 55000, 55000, '', 0, 1),
(173, 19, 'Gỏi xoài khô cá lóc', 'xoài khô cá lóc', 'Dĩa', 65000, 65000, 65000, 65000, '', 0, 1),
(174, 15, 'Sò huyết luộc/nướng', 'Sò huyết luộc/nướng', 'Dĩa', 40000, 40000, 40000, 40000, '', 0, 1),
(175, 15, 'Sò huyết rang muối/rang me', 'Sò huyết rang muối/rang me', 'Dĩa', 40000, 40000, 40000, 40000, '', 0, 1),
(176, 15, 'Sò điệp nướng mỡ hành', 'Sò điệp nướng mỡ hành', 'Dĩa', 35000, 35000, 35000, 35000, '', 0, 1),
(177, 15, 'Sò điệp nướng phô mai', 'Sò điệp nướng phô mai', 'Dĩa', 35000, 35000, 35000, 35000, '', 0, 1),
(178, 15, 'Sò vẹo hấp xả', 'Sò vẹo hấp xả', 'Dĩa', 40000, 40000, 40000, 40000, '', 0, 1),
(179, 15, 'Sò vẹo nướng mỡ hành', 'Sò vẹo n. mỡ hành', 'Dĩa', 40000, 40000, 40000, 40000, '', 0, 1),
(180, 15, 'Ốc mỡ xào tỏi', 'Ốc mỡ xào tỏi', 'Dĩa', 55000, 55000, 55000, 55000, '', 0, 1),
(181, 15, 'Ốc mỡ xào hành', 'Ốc mỡ xào hành', 'Dĩa', 55000, 55000, 55000, 55000, '', 0, 1),
(182, 15, 'Ốc mỡ xào me', 'Ốc mỡ xào me', 'Dĩa', 55000, 55000, 55000, 55000, '', 0, 1),
(183, 15, 'Ôc bươu nướng tiêu', 'Ôc bươu n.tiêu', 'Dĩa', 35000, 35000, 35000, 35000, '', 0, 1),
(184, 15, 'Ôc bươu hấp xả', 'Ôc bươu h. xả', 'Dĩa', 35000, 35000, 35000, 35000, '', 0, 1),
(186, 11, '333 lon', '333 lon', 'Lon', 11000, 11000, 11000, 11000, '', 0, 1),
(187, 11, '333 chai', '333 chai', 'Chai', 11000, 11000, 11000, 11000, '', 0, 1),
(188, 11, 'Heneiken chai', 'Ken chai', 'Chai', 16000, 16000, 16000, 16000, '', 0, 1),
(189, 11, 'Heneiken lon', 'Ken lon', 'Lon', 19000, 19000, 19000, 19000, '', 0, 1),
(190, 11, 'Tiger nâu', 'Tiger nâu', 'Chai', 12000, 12000, 12000, 12000, '', 0, 1),
(191, 11, 'Tiger bạc', 'Tiger bạc', 'Chai', 14000, 14000, 14000, 14000, '', 0, 1),
(192, 11, 'Nước ngọt', 'Nước ngọt', 'Chai', 12000, 12000, 12000, 12000, '', 0, 1),
(193, 11, 'Nước suối', 'Nước suối', 'Chai', 10000, 10000, 10000, 10000, '', 0, 1),
(194, 14, 'Khoai tây chiên', 'Khoai tây chiên', 'Dĩa', 30000, 30000, 30000, 30000, '', 0, 1),
(195, 14, 'Đậu hủ chiên sả ớt', 'Đ.hủ chiên sả ớt', 'Dĩa', 30000, 30000, 30000, 30000, '', 0, 1),
(196, 14, 'Đậu hủ chiên giòn', 'Đ.hủ chiên giòn', 'Dĩa', 30000, 30000, 30000, 30000, '', 0, 1),
(197, 14, 'Cá thác lác sả ớt Adi', 'Cá TL sả ớt Adi', 'Dĩa', 60000, 60000, 60000, 60000, '', 0, 1),
(206, 17, 'Mì xào hải sản', 'Mì xào hải sản', 'Dĩa', 60000, 60000, 60000, 60000, '', 0, 1),
(207, 17, 'Mì xào bò', 'Mì xào bò', 'Dĩa', 60000, 60000, 60000, 60000, '', 0, 1),
(208, 17, 'Mực xào sa tế', 'Mực xào sa tế', 'Dĩa', 58000, 58000, 58000, 58000, '', 0, 1),
(209, 17, 'Mực xào chua ngọt', 'Mực xào chua ngọt', 'Dĩa', 58000, 58000, 58000, 58000, '', 0, 1),
(210, 17, 'Rau nhút xào hải sản', 'Rau nhút xào hải sản', 'Dĩa', 58000, 58000, 58000, 58000, '', 0, 1),
(211, 17, 'Rau muống xào tỏi', 'Rau muống xào tỏi', 'Dĩa', 28000, 28000, 28000, 28000, '', 0, 1),
(212, 17, 'Rau muống xào bò', 'Rau muống xào bò', 'Dĩa', 60000, 60000, 60000, 60000, '', 0, 1),
(213, 20, 'Cơm chiên Adi', 'chiên Adi', 'Dĩa', 60000, 60000, 60000, 60000, '', 20, 1),
(214, 20, 'Cơm chiên tỏi', 'chiên tỏi', 'Dĩa', 30000, 30000, 30000, 30000, '', 15, 1),
(215, 20, 'Cơm chiên trứng', 'chiên trứng', 'Dĩa', 40000, 40000, 40000, 40000, '', 15, 1),
(216, 20, 'Cơm chiên hải sản', 'chiên hải sản', 'Điếu', 60000, 60000, 60000, 60000, '', 25, 1),
(218, 16, 'Bò Adi', 'Adi', 'Dĩa', 70000, 70000, 70000, 70000, '', 0, 1),
(219, 16, 'Bò lúc lắc', 'lúc lắc', 'Dĩa', 65000, 65000, 65000, 65000, '', 0, 1),
(220, 16, 'Bò bíttết', 'bít tết', 'Dĩa', 65000, 65000, 65000, 65000, '', 0, 1),
(221, 16, 'Bò nướng lụi', 'nướng lụi', 'Dĩa', 65000, 65000, 65000, 65000, '', 0, 1),
(227, 13, 'Lẩu cá bốp', 'cá bốp', 'Cái', 130000, 130000, 130000, 130000, '', 25, 1),
(230, 19, 'Gỏi điên điển hải sản', 'điên điển hải sản', 'Dĩa', 65000, 65000, 65000, 65000, '', 0, 1),
(231, 8, 'Đầu cá hồi', 'Đầu cá hồi', 'Dĩa', 0, 0, 0, 0, '', 0, 1),
(232, 15, 'Nghêu hấp sả', 'Nghêu hấp sả', 'Dĩa', 30000, 30000, 30000, 30000, '', 0, 1),
(233, 15, 'Sò lông hấp sả', 'Sò lông hấp sả', 'Dĩa', 35000, 35000, 35000, 35000, '', 0, 1),
(234, 15, 'Sò lông nướng mỡ hành', 'Sò lông nướng mỡ hành', 'Dĩa', 40000, 40000, 40000, 40000, '', 0, 1),
(235, 21, 'Hàu nướng phô mai', 'Hàu n. phô mai', 'Cái', 18000, 18000, 18000, 18000, '', 0, 1),
(236, 21, 'Hàu nướng mỡ hành', 'Hàu n, mỡ hành', 'Cái', 18000, 18000, 18000, 18000, '', 0, 1),
(237, 21, 'Hàu nướng tái chanh', 'Hàu n. tái chanh', 'Cái', 18000, 18000, 18000, 18000, '', 0, 1),
(238, 21, 'Tôm nướng muối ớt', 'Tôm n. muối ớt', 'Dĩa', 58000, 58000, 58000, 58000, '', 0, 1),
(239, 21, 'Tôm nướng sa tế', 'Tôm n. sa tế', 'Dĩa', 58000, 58000, 58000, 58000, '', 0, 1),
(240, 21, 'Tôm nướng mọi', 'Tôm nướng mọi', 'Dĩa', 58000, 58000, 58000, 58000, '', 0, 1),
(242, 22, 'Gà muối ớt chanh', 'Gà muối ớt chanh', 'Bịch', 200000, 200000, 200000, 200000, '', 0, 0),
(243, 22, 'Bánh bao Tài Có', 'Bánh bao Tài Có', 'Cái', 20000, 20000, 20000, 20000, '', 0, 0),
(246, 22, 'Chim cút', 'Chim cút', 'Bịch', 20000, 20000, 20000, 20000, '', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_course_log`
--

CREATE TABLE IF NOT EXISTS `tbl_course_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_table` int(11) NOT NULL,
  `id_course` int(11) NOT NULL,
  `date_time` datetime NOT NULL,
  `count` int(11) NOT NULL,
  `state` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `tbl_course_log`
--

INSERT INTO `tbl_course_log` (`id`, `id_table`, `id_course`, `date_time`, `count`, `state`) VALUES
(16, 1, 227, '2013-12-24 17:09:38', 1, 2),
(17, 1, 161, '2013-12-24 17:10:15', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_customer`
--

CREATE TABLE IF NOT EXISTS `tbl_customer` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  `card` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `discount` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=13 ;

--
-- Dumping data for table `tbl_customer`
--

INSERT INTO `tbl_customer` (`id`, `name`, `type`, `card`, `phone`, `address`, `note`, `discount`) VALUES
(1, 'KHÁCH VÃNG LAI', 0, '1', '', '', '', 0),
(12, 'Nguyễn Văn A', 1, '2', '0919 111 222', 'Vĩnh Long', '', 5);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_domain`
--

CREATE TABLE IF NOT EXISTS `tbl_domain` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `tbl_domain`
--

INSERT INTO `tbl_domain` (`id`, `name`) VALUES
(1, 'PHÒNG LẠNH'),
(2, 'SÂN VƯỜN'),
(3, 'KHU NHÀ');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_employee`
--

CREATE TABLE IF NOT EXISTS `tbl_employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `job` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `gender` tinyint(2) NOT NULL,
  `phone` varchar(13) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `salary_base` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Dumping data for table `tbl_employee`
--

INSERT INTO `tbl_employee` (`id`, `name`, `job`, `gender`, `phone`, `address`, `salary_base`) VALUES
(1, 'Nguyễn Văn A', 'Bảo vệ', 0, '0946 111 222', 'P4 - Vĩnh Long', 2000000),
(2, 'Nguyễn Văn B', 'Phục vụ', 0, '0932502838', 'Châu Thành, Đồng Tháp', 3000000),
(3, 'Nguyễn Văn C', 'Phục vụ', 0, '0', 'Sóc Trăng', 0),
(4, 'Nguyễn Văn D', 'Phục vụ', 1, '', 'Châu Thành, Đồng Tháp', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_guest`
--

CREATE TABLE IF NOT EXISTS `tbl_guest` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(16) CHARACTER SET latin1 NOT NULL,
  `entry_time` varchar(32) CHARACTER SET latin1 NOT NULL,
  `exit_time` varchar(32) CHARACTER SET latin1 NOT NULL,
  `agent` varchar(16) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=150 ;

--
-- Dumping data for table `tbl_guest`
--

INSERT INTO `tbl_guest` (`id`, `ip`, `entry_time`, `exit_time`, `agent`) VALUES
(149, '115.78.94.118', '1383319305', '1383322905', '115.78.94.118');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_notify`
--

CREATE TABLE IF NOT EXISTS `tbl_notify` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  `message` varchar(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `tbl_notify`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_order_import`
--

CREATE TABLE IF NOT EXISTS `tbl_order_import` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idsupplier` int(11) NOT NULL,
  `date` date NOT NULL,
  `description` varchar(50) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_order_import_1` (`idsupplier`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=350 ;

--
-- Dumping data for table `tbl_order_import`
--

INSERT INTO `tbl_order_import` (`id`, `idsupplier`, `date`, `description`) VALUES
(347, 9, '2013-11-01', 'Nhập hàng'),
(348, 8, '2013-12-04', ''),
(349, 8, '2013-11-01', '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order_import_detail`
--

CREATE TABLE IF NOT EXISTS `tbl_order_import_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idorder` int(11) NOT NULL,
  `idresource` int(11) NOT NULL,
  `count` float NOT NULL,
  `price` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_order_import_detail_1` (`idorder`),
  KEY `tbl_order_import_detail_2` (`idresource`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=636 ;

--
-- Dumping data for table `tbl_order_import_detail`
--

INSERT INTO `tbl_order_import_detail` (`id`, `idorder`, `idresource`, `count`, `price`) VALUES
(629, 347, 35, 2, 160000),
(630, 347, 36, 4, 185000),
(631, 347, 39, 3, 150000),
(632, 347, 40, 2, 120000),
(633, 347, 43, 2, 180000),
(634, 348, 19, 20, 150000),
(635, 349, 19, 1, 150000);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_paid_customer`
--

CREATE TABLE IF NOT EXISTS `tbl_paid_customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idcustomer` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_customer_paid_1` (`idcustomer`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=19 ;

--
-- Dumping data for table `tbl_paid_customer`
--

INSERT INTO `tbl_paid_customer` (`id`, `idcustomer`, `date`, `value`, `note`) VALUES
(18, 1, '2013-05-16', 1, '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_paid_employee`
--

CREATE TABLE IF NOT EXISTS `tbl_paid_employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_employee` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(150) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_employee` (`id_employee`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `tbl_paid_employee`
--

INSERT INTO `tbl_paid_employee` (`id`, `id_employee`, `date`, `value`, `note`) VALUES
(1, 1, '2013-10-05', 100000, 'Ứng đợt 2'),
(2, 1, '2013-10-01', 200000, 'Ứng đợt 1');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_paid_general`
--

CREATE TABLE IF NOT EXISTS `tbl_paid_general` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_term` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_paid_1` (`id_term`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=167 ;

--
-- Dumping data for table `tbl_paid_general`
--

INSERT INTO `tbl_paid_general` (`id`, `id_term`, `date`, `value`, `note`) VALUES
(9, 10, '2013-04-01', 157000, 'Chi tiền chợ'),
(10, 10, '2013-04-02', 146000, 'Tiền chợ'),
(11, 10, '2013-04-03', 189000, 'Tiền chợ'),
(12, 10, '2013-04-04', 184000, 'Tiền chợ'),
(20, 11, '2013-04-06', 163000, 'Chi mua đồ điện '),
(21, 11, '2013-12-04', 250000, 'Mua CB'),
(22, 11, '2013-04-07', 57000, 'Trái cây cúng+bao kiếng trái cây'),
(66, 2, '2013-04-30', 2100000, 'Tạm tính'),
(111, 3, '2013-07-31', 1500000, 'Thuế TTĐB Tháng 07'),
(112, 1, '2013-07-31', 4000000, 'Tiền điện T07'),
(113, 2, '2013-07-31', 2000000, 'Tiền nước T07'),
(155, 3, '2013-08-31', 800000, 'Thuế TTĐB T08'),
(156, 3, '2013-09-30', 850000, 'Thuế TTĐB T09'),
(158, 1, '2013-08-31', 5800000, 'Tiền điện T08'),
(159, 1, '2013-09-30', 3700000, 'Tiền điện T09'),
(160, 2, '2013-08-31', 2200000, 'Tiền nước T08'),
(161, 2, '2013-09-30', 2300000, 'Tiền nước T09'),
(163, 1, '2013-05-31', 4700000, 'Tiền điện T05'),
(164, 1, '2013-06-30', 3900000, 'Tiền điện T06'),
(165, 2, '2013-05-31', 2350000, 'Tiền nước T05'),
(166, 2, '2013-06-30', 2260000, 'Tiền nước T06');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_paid_pay_roll`
--

CREATE TABLE IF NOT EXISTS `tbl_paid_pay_roll` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_employee` int(11) NOT NULL,
  `date` date NOT NULL,
  `value_base` int(11) NOT NULL,
  `value_sub` int(11) NOT NULL,
  `value_pre` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_paid_pay_roll_1` (`id_employee`),
  KEY `id_employee` (`id_employee`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tbl_paid_pay_roll`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_paid_supplier`
--

CREATE TABLE IF NOT EXISTS `tbl_paid_supplier` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idsupplier` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_supplier_paid_1` (`idsupplier`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=18 ;

--
-- Dumping data for table `tbl_paid_supplier`
--

INSERT INTO `tbl_paid_supplier` (`id`, `idsupplier`, `date`, `value`, `note`) VALUES
(1, 1, '2012-08-01', 2300000, 'được không ?'),
(2, 1, '2012-07-03', 350000, 'Ghi chú gì đây'),
(3, 1, '2012-07-26', 750000, 'Ghi ghi gì gì đó'),
(8, 6, '2012-09-19', 1000000, 'Thử nè được không đó !'),
(9, 1, '2012-09-19', 1000000, 'lung tung quá đi'),
(11, 1, '2012-01-01', 123, 'sdfdsfggf'),
(12, 1, '2012-09-24', 1230000, 'đâu biết'),
(13, 1, '2012-09-24', 1213232, ''),
(14, 1, '2012-09-24', 34243243, ''),
(15, 1, '2012-09-24', 21323, ''),
(16, 1, '2012-09-24', 123323, ''),
(17, 1, '2012-09-24', 21323, '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_pay_roll`
--

CREATE TABLE IF NOT EXISTS `tbl_pay_roll` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_employee` int(11) NOT NULL,
  `date` date NOT NULL,
  `state` int(11) NOT NULL,
  `extra` int(11) NOT NULL,
  `late` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_employee` (`id_employee`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=63 ;

--
-- Dumping data for table `tbl_pay_roll`
--

INSERT INTO `tbl_pay_roll` (`id`, `id_employee`, `date`, `state`, `extra`, `late`) VALUES
(1, 1, '2013-10-01', 0, 0, 0),
(2, 1, '2013-10-02', 1, 0, 0),
(3, 1, '2013-10-03', 1, 0, 0),
(4, 1, '2013-10-04', 1, 0, 0),
(5, 1, '2013-10-05', 1, 0, 0),
(6, 1, '2013-10-06', 1, 0, 0),
(7, 1, '2013-10-07', 1, 0, 0),
(8, 1, '2013-10-08', 1, 0, 0),
(9, 1, '2013-10-09', 1, 0, 0),
(10, 1, '2013-10-10', 1, 0, 0),
(11, 1, '2013-10-11', 1, 0, 0),
(12, 1, '2013-10-12', 1, 0, 0),
(13, 1, '2013-10-13', 1, 0, 0),
(14, 1, '2013-10-14', 1, 0, 0),
(15, 1, '2013-10-31', 1, 0, 0),
(16, 1, '2013-10-30', 1, 0, 0),
(17, 1, '2013-10-15', 1, 0, 0),
(18, 1, '2013-10-16', 1, 0, 0),
(19, 1, '2013-10-17', 1, 0, 0),
(20, 1, '2013-10-18', 1, 0, 0),
(21, 1, '2013-10-19', 1, 0, 0),
(22, 1, '2013-10-25', 1, 0, 0),
(23, 1, '2013-10-27', 1, 0, 0),
(24, 1, '2013-10-24', 1, 0, 0),
(25, 1, '2013-10-21', 1, 0, 0),
(26, 1, '2013-10-20', 1, 0, 0),
(27, 1, '2013-10-23', 1, 0, 0),
(28, 1, '2013-10-22', 1, 0, 0),
(29, 1, '2013-10-26', 1, 0, 0),
(30, 1, '2013-10-28', 1, 0, 0),
(31, 1, '2013-10-29', 1, 0, 0),
(32, 2, '2013-10-01', 1, 0, 0),
(33, 2, '2013-10-02', 1, 0, 0),
(34, 2, '2013-10-03', 1, 0, 0),
(35, 2, '2013-10-04', 1, 0, 0),
(36, 2, '2013-10-05', 1, 0, 0),
(37, 2, '2013-10-06', 1, 0, 0),
(38, 2, '2013-10-07', 1, 0, 0),
(39, 2, '2013-10-08', 1, 0, 0),
(40, 2, '2013-10-09', 1, 0, 0),
(41, 2, '2013-10-10', 1, 0, 0),
(42, 2, '2013-10-11', 1, 0, 0),
(43, 2, '2013-10-12', 1, 0, 0),
(44, 2, '2013-10-13', 1, 0, 0),
(45, 2, '2013-10-14', 1, 0, 0),
(46, 2, '2013-10-15', 1, 0, 0),
(47, 2, '2013-10-16', 1, 0, 0),
(48, 2, '2013-10-17', 1, 0, 0),
(49, 2, '2013-10-18', 1, 0, 0),
(50, 2, '2013-10-19', 1, 0, 0),
(51, 2, '2013-10-20', 1, 0, 0),
(52, 2, '2013-10-21', 1, 0, 0),
(53, 2, '2013-10-22', 1, 0, 0),
(54, 2, '2013-10-23', 1, 0, 0),
(55, 2, '2013-10-24', 1, 0, 0),
(56, 2, '2013-10-25', 1, 0, 0),
(57, 2, '2013-10-26', 1, 0, 0),
(58, 2, '2013-10-27', 1, 0, 0),
(59, 2, '2013-10-28', 1, 0, 0),
(60, 2, '2013-10-29', 1, 0, 0),
(61, 2, '2013-10-30', 1, 0, 0),
(62, 2, '2013-10-31', 1, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_r2c`
--

CREATE TABLE IF NOT EXISTS `tbl_r2c` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_course` int(11) NOT NULL,
  `id_resource` int(11) NOT NULL,
  `value1` double NOT NULL,
  `value2` double NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_r2c_1` (`id_course`),
  KEY `tbl_r2c_2` (`id_resource`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=158 ;

--
-- Dumping data for table `tbl_r2c`
--

INSERT INTO `tbl_r2c` (`id`, `id_course`, `id_resource`, `value1`, `value2`) VALUES
(156, 239, 19, 1, 4),
(157, 240, 19, 1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_resource`
--

CREATE TABLE IF NOT EXISTS `tbl_resource` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `idsupplier` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `unit` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `price` int(10) NOT NULL,
  `description` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_resource_1` (`idsupplier`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=102 ;

--
-- Dumping data for table `tbl_resource`
--

INSERT INTO `tbl_resource` (`id`, `idsupplier`, `name`, `unit`, `price`, `description`) VALUES
(2, 1, 'Đá viên lớn', 'Kg', 800, 'Nước đá cưa - Bao 20kg'),
(14, 1, 'Nước đá ướp', 'Kg', 800, 'Đá cây ướp bia'),
(17, 6, 'Bánh', 'Gói', 5000, ''),
(19, 8, 'Tôm loại 1', 'Kg', 150000, ''),
(20, 8, 'Tôm loại 2', 'Kg', 120000, ''),
(27, 6, 'Xúc xích', 'Gói', 17000, ''),
(35, 9, 'Trà xanh 0 độ', 'Thùng', 160000, 'Thùng 24 chai 500ml'),
(36, 9, 'Dr Thanh', 'Thùng', 185000, 'Thùng 24 chai 370 ml'),
(39, 9, 'Pepsi', 'Thùng', 150000, 'Thùng 24 lon 330 ml'),
(40, 9, 'Mirinda Cam', 'Thùng', 120000, 'Thùng 24 lon 330ml'),
(43, 9, 'Sting đỏ', 'Thùng', 180000, 'Thùng 24 lon 330ml'),
(47, 12, 'Ổi', 'Kg', 9000, ''),
(48, 12, 'Củ sắn', 'Kg', 15000, ''),
(49, 12, 'Mít', 'Kg', 18000, ''),
(50, 12, 'Chôm chôm', 'Kg', 10000, ''),
(51, 12, 'Xoài Thái', 'Kg', 15000, ''),
(52, 12, 'Xoài Đài Loan', 'Kg', 15000, ''),
(53, 12, 'Xoài chua', 'Kg', 15000, ''),
(54, 12, 'Mận', 'Kg', 10000, ''),
(55, 12, 'Sơ ri', 'Kg', 12000, ''),
(56, 12, 'Thơm', 'Kg', 12000, ''),
(57, 12, 'Khóm', 'Kg', 10000, ''),
(79, 12, 'Dưa hấu', 'Kg', 10000, ''),
(82, 12, 'Táo', 'Kg', 10000, ''),
(84, 12, 'Cóc', 'Kg', 6000, ''),
(91, 1, 'Đá ống viên lớn', 'Kg', 800, 'Bao 20kg'),
(99, 12, 'Bưởi', 'Kg', 10000, ''),
(101, 8, 'Tôm loại 3', 'Kg', 100000, '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_session`
--

CREATE TABLE IF NOT EXISTS `tbl_session` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idtable` int(11) NOT NULL,
  `iduser` int(11) NOT NULL,
  `idcustomer` int(11) NOT NULL,
  `idemployee` int(11) NOT NULL,
  `datetime` datetime NOT NULL,
  `datetimeend` datetime DEFAULT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  `discount_value` int(11) NOT NULL,
  `discount_percent` int(11) NOT NULL,
  `surtax` int(11) NOT NULL,
  `payment` int(11) NOT NULL,
  `value` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idtable` (`idtable`),
  KEY `iduser` (`iduser`),
  KEY `tbl_session_3` (`idcustomer`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=30 ;

--
-- Dumping data for table `tbl_session`
--

INSERT INTO `tbl_session` (`id`, `idtable`, `iduser`, `idcustomer`, `idemployee`, `datetime`, `datetimeend`, `note`, `status`, `discount_value`, `discount_percent`, `surtax`, `payment`, `value`) VALUES
(3, 1, 1, 1, 0, '2013-11-12 15:17:53', '2013-11-12 15:17:53', '', 1, 0, 0, 0, 0, 0),
(4, 1, 1, 1, 0, '2013-11-20 00:11:16', '2013-11-20 00:11:16', '', 1, 0, 0, 0, 0, 0),
(6, 4, 1, 1, 0, '2013-11-27 01:08:44', '2013-11-27 01:08:44', '', 1, 0, 0, 0, 0, 0),
(8, 4, 1, 1, 0, '2013-11-27 10:16:40', '2013-11-27 10:16:40', '', 1, 0, 0, 0, 0, 0),
(9, 1, 1, 1, 0, '2013-11-27 10:32:31', '2013-11-27 10:32:31', '', 1, 0, 0, 0, 0, 0),
(10, 2, 1, 1, 0, '2013-12-04 03:55:12', '2013-12-04 03:55:12', '', 1, 0, 0, 0, 0, 0),
(11, 2, 1, 1, 0, '2013-12-05 00:06:33', '2013-12-05 00:06:33', '', 1, 0, 0, 0, 0, 0),
(12, 2, 1, 1, 0, '2013-12-05 23:48:36', '2013-12-05 23:48:36', '', 1, 0, 0, 0, 0, 0),
(13, 14, 1, 1, 0, '2013-12-06 18:10:58', '2013-12-06 18:10:58', '', 1, 0, 0, 0, 0, 0),
(14, 1, 1, 1, 0, '2013-12-06 22:40:58', '2013-12-06 22:40:58', '', 1, 0, 10, 0, 0, 0),
(15, 2, 1, 1, 0, '2013-12-07 01:47:45', '2013-12-07 01:47:45', '', 1, 0, 0, 0, 0, 0),
(16, 3, 1, 1, 0, '2013-12-09 19:38:18', '2013-12-09 19:38:18', '', 1, 0, 0, 0, 0, 0),
(17, 15, 1, 12, 0, '2013-12-09 19:38:42', '2013-12-09 19:38:42', '', 1, 0, 5, 0, 0, 0),
(18, 33, 1, 1, 0, '2013-12-09 19:45:29', '2013-12-09 19:45:29', '', 1, 0, 0, 0, 0, 0),
(19, 32, 1, 1, 0, '2013-12-09 19:47:30', '2013-12-09 19:47:30', '', 1, 0, 0, 0, 0, 0),
(20, 4, 1, 1, 0, '2013-12-09 21:47:38', '2013-12-09 21:47:38', '', 1, 0, 0, 0, 0, 0),
(21, 1, 1, 1, 0, '2013-12-17 11:07:47', '2013-12-17 11:07:47', '', 1, 0, 0, 0, 0, 0),
(22, 1, 1, 1, 0, '2013-12-18 17:43:12', '2013-12-18 17:43:12', '', 1, 0, 0, 0, 0, 0),
(23, 14, 1, 1, 0, '2013-12-18 17:43:20', '2013-12-18 17:43:20', '', 0, 0, 0, 0, 0, 0),
(24, 2, 1, 12, 0, '2013-12-22 14:41:34', '2013-12-22 14:41:34', '', 1, 0, 10, 0, 0, 0),
(25, 2, 1, 1, 4, '2013-12-24 06:09:17', '2013-12-24 06:09:17', '', 1, 0, 0, 0, 0, 0),
(26, 3, 1, 1, 0, '2013-12-24 06:11:53', '2013-12-24 06:11:54', '', 1, 0, 0, 0, 0, 0),
(27, 1, 1, 1, 1, '2013-12-24 16:20:15', '2013-12-24 16:20:15', '', 1, 0, 0, 0, 0, 0),
(28, 2, 1, 1, 1, '2013-12-24 16:33:59', '2013-12-24 16:33:59', '', 1, 0, 0, 0, 0, 0),
(29, 1, 1, 1, 1, '2013-12-24 17:09:38', '2013-12-24 17:09:38', '', 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_session_detail`
--

CREATE TABLE IF NOT EXISTS `tbl_session_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idsession` int(11) NOT NULL,
  `idcourse` int(11) NOT NULL,
  `count` float NOT NULL,
  `price` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idsession` (`idsession`),
  KEY `idcourse` (`idcourse`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=84 ;

--
-- Dumping data for table `tbl_session_detail`
--

INSERT INTO `tbl_session_detail` (`id`, `idsession`, `idcourse`, `count`, `price`) VALUES
(6, 3, 197, 3, 16000),
(7, 4, 165, 2, 12000),
(8, 4, 220, 3, 65000),
(11, 6, 187, 12, 11000),
(15, 6, 169, 3, 55000),
(17, 8, 187, 11, 11000),
(19, 9, 239, 1, 58000),
(20, 10, 239, 2, 58000),
(21, 11, 240, 1, 58000),
(23, 12, 238, 2, 58000),
(24, 12, 187, 4, 11000),
(25, 12, 165, 1, 85000),
(26, 13, 55, 2, 200000),
(27, 13, 187, 20, 11000),
(28, 14, 187, 20, 11000),
(29, 14, 227, 1, 130000),
(30, 14, 111, 1, 320000),
(31, 15, 110, 0.5, 200000),
(32, 15, 218, 6, 70000),
(33, 14, 188, 1, 16000),
(34, 15, 127, 1, 0),
(35, 16, 214, 3, 30000),
(36, 16, 216, 2, 60000),
(37, 17, 55, 1, 0),
(38, 17, 54, 0.7, 200000),
(39, 18, 187, 1, 11000),
(40, 18, 197, 2, 60000),
(41, 18, 169, 1, 55000),
(42, 19, 165, 1, 85000),
(43, 16, 213, 1, 60000),
(44, 15, 214, 1, 30000),
(45, 20, 213, 1, 60000),
(46, 20, 214, 1, 30000),
(47, 21, 187, 7, 11000),
(49, 21, 197, 1, 60000),
(50, 21, 242, 1, 200000),
(51, 21, 243, 3, 20000),
(52, 21, 115, 1, 12000),
(53, 21, 218, 1, 70000),
(54, 20, 188, 1, 16000),
(55, 21, 186, 3, 11000),
(56, 22, 227, 3, 130000),
(57, 23, 163, 1, 98000),
(58, 19, 227, 1, 130000),
(59, 22, 15, 21, 13000),
(60, 22, 186, 1, 11000),
(61, 22, 161, 2, 105000),
(62, 22, 163, 1, 98000),
(63, 22, 55, 1, 0),
(64, 24, 243, 10, 20000),
(65, 24, 242, 1, 200000),
(66, 24, 187, 10, 11000),
(67, 24, 246, 1, 20000),
(68, 22, 187, 3, 11000),
(69, 25, 187, 1, 11000),
(70, 26, 243, 1, 20000),
(71, 26, 169, 1, 55000),
(72, 25, 227, 3, 130000),
(73, 26, 227, 2, 130000),
(74, 25, 161, 1, 105000),
(75, 25, 163, 1, 98000),
(76, 25, 149, 1, 105000),
(77, 27, 227, 2, 130000),
(78, 27, 161, 1, 105000),
(79, 28, 227, 1, 130000),
(80, 27, 162, 1, 135000),
(81, 27, 163, 1, 98000),
(82, 29, 227, 1, 130000),
(83, 29, 161, 1, 105000);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_store`
--

CREATE TABLE IF NOT EXISTS `tbl_store` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(125) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_store`
--

INSERT INTO `tbl_store` (`id`, `name`, `note`) VALUES
(1, 'Kho nhà', 'Ghi chú gì đây ?');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_supplier`
--

CREATE TABLE IF NOT EXISTS `tbl_supplier` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `debt` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=13 ;

--
-- Dumping data for table `tbl_supplier`
--

INSERT INTO `tbl_supplier` (`id`, `name`, `phone`, `address`, `note`, `debt`) VALUES
(1, 'ĐL NƯỚC ĐÁ', '0703 11 22 33', 'Phường 4', 'Cung cấp nước đá', 0),
(6, 'Siêu thị COOP MART', 'chưa cập nhật', 'Vĩnh Long', '', 0),
(8, 'Đại lý hải sản', '0703 111 222', 'Rạch Giá', '', 0),
(9, 'ĐL Nước ngọt', '', '', '', 0),
(12, 'VỰA TRÁI CÂY', '', '', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_table`
--

CREATE TABLE IF NOT EXISTS `tbl_table` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iddomain` int(11) NOT NULL,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `iduser` int(11) DEFAULT NULL,
  `type` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `iddomain` (`iddomain`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=34 ;

--
-- Dumping data for table `tbl_table`
--

INSERT INTO `tbl_table` (`id`, `iddomain`, `name`, `iduser`, `type`) VALUES
(1, 1, 'PL01', 1, '0'),
(2, 1, 'PL02', 1, '0'),
(3, 1, 'PL03', 1, '0'),
(4, 1, 'PL04', 1, '0'),
(14, 2, 'SV01', 1, '0'),
(15, 2, 'SV02', 1, '0'),
(16, 2, 'SV03', 1, '0'),
(17, 2, 'SV04', 1, '0'),
(26, 3, 'KN01', 1, '0'),
(27, 3, 'KN02', 1, '0'),
(28, 3, 'KN03', 1, '0'),
(29, 3, 'KN04', 1, '0'),
(30, 3, 'KN05', 1, '0'),
(31, 3, 'KN06', 1, '0'),
(32, 3, 'KN07', 1, '0'),
(33, 3, 'KN08', 1, '0');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_term`
--

CREATE TABLE IF NOT EXISTS `tbl_term` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=12 ;

--
-- Dumping data for table `tbl_term`
--

INSERT INTO `tbl_term` (`id`, `name`, `type`) VALUES
(1, 'Tiền Điện', 0),
(2, 'Tiền Nước', 0),
(3, 'Thuế', 0),
(10, 'Tiền Ăn Nhân Viên', 0),
(11, 'CP Khác', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_term_collect`
--

CREATE TABLE IF NOT EXISTS `tbl_term_collect` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `tbl_term_collect`
--

INSERT INTO `tbl_term_collect` (`id`, `name`) VALUES
(2, 'Phụ Phẩm'),
(3, 'Đặc Biệt');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tracking`
--

CREATE TABLE IF NOT EXISTS `tbl_tracking` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_start` date NOT NULL,
  `date_end` date NOT NULL,
  `paid_general` int(11) NOT NULL,
  `paid_pay_roll` int(11) NOT NULL,
  `paid_import` int(11) NOT NULL,
  `collect_general` int(11) NOT NULL,
  `collect_customer` int(11) NOT NULL,
  `collect_selling_debt` int(11) NOT NULL,
  `collect_selling_nodebt` int(11) NOT NULL,
  `estate_rate` int(11) NOT NULL,
  `store_value` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=15 ;

--
-- Dumping data for table `tbl_tracking`
--

INSERT INTO `tbl_tracking` (`id`, `date_start`, `date_end`, `paid_general`, `paid_pay_roll`, `paid_import`, `collect_general`, `collect_customer`, `collect_selling_debt`, `collect_selling_nodebt`, `estate_rate`, `store_value`) VALUES
(10, '2013-10-01', '2013-10-31', 0, 0, 0, 0, 0, 0, 0, 0, 0),
(11, '2013-11-01', '2013-11-30', 0, 0, 0, 0, 0, 0, 0, 0, 0),
(12, '2013-12-01', '2013-12-31', 0, 0, 0, 0, 0, 0, 0, 0, 0),
(13, '2014-01-01', '2014-01-31', 0, 0, 0, 0, 0, 0, 0, 0, 0),
(14, '2014-02-01', '2014-02-28', 0, 0, 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tracking_course`
--

CREATE TABLE IF NOT EXISTS `tbl_tracking_course` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tracking` int(11) NOT NULL,
  `id_td` int(11) NOT NULL,
  `id_course` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `value` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=217 ;

--
-- Dumping data for table `tbl_tracking_course`
--

INSERT INTO `tbl_tracking_course` (`id`, `id_tracking`, `id_td`, `id_course`, `count`, `price`, `value`) VALUES
(185, 12, 66, 187, 4, 0, 0),
(186, 12, 66, 165, 1, 0, 0),
(187, 12, 66, 240, 1, 0, 0),
(188, 12, 66, 238, 2, 0, 0),
(189, 12, 65, 239, 2, 0, 0),
(198, 12, 83, 187, 10, 0, 0),
(199, 12, 83, 243, 10, 0, 0),
(200, 12, 83, 246, 1, 0, 0),
(201, 12, 83, 242, 1, 0, 0),
(212, 12, 67, 187, 40, 0, 0),
(213, 12, 67, 55, 2, 0, 0),
(214, 12, 67, 188, 1, 0, 0),
(215, 12, 67, 227, 1, 0, 0),
(216, 12, 67, 111, 1, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tracking_customer`
--

CREATE TABLE IF NOT EXISTS `tbl_tracking_customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tracking` int(11) NOT NULL,
  `id_customer` int(11) NOT NULL,
  `value_session1` int(11) NOT NULL,
  `value_session2` int(11) NOT NULL,
  `value_collect` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tbl_tracking_customer`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_tracking_daily`
--

CREATE TABLE IF NOT EXISTS `tbl_tracking_daily` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tracking` int(11) NOT NULL,
  `date` date NOT NULL,
  `selling` bigint(20) NOT NULL,
  `import` bigint(20) NOT NULL,
  `store` bigint(20) NOT NULL,
  `paid` bigint(20) NOT NULL,
  `collect` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=152 ;

--
-- Dumping data for table `tbl_tracking_daily`
--

INSERT INTO `tbl_tracking_daily` (`id`, `id_tracking`, `date`, `selling`, `import`, `store`, `paid`, `collect`) VALUES
(1, 10, '2013-10-01', 0, 0, 0, 0, 0),
(2, 10, '2013-10-02', 0, 0, 0, 0, 0),
(3, 10, '2013-10-03', 0, 0, 0, 0, 0),
(4, 10, '2013-10-04', 0, 0, 0, 0, 0),
(5, 10, '2013-10-05', 0, 0, 0, 0, 0),
(6, 10, '2013-10-06', 0, 0, 0, 0, 0),
(7, 10, '2013-10-07', 0, 0, 0, 0, 0),
(8, 10, '2013-10-08', 0, 0, 0, 0, 0),
(9, 10, '2013-10-09', 0, 0, 0, 0, 0),
(10, 10, '2013-10-10', 0, 0, 0, 0, 0),
(11, 10, '2013-10-11', 0, 0, 0, 0, 0),
(12, 10, '2013-10-12', 0, 0, 0, 0, 0),
(13, 10, '2013-10-13', 0, 0, 0, 0, 0),
(14, 10, '2013-10-14', 0, 0, 0, 0, 0),
(15, 10, '2013-10-15', 0, 0, 0, 0, 0),
(16, 10, '2013-10-16', 0, 0, 0, 0, 0),
(17, 10, '2013-10-17', 0, 0, 0, 0, 0),
(18, 10, '2013-10-18', 0, 0, 0, 0, 0),
(19, 10, '2013-10-19', 0, 0, 0, 0, 0),
(20, 10, '2013-10-20', 0, 0, 0, 0, 0),
(21, 10, '2013-10-21', 0, 0, 0, 0, 0),
(22, 10, '2013-10-22', 0, 0, 0, 0, 0),
(23, 10, '2013-10-23', 0, 0, 0, 0, 0),
(24, 10, '2013-10-24', 0, 0, 0, 0, 0),
(25, 10, '2013-10-25', 0, 0, 0, 0, 0),
(26, 10, '2013-10-26', 0, 0, 0, 0, 0),
(27, 10, '2013-10-27', 0, 0, 0, 0, 0),
(28, 10, '2013-10-28', 0, 0, 0, 0, 0),
(29, 10, '2013-10-29', 0, 0, 0, 0, 0),
(30, 10, '2013-10-30', 0, 0, 0, 0, 0),
(31, 10, '2013-10-31', 0, 0, 0, 0, 0),
(32, 11, '2013-11-01', 0, 0, 0, 0, 0),
(33, 11, '2013-11-02', 0, 0, 0, 0, 0),
(34, 11, '2013-11-03', 0, 0, 0, 0, 0),
(35, 11, '2013-11-04', 0, 0, 0, 0, 0),
(36, 11, '2013-11-05', 0, 0, 0, 0, 0),
(37, 11, '2013-11-06', 0, 0, 0, 0, 0),
(38, 11, '2013-11-07', 0, 0, 0, 0, 0),
(39, 11, '2013-11-08', 0, 0, 0, 0, 0),
(40, 11, '2013-11-09', 0, 0, 0, 0, 0),
(41, 11, '2013-11-10', 0, 0, 0, 0, 0),
(42, 11, '2013-11-11', 0, 0, 0, 0, 0),
(43, 11, '2013-11-12', 0, 0, 0, 0, 0),
(44, 11, '2013-11-13', 0, 0, 0, 0, 0),
(45, 11, '2013-11-14', 0, 0, 0, 0, 0),
(46, 11, '2013-11-15', 0, 0, 0, 0, 0),
(47, 11, '2013-11-16', 0, 0, 0, 0, 0),
(48, 11, '2013-11-17', 0, 0, 0, 0, 0),
(49, 11, '2013-11-18', 0, 0, 0, 0, 0),
(50, 11, '2013-11-19', 0, 0, 0, 0, 0),
(51, 11, '2013-11-20', 0, 0, 0, 0, 0),
(52, 11, '2013-11-21', 0, 0, 0, 0, 0),
(53, 11, '2013-11-22', 0, 0, 0, 0, 0),
(54, 11, '2013-11-23', 0, 0, 0, 0, 0),
(55, 11, '2013-11-24', 0, 0, 0, 0, 0),
(56, 11, '2013-11-25', 0, 0, 0, 0, 0),
(57, 11, '2013-11-26', 0, 0, 0, 0, 0),
(58, 11, '2013-11-27', 0, 0, 0, 0, 0),
(59, 11, '2013-11-28', 0, 0, 0, 0, 0),
(60, 11, '2013-11-29', 0, 0, 0, 0, 0),
(61, 11, '2013-11-30', 0, 0, 0, 0, 0),
(62, 12, '2013-12-01', 0, 0, 0, 0, 0),
(63, 12, '2013-12-02', 0, 0, 0, 0, 0),
(64, 12, '2013-12-03', 0, 0, 0, 0, 0),
(65, 12, '2013-12-04', 116000, 3000000, 3030000, 250000, 10000000),
(66, 12, '2013-12-05', 58000, 0, 0, 0, 0),
(67, 12, '2013-12-06', 1237000, 0, 105000, 0, 0),
(68, 12, '2013-12-07', 0, 0, 0, 0, 0),
(69, 12, '2013-12-08', 0, 0, 105000, 0, 0),
(70, 12, '2013-12-09', 0, 0, 0, 0, 0),
(71, 12, '2013-12-10', 0, 0, 0, 0, 0),
(72, 12, '2013-12-11', 0, 0, 0, 0, 0),
(73, 12, '2013-12-12', 0, 0, 0, 0, 0),
(74, 12, '2013-12-13', 0, 0, 0, 0, 0),
(75, 12, '2013-12-14', 0, 0, 0, 0, 0),
(76, 12, '2013-12-15', 0, 0, 0, 0, 0),
(77, 12, '2013-12-16', 0, 0, 105000, 0, 0),
(78, 12, '2013-12-17', 0, 0, 0, 0, 0),
(79, 12, '2013-12-18', 0, 0, 0, 0, 0),
(80, 12, '2013-12-19', 0, 0, 105000, 0, 0),
(81, 12, '2013-12-20', 0, 0, 0, 0, 0),
(82, 12, '2013-12-21', 0, 0, 0, 0, 0),
(83, 12, '2013-12-22', 519000, 0, 105000, 0, 0),
(84, 12, '2013-12-23', 0, 0, 105000, 0, 0),
(85, 12, '2013-12-24', 0, 0, 105000, 0, 0),
(86, 12, '2013-12-25', 0, 0, 105000, 0, 0),
(87, 12, '2013-12-26', 0, 0, 105000, 0, 0),
(88, 12, '2013-12-27', 0, 0, 0, 0, 0),
(89, 12, '2013-12-28', 0, 0, 0, 0, 0),
(90, 12, '2013-12-29', 0, 0, 0, 0, 0),
(91, 12, '2013-12-30', 0, 0, 0, 0, 0),
(92, 12, '2013-12-31', 0, 0, 0, 0, 0),
(93, 13, '2014-01-01', 0, 0, 0, 0, 0),
(94, 13, '2014-01-02', 0, 0, 0, 0, 0),
(95, 13, '2014-01-03', 0, 0, 0, 0, 0),
(96, 13, '2014-01-04', 0, 0, 0, 0, 0),
(97, 13, '2014-01-05', 0, 0, 0, 0, 0),
(98, 13, '2014-01-06', 0, 0, 0, 0, 0),
(99, 13, '2014-01-07', 0, 0, 0, 0, 0),
(100, 13, '2014-01-08', 0, 0, 0, 0, 0),
(101, 13, '2014-01-09', 0, 0, 0, 0, 0),
(102, 13, '2014-01-10', 0, 0, 0, 0, 0),
(103, 13, '2014-01-11', 0, 0, 0, 0, 0),
(104, 13, '2014-01-12', 0, 0, 0, 0, 0),
(105, 13, '2014-01-13', 0, 0, 0, 0, 0),
(106, 13, '2014-01-14', 0, 0, 0, 0, 0),
(107, 13, '2014-01-15', 0, 0, 0, 0, 0),
(108, 13, '2014-01-16', 0, 0, 0, 0, 0),
(109, 13, '2014-01-17', 0, 0, 0, 0, 0),
(110, 13, '2014-01-18', 0, 0, 0, 0, 0),
(111, 13, '2014-01-19', 0, 0, 0, 0, 0),
(112, 13, '2014-01-20', 0, 0, 0, 0, 0),
(113, 13, '2014-01-21', 0, 0, 0, 0, 0),
(114, 13, '2014-01-22', 0, 0, 0, 0, 0),
(115, 13, '2014-01-23', 0, 0, 0, 0, 0),
(116, 13, '2014-01-24', 0, 0, 0, 0, 0),
(117, 13, '2014-01-25', 0, 0, 0, 0, 0),
(118, 13, '2014-01-26', 0, 0, 0, 0, 0),
(119, 13, '2014-01-27', 0, 0, 0, 0, 0),
(120, 13, '2014-01-28', 0, 0, 0, 0, 0),
(121, 13, '2014-01-29', 0, 0, 0, 0, 0),
(122, 13, '2014-01-30', 0, 0, 0, 0, 0),
(123, 13, '2014-01-31', 0, 0, 0, 0, 0),
(124, 14, '2014-02-01', 0, 0, 0, 0, 0),
(125, 14, '2014-02-02', 0, 0, 0, 0, 0),
(126, 14, '2014-02-03', 0, 0, 0, 0, 0),
(127, 14, '2014-02-04', 0, 0, 0, 0, 0),
(128, 14, '2014-02-05', 0, 0, 0, 0, 0),
(129, 14, '2014-02-06', 0, 0, 0, 0, 0),
(130, 14, '2014-02-07', 0, 0, 0, 0, 0),
(131, 14, '2014-02-08', 0, 0, 0, 0, 0),
(132, 14, '2014-02-09', 0, 0, 0, 0, 0),
(133, 14, '2014-02-10', 0, 0, 0, 0, 0),
(134, 14, '2014-02-11', 0, 0, 0, 0, 0),
(135, 14, '2014-02-12', 0, 0, 0, 0, 0),
(136, 14, '2014-02-13', 0, 0, 0, 0, 0),
(137, 14, '2014-02-14', 0, 0, 0, 0, 0),
(138, 14, '2014-02-15', 0, 0, 0, 0, 0),
(139, 14, '2014-02-16', 0, 0, 0, 0, 0),
(140, 14, '2014-02-17', 0, 0, 0, 0, 0),
(141, 14, '2014-02-18', 0, 0, 0, 0, 0),
(142, 14, '2014-02-19', 0, 0, 0, 0, 0),
(143, 14, '2014-02-20', 0, 0, 0, 0, 0),
(144, 14, '2014-02-21', 0, 0, 0, 0, 0),
(145, 14, '2014-02-22', 0, 0, 0, 0, 0),
(146, 14, '2014-02-23', 0, 0, 0, 0, 0),
(147, 14, '2014-02-24', 0, 0, 0, 0, 0),
(148, 14, '2014-02-25', 0, 0, 0, 0, 0),
(149, 14, '2014-02-26', 0, 0, 0, 0, 0),
(150, 14, '2014-02-27', 0, 0, 0, 0, 0),
(151, 14, '2014-02-28', 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tracking_store`
--

CREATE TABLE IF NOT EXISTS `tbl_tracking_store` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tracking` int(11) NOT NULL,
  `id_td` int(11) NOT NULL,
  `id_resource` int(11) NOT NULL,
  `count_old` float NOT NULL,
  `count_import` float NOT NULL,
  `count_export` float NOT NULL,
  `price` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1895 ;

--
-- Dumping data for table `tbl_tracking_store`
--

INSERT INTO `tbl_tracking_store` (`id`, `id_tracking`, `id_td`, `id_resource`, `count_old`, `count_import`, `count_export`, `price`) VALUES
(1860, 11, 65, 19, 0, 1, 0.3, 150000),
(1874, 12, 65, 19, 0.7, 20, 0.5, 150000),
(1877, 12, 86, 19, 0.7, 0, 0, 150000),
(1878, 12, 87, 19, 0.7, 0, 0, 150000),
(1881, 12, 85, 19, 0.7, 0, 0, 150000),
(1882, 12, 83, 19, 0.7, 0, 0, 150000),
(1888, 12, 62, 19, 0, 0, 0, 150000),
(1889, 12, 64, 19, 0, 0, 0, 150000),
(1890, 12, 67, 19, 0.7, 0, 0, 150000),
(1891, 12, 69, 19, 0.7, 0, 0, 150000),
(1892, 12, 84, 19, 0.7, 0, 0, 150000),
(1893, 12, 80, 19, 0.7, 0, 0, 150000),
(1894, 12, 77, 19, 0.7, 0, 0, 150000);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_unit`
--

CREATE TABLE IF NOT EXISTS `tbl_unit` (
  `id` int(25) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=24 ;

--
-- Dumping data for table `tbl_unit`
--

INSERT INTO `tbl_unit` (`id`, `name`) VALUES
(1, 'Ly'),
(2, 'Điếu'),
(3, 'Chai'),
(4, 'Lon'),
(5, 'Dĩa'),
(6, 'Thùng'),
(7, 'Két'),
(9, 'Bịch'),
(10, 'Gói'),
(20, 'Trái'),
(21, 'Cái'),
(22, 'Hủ'),
(23, 'Kg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE IF NOT EXISTS `tbl_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pass` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gender` int(11) NOT NULL,
  `note` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `datecreate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dateupdate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `dateactivity` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `type` tinyint(4) NOT NULL,
  `code` varchar(13) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `name`, `email`, `pass`, `gender`, `note`, `datecreate`, `dateupdate`, `dateactivity`, `type`, `code`) VALUES
(1, 'Tuấn', 'tuanbuithanh@gmail.com', 'admin068368', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 4, ''),
(2, 'Thái', 'thai@gmail.com', '123456', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 4, '');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_collect_customer`
--
ALTER TABLE `tbl_collect_customer`
  ADD CONSTRAINT `tbl_customer_collect_1` FOREIGN KEY (`idcustomer`) REFERENCES `tbl_customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_collect_general`
--
ALTER TABLE `tbl_collect_general`
  ADD CONSTRAINT `tbl_collect_general_1` FOREIGN KEY (`id_term`) REFERENCES `tbl_term_collect` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_course`
--
ALTER TABLE `tbl_course`
  ADD CONSTRAINT `tbl_course_1` FOREIGN KEY (`idcategory`) REFERENCES `tbl_category` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_order_import`
--
ALTER TABLE `tbl_order_import`
  ADD CONSTRAINT `tbl_order_import_1` FOREIGN KEY (`idsupplier`) REFERENCES `tbl_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_order_import_detail`
--
ALTER TABLE `tbl_order_import_detail`
  ADD CONSTRAINT `tbl_order_import_detail_1` FOREIGN KEY (`idorder`) REFERENCES `tbl_order_import` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_order_import_detail_2` FOREIGN KEY (`idresource`) REFERENCES `tbl_resource` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_paid_customer`
--
ALTER TABLE `tbl_paid_customer`
  ADD CONSTRAINT `tbl_customer_paid_1` FOREIGN KEY (`idcustomer`) REFERENCES `tbl_customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_paid_employee`
--
ALTER TABLE `tbl_paid_employee`
  ADD CONSTRAINT `tbl_paid_employee_ibfk_1` FOREIGN KEY (`id_employee`) REFERENCES `tbl_employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_paid_general`
--
ALTER TABLE `tbl_paid_general`
  ADD CONSTRAINT `tbl_paid_general_1` FOREIGN KEY (`id_term`) REFERENCES `tbl_term` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_paid_pay_roll`
--
ALTER TABLE `tbl_paid_pay_roll`
  ADD CONSTRAINT `tbl_paid_pay_roll_ibfk_1` FOREIGN KEY (`id_employee`) REFERENCES `tbl_employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_paid_supplier`
--
ALTER TABLE `tbl_paid_supplier`
  ADD CONSTRAINT `tbl_supplier_paid_1` FOREIGN KEY (`idsupplier`) REFERENCES `tbl_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_pay_roll`
--
ALTER TABLE `tbl_pay_roll`
  ADD CONSTRAINT `tbl_pay_roll_ibfk_1` FOREIGN KEY (`id_employee`) REFERENCES `tbl_employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_r2c`
--
ALTER TABLE `tbl_r2c`
  ADD CONSTRAINT `tbl_r2c_1` FOREIGN KEY (`id_course`) REFERENCES `tbl_course` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_r2c_2` FOREIGN KEY (`id_resource`) REFERENCES `tbl_resource` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_resource`
--
ALTER TABLE `tbl_resource`
  ADD CONSTRAINT `tbl_resource_1` FOREIGN KEY (`idsupplier`) REFERENCES `tbl_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_session`
--
ALTER TABLE `tbl_session`
  ADD CONSTRAINT `tbl_session_1` FOREIGN KEY (`idtable`) REFERENCES `tbl_table` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_session_2` FOREIGN KEY (`iduser`) REFERENCES `tbl_user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_session_3` FOREIGN KEY (`idcustomer`) REFERENCES `tbl_customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_session_detail`
--
ALTER TABLE `tbl_session_detail`
  ADD CONSTRAINT `tbl_session_detail_1` FOREIGN KEY (`idsession`) REFERENCES `tbl_session` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_session_detail_2` FOREIGN KEY (`idcourse`) REFERENCES `tbl_course` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_table`
--
ALTER TABLE `tbl_table`
  ADD CONSTRAINT `tbl_table_1` FOREIGN KEY (`iddomain`) REFERENCES `tbl_domain` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
