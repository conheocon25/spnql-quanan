-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 24, 2014 at 06:29 PM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `qlquanan_langbien`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_app`
--

CREATE TABLE IF NOT EXISTS `tbl_app` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(125) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(50) CHARACTER SET utf8 NOT NULL,
  `banner` varchar(125) CHARACTER SET utf8 NOT NULL,
  `prefix` varchar(50) CHARACTER SET utf8 NOT NULL,
  `alias` varchar(256) CHARACTER SET utf8 NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_activity` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `type` tinyint(4) NOT NULL,
  `page_view` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_app`
--

INSERT INTO `tbl_app` (`id`, `name`, `phone`, `address`, `email`, `banner`, `prefix`, `alias`, `date_created`, `date_modified`, `date_activity`, `type`, `page_view`) VALUES
(1, 'Karaoke Ba Đức', '0945 03 07 09', 'Phó Cơ Điều P3 - TPVL', '', 'data/images/banner/logo.png', 'tbl_', 'tbl_', '2012-06-30 17:00:00', '0000-00-00 00:00:00', '2012-12-26 07:28:02', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

CREATE TABLE IF NOT EXISTS `tbl_category` (
  `id` int(25) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `picture` binary(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=50 ;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`id`, `name`, `picture`) VALUES
(11, 'BIA', NULL),
(37, 'Rượu', NULL),
(38, 'CÁNH, CHÂN GÀ, ẾCH', NULL),
(40, 'GÀ TA', NULL),
(41, 'ĐẶC BIỆT', NULL),
(42, 'CHÁO, MÌ, CƠM, LẨU', NULL),
(43, 'CUA GẠCH, GHẸ', NULL),
(44, 'NGHÊU, SÒ, HÀU', NULL),
(45, 'RAU, GỎI, CHIÊN', NULL),
(46, 'BÒ, TÔM,  MỰC', NULL),
(47, 'HẢI SẢN', NULL),
(48, 'KHĂN, ĐẬU', NULL),
(49, 'GỌI THÊM', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_collect_customer`
--

CREATE TABLE IF NOT EXISTS `tbl_collect_customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idcustomer` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_customer_collect_1` (`idcustomer`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tbl_collect_customer`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_collect_general`
--

CREATE TABLE IF NOT EXISTS `tbl_collect_general` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_term` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_collect_1` (`id_term`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

--
-- Dumping data for table `tbl_collect_general`
--

INSERT INTO `tbl_collect_general` (`id`, `id_term`, `date`, `value`, `note`) VALUES
(6, 3, '2013-12-04', 10000000, 'Bổ sung tiền quỹ');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_config`
--

CREATE TABLE IF NOT EXISTS `tbl_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `param` varchar(125) COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=10 ;

--
-- Dumping data for table `tbl_config`
--

INSERT INTO `tbl_config` (`id`, `param`, `value`) VALUES
(5, 'DISCOUNT', '0'),
(6, 'ROW_PER_PAGE', '12'),
(7, 'GUEST_VISIT', '9247'),
(8, 'EVERY_5_MINUTES', '2000'),
(9, 'CATEGORY_AUTO', '22');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_course`
--

CREATE TABLE IF NOT EXISTS `tbl_course` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idcategory` int(25) DEFAULT NULL,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `shortname` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `unit` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `price1` bigint(20) NOT NULL,
  `price2` bigint(20) NOT NULL,
  `price3` bigint(20) NOT NULL,
  `price4` bigint(20) NOT NULL,
  `picture` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `prepare` int(11) NOT NULL,
  `is_discount` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `foreign_field` (`idcategory`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=658 ;

--
-- Dumping data for table `tbl_course`
--

INSERT INTO `tbl_course` (`id`, `idcategory`, `name`, `shortname`, `unit`, `price1`, `price2`, `price3`, `price4`, `picture`, `prepare`, `is_discount`) VALUES
(115, 11, 'SG chai xanh', 'SG chai xanh', 'Chai', 12000, 12000, 12000, 12000, '', 0, 0),
(116, 11, 'SG do', 'SG do', 'Chai', 9000, 9000, 9000, 9000, '', 0, 0),
(188, 11, 'Heneiken chai', 'Ken chai', 'Chai', 16000, 16000, 16000, 16000, '', 0, 0),
(189, 11, 'Heneiken lon', 'Ken lon', 'Lon', 19000, 19000, 19000, 19000, '', 0, 0),
(190, 11, 'Tiger nau', 'Tiger nau', 'Chai', 12000, 12000, 12000, 12000, '', 0, 0),
(191, 11, 'Tiger bac', 'Tiger bac', 'Chai', 14000, 14000, 14000, 14000, '', 0, 0),
(405, 11, '333 lon', '333 lon', 'Lon', 11000, 11000, 11000, 11000, '', 0, 0),
(411, 11, '333 chai', '333 chai', 'Chai', 10000, 10000, 10000, 10000, '', 0, 0),
(489, 11, 'SG lon xanh', 'SG lon xanh', 'Lon', 13000, 13000, 13000, 13000, '', 0, 0),
(490, 11, 'Nuoc ngot', 'Nuoc ngot', 'Chai', 12000, 12000, 12000, 12000, '', 0, 0),
(491, 11, 'Nuoc suoi', 'Nuoc suoi', 'Chai', 8000, 8000, 8000, 8000, '', 0, 0),
(492, 37, 'Phu Le', 'Phu Le', 'Chai', 75000, 75000, 75000, 75000, '', 0, 0),
(493, 37, 'Volka lon', 'Volka lon', 'Chai', 105000, 105000, 105000, 105000, '', 0, 0),
(494, 37, 'Volka nho', 'Volka nho', 'Chai', 65000, 65000, 65000, 65000, '', 0, 0),
(495, 38, 'Canh ga nuong muoi ot', 'Canh ga nuong muoi ot', 'Dĩa', 55000, 55000, 55000, 55000, '', 0, 0),
(496, 38, 'Canh ga chien nuoc mam', 'Canh ga chien nuoc mam', 'Dĩa', 55000, 55000, 55000, 55000, '', 0, 0),
(497, 38, 'Canh ga nuong ngu vi', 'Canh ga nuong ngu vi', 'Dĩa', 55000, 55000, 55000, 55000, '', 0, 0),
(498, 38, 'Canh ga nuong chao', 'Canh ga nuong chao', 'Chai', 55000, 55000, 55000, 55000, '', 0, 0),
(503, 40, 'Ga ta nuong muoi ot', 'Ga ta nuong muoi ot', 'Con', 230000, 230000, 230000, 230000, '', 0, 0),
(504, 40, 'Ga ta hap hanh', 'Ga ta hap hanh', 'Con', 230000, 230000, 230000, 230000, '', 0, 0),
(505, 40, 'Ga ta nuong ngu vi', 'Ga ta nuong ngu vi', 'Con', 230000, 230000, 230000, 230000, '', 0, 0),
(506, 40, 'Ga ta nuong chao', 'Ga ta nuong chao', 'Con', 230000, 230000, 230000, 230000, '', 0, 0),
(507, 40, 'Gà ta nướng chao', 'Gà ta nướng chao', 'Con', 230000, 230000, 230000, 230000, '', 0, 0),
(508, 40, 'Ga ta quay lu', 'Ga ta quay lu', 'Con', 230000, 230000, 230000, 230000, '', 0, 0),
(509, 40, 'Ga ta nau la giang', 'Ga ta nau la giang', 'Con', 230000, 230000, 230000, 230000, '', 0, 0),
(510, 41, 'Heo sua quay phan', 'Heo sua quay phan', 'Phần', 150000, 150000, 150000, 150000, '', 0, 0),
(511, 41, 'Heo sua quay con', 'Heo sua quay con', 'Con', 650000, 650000, 650000, 650000, '', 0, 0),
(512, 42, 'Chao ngheu', 'Chao ngheu', 'Thố', 40000, 40000, 40000, 40000, '', 0, 0),
(513, 42, 'Chao bo bam', 'Chao bo bam', 'Thố', 55000, 55000, 55000, 55000, '', 0, 0),
(514, 42, 'Chao hao', 'Chao hao', 'Thố', 60000, 60000, 60000, 60000, '', 0, 0),
(515, 42, 'Chao hai san', 'Chao hai san', 'Thố', 55000, 55000, 55000, 55000, '', 0, 0),
(516, 42, 'Chao muc', 'Chao muc', 'Thố', 55000, 55000, 55000, 55000, '', 0, 0),
(517, 42, 'Chao tom', 'Chao tom', 'Thố', 55000, 55000, 55000, 55000, '', 0, 0),
(518, 42, 'Chao so huyet', 'Chao so huyet', 'Thố', 55000, 55000, 55000, 55000, '', 0, 0),
(519, 43, 'Cua', 'Cua', 'Kg', 370000, 370000, 370000, 370000, '', 0, 0),
(520, 43, 'Ghe', 'Ghe', 'Kg', 300000, 300000, 300000, 300000, '', 0, 0),
(522, 44, 'Ngheu hap sa', 'Ngheu hap sa', 'Phần', 30000, 30000, 30000, 30000, '', 0, 0),
(523, 44, 'Ngheu hap thai', 'Ngheu hap thai', 'Phần', 30000, 30000, 30000, 30000, '', 0, 0),
(524, 44, 'Ngheu xao la hue', 'Ngheu xao la hue', 'Phần', 30000, 30000, 30000, 30000, '', 0, 0),
(525, 44, 'So long hap xa', 'So long hap xa', 'Phần', 35000, 35000, 35000, 35000, '', 0, 0),
(526, 44, 'So long nuong mo hanh', 'So long nuong mo hanh', 'Phần', 40000, 40000, 40000, 40000, '', 0, 0),
(527, 44, 'Hau nuong pho mai', 'Hau nuong pho mai', 'Con', 15000, 15000, 15000, 15000, '', 0, 0),
(528, 44, 'Hau nuong mo hanh', 'Hau nuong mo hanh', 'Con', 15000, 15000, 15000, 15000, '', 0, 0),
(529, 44, 'Hau tai chanh', 'Hau tai chanh', 'Con', 15000, 15000, 15000, 15000, '', 0, 0),
(530, 44, 'So huyet luoc / nuong', 'So huyet luoc / nuong', 'Dĩa', 40000, 40000, 40000, 40000, '', 0, 0),
(531, 44, 'So huyet rang muoi / rang me', 'So huyet rang muoi / rang me', 'Dĩa', 40000, 40000, 40000, 40000, '', 0, 0),
(532, 44, 'So huyet rang muoi / rang me', 'So huyet rang muoi / rang me', 'Dĩa', 40000, 40000, 40000, 40000, '', 0, 0),
(533, 44, 'So diep nuong mo hanh', 'So diep nuong mo hanh', 'Dĩa', 35000, 35000, 35000, 35000, '', 0, 0),
(534, 44, 'So diep nuong pho mai', 'So diep nuong pho mai', 'Dĩa', 35000, 35000, 35000, 35000, '', 0, 0),
(535, 44, 'So veo hap xa', 'So veo hap xa', 'Dĩa', 40000, 40000, 40000, 40000, '', 0, 0),
(536, 44, 'So veo nuong mo hanh', 'So veo nuong mo hanh', 'Dĩa', 40000, 40000, 40000, 40000, '', 0, 0),
(537, 44, 'Oc mo xao toi', 'Oc mo xao toi', 'Dĩa', 55000, 55000, 55000, 55000, '', 0, 0),
(538, 44, 'Oc mo xao hanh', 'Oc mo xao hanh', 'Dĩa', 55000, 55000, 55000, 55000, '', 0, 0),
(539, 44, 'Oc mo xao me ', 'Oc mo xao me ', 'Dĩa', 55000, 55000, 55000, 55000, '', 0, 0),
(540, 44, 'Oc buou nuong tieu', 'Oc buou nuong tieu', 'Dĩa', 35000, 35000, 35000, 35000, '', 0, 0),
(541, 44, 'Oc buou hap xa', 'Oc buou hap xa', 'Dĩa', 35000, 35000, 35000, 35000, '', 0, 0),
(542, 42, 'Mi xao hai san', 'Mi xao hai san', 'Dĩa', 60000, 60000, 60000, 60000, '', 0, 0),
(543, 42, 'Mi xao thap cam', 'Mi xao thap cam', 'Dĩa', 60000, 60000, 60000, 60000, '', 0, 0),
(544, 42, 'Mi xao bo', 'Mi xao bo', 'Dĩa', 58000, 58000, 58000, 58000, '', 0, 0),
(545, 42, 'Muc xao sa te', 'Muc xao sa te', 'Dĩa', 58000, 58000, 58000, 58000, '', 0, 0),
(546, 42, 'Muc xao chua ngot', 'Muc xao chua ngot', 'Dĩa', 60000, 60000, 60000, 60000, '', 0, 0),
(547, 42, 'Bun xao Singapore', 'Bun xao Singapore', 'Dĩa', 60000, 60000, 60000, 60000, '', 0, 0),
(548, 42, 'Com chien Lang Bien', 'Com chien Lang Bien', 'Dĩa', 60000, 60000, 60000, 60000, '', 0, 0),
(549, 42, 'Com chien Tu Quy', 'Com chien Tu Quy', 'Dĩa', 60000, 60000, 60000, 60000, '', 0, 0),
(550, 42, 'Com chien toi', 'Com chien toi', 'Dĩa', 30000, 30000, 30000, 30000, '', 0, 0),
(551, 42, 'Com chien Thuong Hai', 'Com chien Thuong Hai', 'Dĩa', 60000, 60000, 60000, 60000, '', 0, 0),
(552, 42, 'Com chien trung', 'Com chien trung', 'Dĩa', 40000, 40000, 40000, 40000, '', 0, 0),
(553, 42, 'Com chien la xanh', 'Com chien la xanh', 'Dĩa', 60000, 60000, 60000, 60000, '', 0, 0),
(554, 42, 'Com chien hai san', 'Com chien hai san', 'Dĩa', 60000, 60000, 60000, 60000, '', 0, 0),
(555, 42, 'Com chien Duong Chau', 'Com chien Duong Chau', 'Dĩa', 60000, 60000, 60000, 60000, '', 0, 0),
(557, 42, 'Lau xi quach', 'Lau xi quach', 'Cái', 105000, 105000, 105000, 105000, '', 0, 0),
(558, 42, 'Lau dau hai san', 'Lau dau hai san', 'Cái', 120000, 120000, 120000, 120000, '', 0, 0),
(559, 42, 'Lau hai san', 'Lau hai san', 'Cái', 105000, 105000, 105000, 105000, '', 0, 0),
(560, 42, 'Lau ca mang chua', 'Lau ca mang chua', 'Cái', 105000, 105000, 105000, 105000, '', 0, 0),
(561, 42, 'Lau Thai hai san', 'Lau Thai hai san', 'Cái', 120000, 120000, 120000, 120000, '', 0, 0),
(562, 42, 'Lau dau ca Hoi', 'Lau dau ca Hoi', 'Cái', 98000, 98000, 98000, 98000, '', 0, 0),
(563, 42, 'Lau ca Bop', 'Lau ca Bop', 'Cái', 130000, 130000, 130000, 130000, '', 0, 0),
(564, 42, 'Lau muc', 'Lau muc', 'Cái', 120000, 120000, 120000, 120000, '', 0, 0),
(565, 42, 'Lau tom', 'Lau tom', 'Cái', 120000, 120000, 120000, 120000, '', 0, 0),
(566, 42, 'Lau cua gach, lau ghe', 'Lau cua gach, lau ghe', 'Cái', 0, 0, 0, 0, '', 0, 0),
(567, 38, 'Chan ga nuong muoi ot', 'Chan ga nuong muoi ot', 'Dĩa', 55000, 55000, 55000, 55000, '', 0, 0),
(568, 38, 'Chan ga hap hanh', 'Chan ga hap hanh', 'Dĩa', 55000, 55000, 55000, 55000, '', 0, 0),
(569, 38, 'Chan ga nuong ngu vi', 'Chan ga nuong ngu vi', 'Dĩa', 55000, 55000, 55000, 55000, '', 0, 0),
(570, 38, 'Chan ga nuong chao', 'Chan ga nuong chao', 'Dĩa', 55000, 55000, 55000, 55000, '', 0, 0),
(571, 45, 'Goi cu hu dua tom thit', 'Goi cu hu dua tom thit', 'Dĩa', 60000, 60000, 60000, 60000, '', 0, 0),
(572, 45, 'Goi rau muong dong tom thit', 'Goi rau muong dong tom thit', 'Dĩa', 60000, 60000, 60000, 60000, '', 0, 0),
(573, 45, 'Goi rau muong dong hai san', 'Goi rau muong dong hai san', 'Dĩa', 60000, 60000, 60000, 60000, '', 0, 0),
(574, 45, 'Goi xoai kho ca loc', 'Goi xoai kho ca loc', 'Dĩa', 55000, 55000, 55000, 55000, '', 0, 0),
(575, 45, 'Goi dien dien hai san', 'Goi dien dien hai san', 'Dĩa', 0, 0, 0, 0, '', 0, 0),
(576, 45, 'Goi bo ba khia Lang Bien', 'Goi bo ba khia Lang Bien', 'Dĩa', 70000, 70000, 70000, 70000, '', 0, 0),
(577, 45, 'Goi muc tom Thai', 'Goi muc tom Thai', 'Dĩa', 60000, 60000, 60000, 60000, '', 0, 0),
(578, 45, 'Goi rau nhut hai san', 'Goi rau nhut hai san', 'Dĩa', 60000, 60000, 60000, 60000, '', 0, 0),
(579, 41, 'Mat ca ngu dai duong hap', 'Mat ca ngu dai duong hap', 'Phần', 60000, 60000, 60000, 60000, '', 0, 0),
(580, 41, 'Mat ca ngu dai duong lau', 'Mat ca ngu dai duong lau', 'Cái', 120000, 120000, 120000, 120000, '', 0, 0),
(581, 41, 'Ca lang cha ca La Vong', 'Ca lang cha ca La Vong', 'Phần', 190000, 190000, 190000, 190000, '', 0, 0),
(582, 41, 'Ca lang lau chua', 'Ca lang lau chua', 'Cái', 190000, 190000, 190000, 190000, '', 0, 0),
(583, 41, 'Dau hu Lang Bien', 'Dau hu Lang Bien', 'Dĩa', 70000, 70000, 70000, 70000, '', 0, 0),
(584, 41, 'Sua tuoi chien gion', 'Sua tuoi chien gion', 'Dĩa', 50000, 50000, 50000, 50000, '', 0, 0),
(585, 41, 'Cha gio Lang Bien', 'Cha gio Lang Bien', 'Dĩa', 55000, 55000, 55000, 55000, '', 0, 0),
(586, 41, 'Bo nuong Lang Bien', 'Bo nuong Lang Bien', 'Dĩa', 70000, 70000, 70000, 70000, '', 0, 0),
(587, 41, 'Com chien Lang Bien', 'Com chien Lang Bien', 'Dĩa', 60000, 60000, 60000, 60000, '', 0, 0),
(588, 41, 'Bun xao Lang Bien', 'Bun xao Lang Bien', 'Dĩa', 60000, 60000, 60000, 60000, '', 0, 0),
(589, 41, 'Com chay nuong Lang Bien', 'Com chay nuong Lang Bien', 'Dĩa', 50000, 50000, 50000, 50000, '', 0, 0),
(590, 41, 'Lau ca mang chua', 'Lau ca mang chua', 'Dĩa', 120000, 120000, 120000, 120000, '', 0, 0),
(591, 45, 'Rau nhut xao hai san', 'Rau nhut xao hai san', 'Dĩa', 58000, 58000, 58000, 58000, '', 0, 0),
(592, 45, 'Rau muong xao toi', 'Rau muong xao toi', 'Dĩa', 28000, 28000, 28000, 28000, '', 0, 0),
(593, 45, 'Rau muong xao bo', 'Rau muong xao bo', 'Dĩa', 60000, 60000, 60000, 60000, '', 0, 0),
(594, 46, 'Bo luc lac', 'Bo luc lac', 'Dĩa', 65000, 65000, 65000, 65000, '', 0, 0),
(595, 46, 'Bo bit tet', 'Bo bit tet', 'Dĩa', 65000, 65000, 65000, 65000, '', 0, 0),
(596, 46, 'Bo nuong lui', 'Bo nuong lui', 'Dĩa', 65000, 65000, 65000, 65000, '', 0, 0),
(597, 46, 'Bo napoleon', 'Bo napoleon', 'Dĩa', 70000, 70000, 70000, 70000, '', 0, 0),
(598, 46, 'Tom nuong muoi ot', 'Tom nuong muoi ot', 'Dĩa', 58000, 58000, 58000, 58000, '', 0, 0),
(599, 46, 'Tom nuong sa te', 'Tom nuong sa te', 'Dĩa', 58000, 58000, 58000, 58000, '', 0, 0),
(600, 46, 'Tom nuong moi', 'Tom nuong moi', 'Dĩa', 58000, 58000, 58000, 58000, '', 0, 0),
(601, 46, 'Muc ong phan', 'Muc ong phan', 'Phần', 78000, 78000, 78000, 78000, '', 0, 0),
(602, 46, 'Muc ong kg', 'Muc ong kg', 'Kg', 280000, 280000, 280000, 280000, '', 0, 0),
(603, 46, 'Muc la phan', 'Muc la phan', 'Phần', 80000, 80000, 80000, 80000, '', 0, 0),
(604, 46, 'Muc la kg', 'Muc la kg', 'Kg', 290000, 290000, 290000, 290000, '', 0, 0),
(605, 46, 'Bach tuoc phan', 'Bach tuoc phan', 'Phần', 70000, 70000, 70000, 70000, '', 0, 0),
(606, 46, 'Bach tuoc kg', 'Bach tuoc kg', 'Kg', 190000, 190000, 190000, 190000, '', 0, 0),
(607, 46, 'Muc trung Phu Quoc phan', 'Muc trung Phu Quoc phan', 'Phần', 78000, 78000, 78000, 78000, '', 0, 0),
(608, 46, 'Muc trung Phu Quoc kg', 'Muc trung Phu Quoc kg', 'Kg', 280000, 280000, 280000, 280000, '', 0, 0),
(609, 46, 'Muc chien gion', 'Muc chien gion', 'Dĩa', 60000, 60000, 60000, 60000, '', 0, 0),
(610, 46, 'Muc hap gung', 'Muc hap gung', 'Dĩa', 60000, 60000, 60000, 60000, '', 0, 0),
(611, 46, 'Muc chien nuoc mam', 'Muc chien nuoc mam', 'Dĩa', 60000, 60000, 60000, 60000, '', 0, 0),
(612, 45, 'Khoai tay chien', 'Khoai tay chien', 'Dĩa', 30000, 30000, 30000, 30000, '', 0, 0),
(613, 45, 'dau hu chien xa ot', 'dau hu chien xa ot', 'Dĩa', 30000, 30000, 30000, 30000, '', 0, 0),
(614, 45, 'Dau hu chien gion', 'Dau hu chien gion', 'Dĩa', 30000, 30000, 30000, 30000, '', 0, 0),
(615, 41, 'Cha ca thac lac Lang Bien', 'Cha ca thac lac Lang Bien', 'Dĩa', 60000, 60000, 60000, 60000, '', 0, 0),
(616, 47, 'Ca sapa con', 'Ca sapa con', 'Con', 58000, 58000, 58000, 58000, '', 0, 0),
(617, 47, 'Ca xuong xanh phan', 'Ca xuong xanh phan', 'Phần', 58000, 58000, 58000, 58000, '', 0, 0),
(618, 47, 'Ca xuong xanh kg', 'Ca xuong xanh kg', 'Kg', 160000, 160000, 160000, 160000, '', 0, 0),
(619, 47, 'ca song con', 'ca song con', 'Con', 35000, 35000, 35000, 35000, '', 0, 0),
(620, 47, 'Ca cam con', 'Ca cam con', 'Con', 68000, 68000, 68000, 68000, '', 0, 0),
(621, 47, 'Ca duoi phan', 'Ca duoi phan', 'Phần', 55000, 55000, 55000, 55000, '', 0, 0),
(622, 47, 'Ca duoi kg', 'Ca duoi kg', 'Kg', 180000, 180000, 180000, 180000, '', 0, 0),
(623, 47, 'Ca thu Nhat phan', 'Ca thu Nhat phan', 'Phần', 55000, 55000, 55000, 55000, '', 0, 0),
(624, 47, 'Ca nhong phan', 'Ca nhong phan', 'Phần', 60000, 60000, 60000, 60000, '', 0, 0),
(625, 47, 'Ca bop phan', 'Ca bop phan', 'Phần', 60000, 60000, 60000, 60000, '', 0, 0),
(626, 47, 'Ca bop kg', 'Ca bop kg', 'Kg', 290000, 290000, 290000, 290000, '', 0, 0),
(627, 47, 'Dau ca hoi', 'Dau ca hoi', 'Phần', 50000, 50000, 50000, 50000, '', 0, 0),
(628, 47, 'Ca mat kien', 'Ca mat kien', 'Phần', 60000, 60000, 60000, 60000, '', 0, 0),
(629, 47, 'Ca ria', 'Ca ria', 'Con', 50000, 50000, 50000, 50000, '', 0, 0),
(630, 47, 'Ca nau', 'Ca nau', 'Kg', 220000, 220000, 220000, 220000, '', 0, 0),
(631, 47, 'Ca bo da', 'Ca bo da', 'Kg', 180000, 180000, 180000, 180000, '', 0, 0),
(632, 47, 'Ca bo vay', 'Ca bo vay', 'Kg', 110000, 110000, 110000, 110000, '', 0, 0),
(633, 47, 'ca gion phan', 'ca gion phan', 'Phần', 58000, 58000, 58000, 58000, '', 0, 0),
(634, 47, 'ca gion kg', 'ca gion kg', 'Kg', 270000, 270000, 270000, 270000, '', 0, 0),
(635, 47, 'ca ngu dai duong kg', 'ca ngu dai duong kg', 'Kg', 390000, 390000, 390000, 390000, '', 0, 0),
(636, 48, 'Khan', 'Khan', 'Cái', 2000, 2000, 2000, 2000, '', 0, 0),
(637, 48, 'Dau', 'Dau', 'Bao', 10000, 10000, 10000, 10000, '', 0, 0),
(638, 49, 'Bo tat chai', 'Bo tat chai', 'Chai', 35000, 35000, 35000, 35000, '', 0, 0),
(639, 49, 'Bo tat chen', 'Bo tat chen', 'Chai', 10000, 10000, 10000, 10000, '', 0, 0),
(640, 49, 'Banh mi', 'Banh mi', 'Cái', 4000, 4000, 4000, 4000, '', 0, 0),
(641, 49, 'Bun them', 'Bun them', 'Dĩa', 10000, 10000, 10000, 10000, '', 0, 0),
(642, 49, 'Rau them', 'Rau them', 'Dĩa', 10000, 10000, 10000, 10000, '', 0, 0),
(643, 49, 'Muc them', 'Muc them', 'Dĩa', 50000, 50000, 50000, 50000, '', 0, 0),
(644, 45, 'Rau luoc kho quet', 'Rau luoc kho quet', 'Dĩa', 50000, 50000, 50000, 50000, '', 0, 0),
(645, 49, 'Thuoc Hero', 'Thuoc Hero', 'Bao', 18000, 18000, 18000, 18000, '', 0, 0),
(646, 49, 'Thuoc JET', 'Thuoc JET', 'Bao', 20000, 20000, 20000, 20000, '', 0, 0),
(647, 49, 'Thuoc meo', 'Thuoc meo', 'Bao', 22000, 22000, 22000, 22000, '', 0, 0),
(648, 49, 'Thuoc 555', 'Thuoc 555', 'Bao', 30000, 30000, 30000, 30000, '', 0, 0),
(649, 47, 'ca chach hue', 'ca chach hue', 'Kg', 340000, 340000, 340000, 340000, '', 0, 0),
(650, 47, 'ca chach hue', 'ca chach hue', 'Kg', 340000, 340000, 340000, 340000, '', 0, 0),
(651, 47, 'ca chach hue', 'ca chach hue', 'Kg', 340000, 340000, 340000, 340000, '', 0, 0),
(652, 45, 'sa lach tron', 'sa lach tron', 'Dĩa', 30000, 30000, 30000, 30000, '', 0, 0),
(653, 45, 'sa lach tron', 'sa lach tron', 'Dĩa', 30000, 30000, 30000, 30000, '', 0, 0),
(654, 49, 'Trung chien', 'Trung chien', 'Dĩa', 35000, 35000, 35000, 35000, '', 0, 0),
(655, 47, 'ca bong tuong', 'ca bong tuong', 'Kg', 360000, 360000, 360000, 360000, '', 0, 0),
(656, 38, 'Ech nuong ', 'Ech nuong ', 'Dĩa', 60000, 60000, 60000, 60000, '', 0, 0),
(657, 38, 'Ech nau lau', 'Ech nau lau', 'Cái', 120000, 120000, 120000, 120000, '', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_course_log`
--

CREATE TABLE IF NOT EXISTS `tbl_course_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_table` int(11) NOT NULL,
  `id_course` int(11) NOT NULL,
  `date_time` datetime NOT NULL,
  `count` int(11) NOT NULL,
  `state` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=570 ;

--
-- Dumping data for table `tbl_course_log`
--

INSERT INTO `tbl_course_log` (`id`, `id_table`, `id_course`, `date_time`, `count`, `state`) VALUES
(565, 1, 380, '2014-01-23 22:37:54', 1, 0),
(566, 1, 380, '2014-01-23 22:37:57', 1, 0),
(567, 1, 380, '2014-01-23 22:37:57', 1, 0),
(568, 1, 416, '2014-01-23 23:06:41', 1, 0),
(569, 1, 415, '2014-01-23 23:06:42', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_customer`
--

CREATE TABLE IF NOT EXISTS `tbl_customer` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  `card` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `discount` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=24 ;

--
-- Dumping data for table `tbl_customer`
--

INSERT INTO `tbl_customer` (`id`, `name`, `type`, `card`, `phone`, `address`, `note`, `discount`) VALUES
(1, 'Khách lẻ', 0, '1', '', '', '', 0),
(12, 'Khách VIP1', 1, 'vip1', '0919 111 222', 'Vĩnh Long', '', 5),
(13, 'Khách VIP2', 1, 'vip2', '0949 959997', 'Đồng Tháp', '', 10);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_domain`
--

CREATE TABLE IF NOT EXISTS `tbl_domain` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=8 ;

--
-- Dumping data for table `tbl_domain`
--

INSERT INTO `tbl_domain` (`id`, `name`) VALUES
(1, 'KHU TUM'),
(2, 'KHU VIP'),
(3, 'KHU TRONG'),
(4, 'KHU NGOÀI'),
(5, 'KH MUA VỀ'),
(7, 'ĐẶT TIỆC');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_employee`
--

CREATE TABLE IF NOT EXISTS `tbl_employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `job` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `gender` tinyint(2) NOT NULL,
  `phone` varchar(13) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `salary_base` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=11 ;

--
-- Dumping data for table `tbl_employee`
--

INSERT INTO `tbl_employee` (`id`, `name`, `job`, `gender`, `phone`, `address`, `salary_base`) VALUES
(2, 'quang', 'Phục vụ', 0, '', 'Đồng Tháp', 3000000),
(6, 'huyen', 'NV', 1, '', 'Đồng Tháp', 2500000),
(7, 'khanh', 'pv', 1, '', 'Đồng Tháp', 5500000),
(8, 'Nguyễn Văn D', 'NV bếp', 0, '', 'Đồng Tháp', 2500000),
(9, 'Nguyễn Văn E', 'NV PV', 0, '', 'Đồng Tháp', 2500000),
(10, 'Nguyễn Văn F', 'NV PV', 1, '', 'Đồng Tháp', 1300000);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_guest`
--

CREATE TABLE IF NOT EXISTS `tbl_guest` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(16) CHARACTER SET latin1 NOT NULL,
  `entry_time` varchar(32) CHARACTER SET latin1 NOT NULL,
  `exit_time` varchar(32) CHARACTER SET latin1 NOT NULL,
  `agent` varchar(16) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=150 ;

--
-- Dumping data for table `tbl_guest`
--

INSERT INTO `tbl_guest` (`id`, `ip`, `entry_time`, `exit_time`, `agent`) VALUES
(149, '115.78.94.118', '1383319305', '1383322905', '115.78.94.118');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_notify`
--

CREATE TABLE IF NOT EXISTS `tbl_notify` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  `message` varchar(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tbl_notify`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_order_import`
--

CREATE TABLE IF NOT EXISTS `tbl_order_import` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idsupplier` int(11) NOT NULL,
  `date` date NOT NULL,
  `description` varchar(50) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_order_import_1` (`idsupplier`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=352 ;

--
-- Dumping data for table `tbl_order_import`
--

INSERT INTO `tbl_order_import` (`id`, `idsupplier`, `date`, `description`) VALUES
(350, 16, '2013-12-28', ''),
(351, 13, '2014-01-17', '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order_import_detail`
--

CREATE TABLE IF NOT EXISTS `tbl_order_import_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idorder` int(11) NOT NULL,
  `idresource` int(11) NOT NULL,
  `count` float NOT NULL,
  `price` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_order_import_detail_1` (`idorder`),
  KEY `tbl_order_import_detail_2` (`idresource`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=641 ;

--
-- Dumping data for table `tbl_order_import_detail`
--

INSERT INTO `tbl_order_import_detail` (`id`, `idorder`, `idresource`, `count`, `price`) VALUES
(636, 350, 169, 2, 16000),
(637, 350, 168, 2, 15000),
(638, 350, 170, 1, 25000),
(639, 351, 114, 0.2, 230000),
(640, 351, 115, 0.3, 230000);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_paid_customer`
--

CREATE TABLE IF NOT EXISTS `tbl_paid_customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idcustomer` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_customer_paid_1` (`idcustomer`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tbl_paid_customer`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_paid_employee`
--

CREATE TABLE IF NOT EXISTS `tbl_paid_employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_employee` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(150) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_employee` (`id_employee`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `tbl_paid_employee`
--

INSERT INTO `tbl_paid_employee` (`id`, `id_employee`, `date`, `value`, `note`) VALUES
(3, 2, '2014-01-16', 10, 'bep ung');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_paid_general`
--

CREATE TABLE IF NOT EXISTS `tbl_paid_general` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_term` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_paid_1` (`id_term`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=167 ;

--
-- Dumping data for table `tbl_paid_general`
--

INSERT INTO `tbl_paid_general` (`id`, `id_term`, `date`, `value`, `note`) VALUES
(9, 10, '2013-04-01', 157000, 'Chi tiền chợ'),
(10, 10, '2013-04-02', 146000, 'Tiền chợ'),
(11, 10, '2013-04-03', 189000, 'Tiền chợ'),
(12, 10, '2013-04-04', 184000, 'Tiền chợ'),
(20, 11, '2013-04-06', 163000, 'Chi mua đồ điện '),
(21, 11, '2013-12-04', 250000, 'Mua CB'),
(22, 11, '2013-04-07', 57000, 'Trái cây cúng+bao kiếng trái cây'),
(66, 2, '2013-04-30', 2100000, 'Tạm tính'),
(111, 3, '2013-07-31', 1500000, 'Thuế TTĐB Tháng 07'),
(112, 1, '2013-07-31', 4000000, 'Tiền điện T07'),
(113, 2, '2013-07-31', 2000000, 'Tiền nước T07'),
(155, 3, '2013-08-31', 800000, 'Thuế TTĐB T08'),
(156, 3, '2013-09-30', 850000, 'Thuế TTĐB T09'),
(158, 1, '2013-08-31', 5800000, 'Tiền điện T08'),
(159, 1, '2013-09-30', 3700000, 'Tiền điện T09'),
(160, 2, '2013-08-31', 2200000, 'Tiền nước T08'),
(161, 2, '2013-09-30', 2300000, 'Tiền nước T09'),
(163, 1, '2013-05-31', 4700000, 'Tiền điện T05'),
(164, 1, '2013-06-30', 3900000, 'Tiền điện T06'),
(165, 2, '2013-05-31', 2350000, 'Tiền nước T05'),
(166, 2, '2013-06-30', 2260000, 'Tiền nước T06');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_paid_pay_roll`
--

CREATE TABLE IF NOT EXISTS `tbl_paid_pay_roll` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_employee` int(11) NOT NULL,
  `date` date NOT NULL,
  `value_base` int(11) NOT NULL,
  `value_sub` int(11) NOT NULL,
  `value_pre` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_paid_pay_roll_1` (`id_employee`),
  KEY `id_employee` (`id_employee`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tbl_paid_pay_roll`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_paid_supplier`
--

CREATE TABLE IF NOT EXISTS `tbl_paid_supplier` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idsupplier` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_supplier_paid_1` (`idsupplier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tbl_paid_supplier`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_pay_roll`
--

CREATE TABLE IF NOT EXISTS `tbl_pay_roll` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_employee` int(11) NOT NULL,
  `date` date NOT NULL,
  `state` int(11) NOT NULL,
  `extra` int(11) NOT NULL,
  `late` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_employee` (`id_employee`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=97 ;

--
-- Dumping data for table `tbl_pay_roll`
--

INSERT INTO `tbl_pay_roll` (`id`, `id_employee`, `date`, `state`, `extra`, `late`) VALUES
(32, 2, '2013-10-01', 1, 0, 0),
(33, 2, '2013-10-02', 1, 0, 0),
(34, 2, '2013-10-03', 1, 0, 0),
(35, 2, '2013-10-04', 1, 0, 0),
(36, 2, '2013-10-05', 1, 0, 0),
(37, 2, '2013-10-06', 1, 0, 0),
(38, 2, '2013-10-07', 1, 0, 0),
(39, 2, '2013-10-08', 1, 0, 0),
(40, 2, '2013-10-09', 1, 0, 0),
(41, 2, '2013-10-10', 1, 0, 0),
(42, 2, '2013-10-11', 1, 0, 0),
(43, 2, '2013-10-12', 1, 0, 0),
(44, 2, '2013-10-13', 1, 0, 0),
(45, 2, '2013-10-14', 1, 0, 0),
(46, 2, '2013-10-15', 1, 0, 0),
(47, 2, '2013-10-16', 1, 0, 0),
(48, 2, '2013-10-17', 1, 0, 0),
(49, 2, '2013-10-18', 1, 0, 0),
(50, 2, '2013-10-19', 1, 0, 0),
(51, 2, '2013-10-20', 1, 0, 0),
(52, 2, '2013-10-21', 1, 0, 0),
(53, 2, '2013-10-22', 1, 0, 0),
(54, 2, '2013-10-23', 1, 0, 0),
(55, 2, '2013-10-24', 1, 0, 0),
(56, 2, '2013-10-25', 1, 0, 0),
(57, 2, '2013-10-26', 1, 0, 0),
(58, 2, '2013-10-27', 1, 0, 0),
(59, 2, '2013-10-28', 1, 0, 0),
(60, 2, '2013-10-29', 1, 0, 0),
(61, 2, '2013-10-30', 1, 0, 0),
(62, 2, '2013-10-31', 1, 0, 0),
(63, 6, '2013-12-14', 1, 0, 0),
(64, 7, '2014-01-09', 1, 0, 0),
(66, 2, '2013-12-01', 0, 0, 0),
(67, 2, '2013-12-02', 0, 0, 0),
(68, 2, '2013-12-03', 0, 0, 0),
(69, 2, '2013-12-04', 0, 0, 0),
(70, 2, '2013-12-05', 0, 0, 0),
(71, 2, '2013-12-06', 0, 0, 0),
(72, 2, '2013-12-07', 0, 0, 0),
(73, 2, '2013-12-08', 0, 0, 0),
(74, 2, '2013-12-09', 0, 0, 0),
(75, 2, '2013-12-10', 0, 0, 0),
(76, 2, '2013-12-11', 0, 0, 0),
(77, 2, '2013-12-12', 0, 0, 0),
(78, 2, '2013-12-13', 0, 0, 0),
(79, 2, '2013-12-14', 0, 0, 0),
(80, 2, '2013-12-15', 0, 0, 0),
(81, 2, '2013-12-16', 0, 0, 0),
(82, 2, '2013-12-17', 0, 0, 0),
(83, 2, '2013-12-18', 0, 0, 0),
(84, 2, '2013-12-19', 0, 0, 0),
(85, 2, '2013-12-20', 0, 0, 0),
(86, 2, '2013-12-21', 0, 0, 0),
(87, 2, '2013-12-22', 0, 0, 0),
(88, 2, '2013-12-23', 0, 0, 0),
(89, 2, '2013-12-24', 0, 0, 0),
(90, 2, '2013-12-25', 0, 0, 0),
(91, 2, '2013-12-26', 0, 0, 0),
(92, 2, '2013-12-27', 0, 0, 0),
(93, 2, '2013-12-28', 1, 0, 0),
(94, 2, '2013-12-29', 1, 0, 0),
(95, 2, '2013-12-30', 1, 0, 0),
(96, 2, '2013-12-31', 1, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_r2c`
--

CREATE TABLE IF NOT EXISTS `tbl_r2c` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_course` int(11) NOT NULL,
  `id_resource` int(11) NOT NULL,
  `value1` double NOT NULL,
  `value2` double NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_r2c_1` (`id_course`),
  KEY `tbl_r2c_2` (`id_resource`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tbl_r2c`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_resource`
--

CREATE TABLE IF NOT EXISTS `tbl_resource` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `idsupplier` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `unit` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `price` int(10) NOT NULL,
  `description` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_resource_1` (`idsupplier`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=211 ;

--
-- Dumping data for table `tbl_resource`
--

INSERT INTO `tbl_resource` (`id`, `idsupplier`, `name`, `unit`, `price`, `description`) VALUES
(105, 21, 'SG special chai', 'Chai', 9600, ''),
(106, 21, 'SG special lon', 'Lon', 11000, ''),
(107, 21, 'SG đỏ', 'Chai', 6600, ''),
(108, 21, 'Heneiken chai', 'Chai', 12050, ''),
(109, 21, 'Heneiken lon', 'Lon', 14000, ''),
(110, 21, 'Tiger nâu', 'Chai', 11000, ''),
(111, 21, 'Tiger bạc', 'Chai', 12000, ''),
(112, 28, 'Sagota', 'Lon', 12500, ''),
(113, 28, 'Sagota vàng', 'Lon', 11000, ''),
(114, 13, 'Cua biển', 'Kg', 230000, ''),
(115, 13, 'Ghẹ', 'Kg', 230000, ''),
(116, 13, 'Cá nhám', 'Kg', 90000, ''),
(117, 13, 'Cá đuối', 'Kg', 230000, ''),
(118, 13, 'Cá chạch quế', 'Kg', 270000, ''),
(119, 13, 'Cá quế', 'Kg', 270000, ''),
(120, 18, 'Gà ', 'Kg', 90000, ''),
(121, 19, 'Cá sapa ', 'Kg', 57000, ''),
(122, 19, 'Cá cam', 'Kg', 1, ''),
(123, 19, 'Cá bò da', 'Kg', 1, ''),
(124, 15, 'Sò huyết', 'Kg', 90000, ''),
(125, 15, 'Nghêu', 'Kg', 35000, ''),
(126, 14, 'Đá cắt', 'Kg', 800, ''),
(127, 14, 'Đá xay', 'Kg', 750, ''),
(128, 14, 'Đá cây', 'Kg', 600, ''),
(129, 22, 'Pepsi ', 'Lon', 6900, ''),
(130, 22, 'Sting lon', 'Lon', 6300, ''),
(131, 22, 'Trà C2', 'Chai', 4300, ''),
(132, 22, 'Suối lavie(500ml)', 'Chai', 3500, ''),
(133, 23, 'Rượu volka men', 'Chai', 1, ''),
(134, 23, 'Rượu phú lễ', 'Chai', 1, ''),
(135, 23, 'Rượu bồ đào đá', 'Chai', 1, ''),
(136, 17, 'Đường', 'Kg', 16000, ''),
(137, 17, 'Muối bọt', 'Bịch', 1, ''),
(138, 17, 'Muối hột', 'Bịch', 1, ''),
(139, 17, 'Bột ngọt', 'Bịch', 45000, ''),
(140, 17, 'Tương ớt', 'Chai', 52000, ''),
(141, 17, 'Tương cà', 'Chai', 1, ''),
(142, 17, 'Tương xí muội', 'Chai', 1, ''),
(143, 17, 'Dầu hào', 'Chai', 30000, ''),
(144, 17, 'Nước tương', 'Chai', 1, ''),
(145, 17, 'Mù tạt nhật', 'Chai', 1, ''),
(146, 17, 'Sữa ngôi sao', 'Hộp', 16000, ''),
(147, 17, 'Bột chiên giòn', 'Bịch', 5000, ''),
(148, 17, 'Bột chiên xù(lớn)', 'Bịch', 1, ''),
(149, 17, 'Bột chiên xù(nhỏ)', 'Bịch', 7000, ''),
(150, 17, 'Dầu ăn', 'Thùng', 650000, ''),
(151, 17, 'Dầu mè', 'Chai', 1, ''),
(152, 17, 'Bột tàu xì', 'Kg', 1, ''),
(153, 17, 'Sa tế', 'Chai', 1, ''),
(154, 17, 'Ngũ vị hương', 'Bịch', 1, ''),
(155, 17, 'Nước tương nam dương', 'Chai', 1, ''),
(156, 17, 'Bột nghệ', 'Kg', 1, ''),
(157, 17, 'Tiêu xay', 'Kg', 1, ''),
(158, 17, 'Tiêu sọ', 'Kg', 1, ''),
(159, 17, 'Bột cà ri', 'Bịch', 1, ''),
(160, 17, 'Đậu hà lan ', 'Lon', 1, ''),
(161, 16, 'Cần tàu', 'Kg', 20000, ''),
(162, 16, 'Gừng', 'Kg', 26000, ''),
(163, 16, 'Ghiền', 'Kg', 0, ''),
(164, 16, 'Rau muống', 'Kg', 8000, ''),
(165, 16, 'Salad lụa', 'Kg', 14000, ''),
(166, 16, 'Cà rốt', 'Kg', 17500, ''),
(167, 16, 'Rau sống', 'Kg', 18000, ''),
(168, 16, 'Hành lá', 'Kg', 15000, ''),
(169, 16, 'Hành tây', 'Kg', 16000, ''),
(170, 16, 'Hành tím', 'Kg', 25000, ''),
(171, 16, 'Rau râm', 'Kg', 10000, ''),
(172, 16, 'Rau nhúc', 'Kg', 0, ''),
(173, 16, 'Cù nèo', 'Kg', 0, ''),
(174, 16, 'Cải ngọt', 'Kg', 0, ''),
(175, 16, 'Cải thìa', 'Kg', 10000, ''),
(176, 17, 'Tỏi củ', 'Kg', 18000, ''),
(177, 16, 'Sả cộng', 'Kg', 10000, ''),
(178, 16, 'Ớt đà lạt', 'Kg', 0, ''),
(179, 16, 'Ớt hiểm xanh', 'Kg', 40000, ''),
(180, 16, 'Ớt sừng', 'Kg', 50000, ''),
(181, 16, 'Khoai môn', 'Kg', 20000, ''),
(182, 16, 'Khoai tây', 'Kg', 28000, ''),
(183, 16, 'Khổ hoa', 'Kg', 0, ''),
(184, 16, 'Dưa leo', 'Kg', 9000, ''),
(185, 16, 'Cà chua', 'Kg', 13000, ''),
(186, 16, 'Đậu bắp', 'Kg', 0, ''),
(187, 16, 'Khóm ', 'Trái', 9000, ''),
(188, 16, 'Cải thảo', 'Kg', 0, ''),
(189, 16, 'Chanh', 'Kg', 8000, ''),
(190, 16, 'Hạnh', 'Kg', 0, ''),
(191, 16, 'Khế', 'Kg', 0, ''),
(192, 16, 'Mồng tơi', 'Kg', 0, ''),
(193, 16, 'Mướp ', 'Kg', 0, ''),
(194, 16, 'Bầu', 'Kg', 0, ''),
(195, 16, 'Ngò rai', 'Kg', 0, ''),
(196, 16, 'Ngò ôm', 'Kg', 0, ''),
(197, 26, 'Đồ khui', 'Cái', 5000, ''),
(198, 26, 'Xô đá', 'Cái', 0, ''),
(199, 26, 'Gấp đá', 'Cái', 0, ''),
(200, 13, 'Cá chép giòn', 'Kg', 280000, ''),
(201, 13, 'Cá lăng', 'Kg', 75000, ''),
(202, 13, 'Cá lăng vàng', 'Kg', 250000, ''),
(203, 15, 'Mực ống', 'Kg', 160000, ''),
(205, 16, 'Nấm rơm', 'Kg', 50000, ''),
(206, 16, 'Củ cải trắng', 'Kg', 8000, ''),
(207, 16, 'Ngò rí', 'Kg', 40000, ''),
(208, 27, 'Mì gói', 'Gói', 2400, ''),
(209, 27, 'Phô mai', 'Miếng', 5000, ''),
(210, 16, 'Bắp chuối', 'Kg', 20000, '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_session`
--

CREATE TABLE IF NOT EXISTS `tbl_session` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idtable` int(11) NOT NULL,
  `iduser` int(11) NOT NULL,
  `idcustomer` int(11) NOT NULL,
  `idemployee` int(11) NOT NULL,
  `datetime` datetime NOT NULL,
  `datetimeend` datetime DEFAULT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  `discount_value` int(11) NOT NULL,
  `discount_percent` int(11) NOT NULL,
  `surtax` int(11) NOT NULL,
  `payment` int(11) NOT NULL,
  `value` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idtable` (`idtable`),
  KEY `iduser` (`iduser`),
  KEY `tbl_session_3` (`idcustomer`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=186 ;

--
-- Dumping data for table `tbl_session`
--

INSERT INTO `tbl_session` (`id`, `idtable`, `iduser`, `idcustomer`, `idemployee`, `datetime`, `datetimeend`, `note`, `status`, `discount_value`, `discount_percent`, `surtax`, `payment`, `value`) VALUES
(151, 2, 3, 1, 7, '2014-01-24 17:23:19', '2014-01-24 17:23:19', '', 1, 0, 0, 0, 0, 0),
(152, 49, 3, 1, 2, '2014-01-24 17:24:19', '2014-01-24 17:24:19', '', 1, 0, 0, 0, 0, 0),
(153, 38, 3, 1, 2, '2014-01-24 17:25:06', '2014-01-24 17:25:06', '', 1, 0, 0, 0, 0, 0),
(154, 46, 3, 1, 2, '2014-01-24 17:32:07', '2014-01-24 17:32:07', '', 1, 0, 0, 0, 0, 0),
(155, 46, 3, 1, 2, '2014-01-24 17:42:07', '2014-01-24 17:42:07', '', 1, 0, 0, 0, 0, 0),
(156, 1, 3, 1, 2, '2014-01-24 17:51:51', '2014-01-24 17:51:51', '', 1, 0, 0, 0, 0, 0),
(157, 38, 3, 1, 2, '2014-01-24 17:55:21', '2014-01-24 17:55:21', '', 1, 0, 0, 0, 0, 0),
(159, 1, 3, 1, 2, '2014-01-24 18:06:34', '2014-01-24 18:06:34', '', 1, 0, 0, 0, 0, 0),
(160, 33, 3, 1, 2, '2014-01-24 18:08:59', '2014-01-24 18:08:59', '', 1, 0, 0, 0, 0, 0),
(161, 36, 3, 1, 2, '2014-01-24 18:11:51', '2014-01-24 18:11:51', '', 1, 0, 0, 0, 0, 0),
(162, 40, 3, 1, 2, '2014-01-24 18:13:08', '2014-01-24 18:13:08', '', 1, 0, 0, 0, 0, 0),
(163, 39, 3, 1, 2, '2014-01-24 18:14:43', '2014-01-24 18:14:43', '', 1, 0, 0, 0, 0, 0),
(164, 2, 3, 1, 2, '2014-01-24 18:16:46', '2014-01-24 18:16:46', '', 1, 0, 0, 0, 0, 0),
(165, 38, 3, 1, 2, '2014-01-24 18:37:31', '2014-01-24 18:37:31', '', 1, 0, 0, 0, 0, 0),
(166, 34, 3, 1, 2, '2014-01-24 18:39:17', '2014-01-24 18:39:17', '', 1, 0, 0, 0, 0, 0),
(167, 52, 3, 1, 2, '2014-01-24 19:23:52', '2014-01-24 19:23:52', '', 1, 0, 0, 0, 0, 0),
(168, 41, 3, 1, 2, '2014-01-24 19:28:33', '2014-01-24 19:28:33', '', 1, 0, 0, 0, 0, 0),
(169, 44, 3, 1, 2, '2014-01-24 19:33:30', '2014-01-24 19:33:30', '', 1, 0, 0, 0, 0, 0),
(170, 36, 3, 1, 2, '2014-01-24 19:37:07', '2014-01-24 19:37:07', '', 1, 0, 0, 0, 0, 0),
(171, 29, 3, 1, 2, '2014-01-24 19:42:47', '2014-01-24 19:42:47', '', 1, 0, 0, 0, 0, 0),
(172, 54, 3, 1, 2, '2014-01-24 19:44:18', '2014-01-24 19:44:18', '', 1, 0, 0, 0, 0, 0),
(173, 31, 3, 1, 2, '2014-01-24 19:45:16', '2014-01-24 19:45:16', '', 1, 0, 0, 0, 0, 0),
(174, 35, 3, 1, 2, '2014-01-24 19:48:01', '2014-01-24 19:48:01', '', 1, 0, 0, 0, 0, 0),
(175, 53, 3, 1, 2, '2014-01-24 19:49:29', '2014-01-24 19:49:29', '', 1, 0, 0, 0, 0, 0),
(176, 37, 3, 1, 2, '2014-01-24 20:02:22', '2014-01-24 20:02:22', '', 1, 0, 0, 0, 0, 0),
(177, 55, 3, 1, 2, '2014-01-24 20:21:47', '2014-01-24 20:21:47', '', 1, 0, 0, 0, 0, 0),
(178, 2, 3, 1, 2, '2014-01-24 20:35:34', '2014-01-24 20:35:34', '', 1, 0, 0, 0, 0, 0),
(179, 40, 3, 1, 2, '2014-01-24 20:42:56', '2014-01-24 20:42:56', '', 1, 0, 0, 0, 0, 0),
(180, 39, 3, 1, 2, '2014-01-24 20:47:19', '2014-01-24 20:47:19', '', 1, 0, 0, 0, 0, 0),
(181, 46, 3, 1, 2, '2014-01-24 21:04:54', '2014-01-24 21:04:54', '', 1, 0, 0, 0, 0, 0),
(182, 52, 3, 1, 2, '2014-01-24 21:10:09', '2014-01-24 21:10:09', '', 1, 0, 0, 0, 0, 0),
(183, 40, 3, 1, 2, '2014-01-24 21:27:31', '2014-01-24 21:27:31', '', 1, 0, 0, 0, 0, 0),
(184, 46, 3, 1, 2, '2014-01-24 21:31:23', '2014-01-24 21:31:23', '', 1, 0, 0, 0, 0, 0),
(185, 40, 3, 1, 2, '2014-01-24 21:57:08', '2014-01-24 21:57:08', '', 1, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_session_detail`
--

CREATE TABLE IF NOT EXISTS `tbl_session_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idsession` int(11) NOT NULL,
  `idcourse` int(11) NOT NULL,
  `count` float NOT NULL,
  `price` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idsession` (`idsession`),
  KEY `idcourse` (`idcourse`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=957 ;

--
-- Dumping data for table `tbl_session_detail`
--

INSERT INTO `tbl_session_detail` (`id`, `idsession`, `idcourse`, `count`, `price`) VALUES
(778, 151, 520, 0.8, 300000),
(779, 152, 625, 2, 60000),
(780, 153, 605, 1, 70000),
(781, 151, 522, 2, 30000),
(782, 151, 531, 1, 40000),
(783, 154, 635, 0.55, 390000),
(784, 154, 188, 15, 16000),
(785, 155, 504, 1, 250000),
(786, 156, 504, 2, 230000),
(787, 156, 116, 10, 9500),
(788, 157, 605, 1, 70000),
(789, 157, 625, 1, 60000),
(790, 157, 637, 1, 10000),
(791, 157, 115, 12, 12000),
(793, 159, 620, 2, 68000),
(794, 159, 548, 3, 60000),
(795, 160, 585, 1, 55000),
(796, 160, 542, 2, 60000),
(797, 160, 607, 1, 78000),
(798, 160, 579, 1, 60000),
(799, 161, 601, 1, 78000),
(800, 161, 542, 1, 60000),
(801, 161, 531, 1, 40000),
(802, 162, 620, 1, 68000),
(803, 162, 548, 1, 60000),
(804, 162, 585, 3, 55000),
(806, 163, 631, 0.7, 180000),
(807, 163, 607, 1, 78000),
(808, 164, 620, 2, 68000),
(809, 164, 520, 0.8, 300000),
(810, 164, 522, 1, 30000),
(811, 164, 531, 1, 40000),
(812, 159, 607, 2, 78000),
(813, 161, 490, 2, 12000),
(814, 159, 520, 1.8, 300000),
(815, 159, 638, 1, 35000),
(817, 162, 579, 3, 60000),
(819, 165, 531, 1, 40000),
(820, 166, 542, 1, 60000),
(821, 164, 636, 4, 2000),
(822, 164, 637, 3, 10000),
(823, 164, 489, 20, 13000),
(824, 162, 490, 2, 12000),
(825, 163, 576, 1, 70000),
(826, 163, 115, 9, 12000),
(827, 163, 637, 1, 10000),
(828, 163, 636, 2, 2000),
(829, 160, 531, 1, 40000),
(830, 159, 583, 2, 70000),
(832, 167, 649, 1, 340000),
(834, 167, 608, 1, 280000),
(835, 168, 579, 1, 60000),
(836, 168, 528, 5, 15000),
(837, 168, 522, 1, 30000),
(838, 168, 606, 0.4, 190000),
(839, 165, 585, 1, 55000),
(840, 165, 607, 2, 78000),
(841, 169, 510, 1, 0),
(842, 169, 633, 1, 58000),
(843, 169, 542, 1, 60000),
(844, 169, 540, 1, 35000),
(845, 166, 503, 1, 230000),
(846, 166, 574, 1, 55000),
(847, 170, 496, 1, 55000),
(848, 168, 116, 10, 9000),
(849, 170, 531, 1, 40000),
(850, 170, 613, 2, 30000),
(851, 171, 536, 1, 40000),
(853, 171, 620, 1, 68000),
(854, 172, 607, 1, 78000),
(855, 172, 522, 1, 30000),
(856, 173, 632, 0.7, 110000),
(857, 173, 550, 2, 30000),
(858, 173, 532, 1, 40000),
(859, 173, 522, 2, 30000),
(860, 174, 528, 4, 15000),
(861, 174, 632, 1.1, 110000),
(862, 175, 616, 1, 58000),
(863, 175, 640, 3, 4000),
(867, 167, 490, 1, 12000),
(868, 167, 115, 17, 12000),
(869, 167, 636, 5, 2000),
(870, 172, 630, 0.3, 220000),
(871, 160, 492, 2, 75000),
(872, 160, 490, 3, 12000),
(873, 160, 637, 1, 10000),
(874, 176, 522, 1, 30000),
(875, 176, 613, 1, 30000),
(876, 176, 531, 1, 40000),
(877, 176, 411, 6, 10000),
(878, 165, 637, 1, 10000),
(879, 165, 115, 20, 12000),
(880, 174, 589, 1, 50000),
(881, 174, 637, 1, 10000),
(882, 174, 636, 4, 2000),
(883, 174, 115, 19, 12000),
(884, 159, 637, 1, 10000),
(885, 159, 115, 31, 12000),
(886, 159, 491, 2, 8000),
(887, 159, 640, 6, 4000),
(888, 169, 636, 4, 2000),
(889, 169, 637, 1, 10000),
(890, 169, 115, 20, 12000),
(891, 175, 654, 1, 35000),
(893, 175, 537, 1, 55000),
(894, 177, 587, 1, 60000),
(895, 177, 589, 1, 50000),
(896, 177, 613, 1, 30000),
(897, 177, 503, 1, 230000),
(899, 171, 548, 1, 60000),
(900, 171, 607, 1, 78000),
(901, 171, 640, 4, 4000),
(902, 178, 655, 0.55, 360000),
(903, 178, 587, 1, 60000),
(904, 178, 621, 1, 55000),
(905, 178, 522, 1, 30000),
(906, 178, 607, 1, 78000),
(907, 178, 531, 1, 40000),
(908, 171, 563, 2, 130000),
(909, 175, 548, 1, 60000),
(910, 175, 637, 3, 10000),
(911, 175, 115, 11, 12000),
(912, 179, 532, 1, 40000),
(913, 179, 520, 0.35, 300000),
(914, 179, 637, 1, 10000),
(915, 179, 115, 15, 12000),
(916, 180, 621, 1, 55000),
(917, 170, 616, 1, 58000),
(918, 170, 490, 1, 12000),
(919, 170, 115, 20, 12000),
(920, 170, 637, 2, 10000),
(921, 180, 522, 1, 30000),
(922, 180, 640, 2, 4000),
(923, 173, 636, 4, 2000),
(924, 173, 115, 16, 12000),
(925, 181, 622, 0.65, 180000),
(926, 181, 604, 0.6, 290000),
(927, 177, 648, 1, 30000),
(929, 182, 619, 2, 35000),
(930, 182, 531, 1, 40000),
(931, 182, 620, 1, 68000),
(932, 183, 491, 1, 8000),
(933, 183, 115, 6, 12000),
(934, 171, 188, 36, 16000),
(935, 171, 637, 3, 10000),
(936, 181, 620, 1, 68000),
(937, 184, 620, 1, 68000),
(938, 166, 652, 1, 30000),
(939, 166, 636, 1, 2000),
(940, 166, 637, 1, 10000),
(941, 166, 115, 35, 12000),
(942, 172, 490, 1, 12000),
(943, 172, 115, 13, 12000),
(944, 178, 190, 11, 12000),
(945, 178, 636, 4, 2000),
(946, 178, 637, 1, 10000),
(947, 180, 637, 2, 10000),
(948, 180, 636, 1, 2000),
(949, 180, 115, 11, 12000),
(950, 177, 115, 27, 12000),
(951, 177, 637, 1, 10000),
(952, 185, 115, 4, 12000),
(953, 185, 637, 1, 10000),
(954, 182, 656, 1, 60000),
(955, 182, 637, 1, 10000),
(956, 182, 115, 38, 12000);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_store`
--

CREATE TABLE IF NOT EXISTS `tbl_store` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(125) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_store`
--

INSERT INTO `tbl_store` (`id`, `name`, `note`) VALUES
(1, 'Kho nhà', 'Ghi chú gì đây ?');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_supplier`
--

CREATE TABLE IF NOT EXISTS `tbl_supplier` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `debt` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=29 ;

--
-- Dumping data for table `tbl_supplier`
--

INSERT INTO `tbl_supplier` (`id`, `name`, `phone`, `address`, `note`, `debt`) VALUES
(13, 'CÁ - CUA - GHẸ SỐNG', '', 'Can Tho', '', 0),
(14, 'NƯỚC ĐÁ - ĐL TRÍ', '', 'Vĩnh Long', '', 0),
(15, 'NGHÊU - SÒ - MỰC', '', 'Cần thơ', '', 0),
(16, 'RAU QUẢ', '', 'Chợ Vĩnh long', '', 0),
(17, 'GIA VỊ - TẠP HÓA A', '', 'Chợ Vĩnh long', '', 0),
(18, 'GIA CẦM - CH A', '', 'Vĩnh long', '', 0),
(19, 'HÀNG CẤP ĐÔNG - METRO CẦN THƠ', '', 'Metro Cần Thơ', '', 0),
(20, 'GAS - CTY A', '', 'Vĩnh long', '', 0),
(21, 'BIA - CTY CP DU LỊCH CỬU LONG', '0703 828 042', 'Chưa cập nhật', '', 0),
(22, 'NƯỚC GIẢI KHÁT - NPP ĐOAN TRANG', '', 'Đoan trang', '', 0),
(23, 'RƯỢU - NPP CẦN THƠ', '', '', '', 0),
(24, 'Rượu nội', '', '', '', 0),
(25, 'Vật dụng bếp', '', '', '', 0),
(26, 'Vật dụng tổ bàn', '', '', '', 0),
(27, 'TẠP HÓA 01', '', 'Chợ  Vĩnh long', '', 0),
(28, 'BIA - CTY SAGOTA', 'Chưa cập nhật', 'Chưa cập nhật', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_table`
--

CREATE TABLE IF NOT EXISTS `tbl_table` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iddomain` int(11) NOT NULL,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `iduser` int(11) DEFAULT NULL,
  `type` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `iddomain` (`iddomain`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=75 ;

--
-- Dumping data for table `tbl_table`
--

INSERT INTO `tbl_table` (`id`, `iddomain`, `name`, `iduser`, `type`) VALUES
(1, 1, 'CÁNH BUỒM', 1, '0'),
(2, 1, 'HẢI ĐĂNG', 1, '0'),
(14, 2, 'SAO BIỂN', 1, '0'),
(15, 2, 'NGỌC TRAI', 1, '0'),
(16, 2, 'BIỂN XANH', 1, '0'),
(26, 3, '001', 1, '0'),
(27, 3, '002', 1, '0'),
(28, 3, '003', 1, '0'),
(29, 3, '004', 1, '0'),
(30, 3, '005', 1, '0'),
(31, 3, '006', 1, '0'),
(32, 3, '007', 1, '0'),
(33, 3, '008', 1, '0'),
(34, 4, '015', 1, '0'),
(35, 4, '016', 1, '0'),
(36, 4, '017', 1, '0'),
(37, 4, '018', 1, '0'),
(38, 4, '019', 1, '0'),
(39, 4, '020', 1, '0'),
(40, 4, '021', 1, '0'),
(41, 4, '022', 1, '0'),
(44, 1, 'THUYỀN TRƯỞNG', 1, '0'),
(46, 5, 'MANG VỀ 01', 1, '0'),
(49, 3, '009', 1, '0'),
(50, 3, '010', 1, '0'),
(51, 3, '011', 1, '0'),
(52, 3, '012', 1, '0'),
(53, 3, 'KT13', 1, '0'),
(54, 3, 'KT14', 1, '0'),
(55, 4, '023', 1, '0'),
(56, 4, '024', 1, '0'),
(57, 4, '025', 1, '0'),
(58, 4, '026', 1, '0'),
(59, 4, 'KN27', 1, '0'),
(60, 4, 'KN28', 1, '0'),
(61, 4, 'KN29', 1, '0'),
(62, 4, 'KN30', 1, '0'),
(63, 4, 'KN31', 1, '0'),
(64, 4, 'KN32', 1, '0'),
(65, 4, 'KN33', 1, '0'),
(66, 4, 'KN34', 1, '0'),
(67, 4, 'KN35', 1, '0'),
(68, 4, 'KN36', 1, '0'),
(69, 4, 'KN37', 1, '0'),
(70, 5, 'MANG VỀ 02', 1, '0'),
(71, 5, 'MANG VỀ 03', 1, '0'),
(72, 7, 'ĐẶT TIỆC 01', 1, '0'),
(73, 7, 'ĐẶT TIỆC 02', 1, '0'),
(74, 7, 'ĐẶT TIỆC 03', 1, '0');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_table_log`
--

CREATE TABLE IF NOT EXISTS `tbl_table_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iduser` int(11) NOT NULL,
  `idtable` int(11) NOT NULL,
  `datetime` datetime NOT NULL,
  `note` varchar(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=909 ;

--
-- Dumping data for table `tbl_table_log`
--

INSERT INTO `tbl_table_log` (`id`, `iduser`, `idtable`, `datetime`, `note`) VALUES
(520, 3, 1, '2014-01-23 22:37:54', 'Tạo mới giao dịch'),
(521, 3, 1, '2014-01-23 22:37:54', 'Cập nhật món Bò Bốp Thấu '),
(522, 3, 1, '2014-01-23 22:37:57', 'Cập nhật món Bò Bốp Thấu 2'),
(523, 3, 1, '2014-01-23 22:37:57', 'Cập nhật món Bò Bốp Thấu 3'),
(524, 1, 1, '2014-01-23 22:45:10', 'tính tiền 27.000'),
(525, 3, 1, '2014-01-23 23:06:41', 'Tạo mới giao dịch'),
(526, 3, 1, '2014-01-23 23:06:41', 'Cập nhật món Cá  Quế Nấu Lẩu '),
(527, 3, 1, '2014-01-23 23:06:42', 'Cập nhật món Cá  Quế Nướng Muối Ớt Cay '),
(528, 3, 1, '2014-01-24 15:47:32', 'Cập nhật món Cánh gà chiên nướng mắm '),
(529, 3, 1, '2014-01-24 15:47:35', 'Cập nhật món Cánh gà nướng chao '),
(530, 3, 2, '2014-01-24 15:49:53', 'Tạo mới giao dịch'),
(531, 3, 2, '2014-01-24 15:49:53', 'Cập nhật món Cánh gà chiên nướng mắm '),
(532, 3, 2, '2014-01-24 15:49:58', 'Cập nhật món 333 chai '),
(533, 3, 2, '2014-01-24 15:49:59', 'Cập nhật món Heneiken chai '),
(534, 3, 2, '2014-01-24 15:50:01', 'Cập nhật món Nước ngọt '),
(535, 3, 2, '2014-01-24 17:23:19', 'Tạo mới giao dịch'),
(536, 3, 2, '2014-01-24 17:23:19', 'Cập nhật món Ghẹ '),
(537, 3, 49, '2014-01-24 17:24:19', 'Tạo mới giao dịch'),
(538, 3, 49, '2014-01-24 17:24:19', 'Cập nhật món Ca bop phan '),
(539, 3, 49, '2014-01-24 17:24:19', 'Cập nhật món Ca bop phan 2'),
(540, 3, 38, '2014-01-24 17:25:06', 'Tạo mới giao dịch'),
(541, 3, 38, '2014-01-24 17:25:06', 'Cập nhật món Bach tuoc phan '),
(542, 3, 2, '2014-01-24 17:25:37', 'Cập nhật món Ngheu hap sa '),
(543, 3, 2, '2014-01-24 17:25:37', 'Cập nhật món Ngheu hap sa 2'),
(544, 3, 2, '2014-01-24 17:25:58', 'Cập nhật món So huyet rang muoi / rang me '),
(545, 3, 46, '2014-01-24 17:32:07', 'Tạo mới giao dịch'),
(546, 3, 46, '2014-01-24 17:32:07', 'Cập nhật món ca ngu dai duong kg '),
(547, 3, 46, '2014-01-24 17:33:35', 'Cập nhật món Heneiken chai '),
(548, 3, 46, '2014-01-24 17:33:35', 'Cập nhật món Heneiken chai 2'),
(549, 1, 46, '2014-01-24 17:36:18', 'tính tiền 454.000'),
(550, 3, 46, '2014-01-24 17:42:07', 'Tạo mới giao dịch'),
(551, 3, 46, '2014-01-24 17:42:07', 'Cập nhật món Gà ta hấp hành '),
(552, 1, 46, '2014-01-24 17:43:23', 'tính tiền 250.000'),
(553, 1, 2, '2014-01-24 17:43:33', 'tính tiền 340.000'),
(554, 1, 49, '2014-01-24 17:43:38', 'tính tiền 120.000'),
(555, 1, 38, '2014-01-24 17:43:41', 'tính tiền 70.000'),
(556, 3, 1, '2014-01-24 17:51:51', 'Tạo mới giao dịch'),
(557, 3, 1, '2014-01-24 17:51:51', 'Cập nhật món Gà ta hấp hành '),
(558, 3, 1, '2014-01-24 17:51:51', 'Cập nhật món Gà ta hấp hành 2'),
(559, 3, 1, '2014-01-24 17:52:17', 'Cập nhật món SG đỏ '),
(560, 3, 1, '2014-01-24 17:52:17', 'Cập nhật món SG đỏ 2'),
(561, 3, 38, '2014-01-24 17:55:21', 'Tạo mới giao dịch'),
(562, 3, 38, '2014-01-24 17:55:21', 'Cập nhật món Bach tuoc phan '),
(563, 3, 38, '2014-01-24 17:55:49', 'Cập nhật món Ca bop phan '),
(564, 3, 38, '2014-01-24 17:56:07', 'Cập nhật món dau '),
(565, 3, 38, '2014-01-24 17:56:07', 'Cập nhật món dau 2'),
(566, 3, 38, '2014-01-24 17:56:09', 'Cập nhật món dau 3'),
(567, 3, 38, '2014-01-24 17:56:38', 'Cập nhật món SG special chai '),
(568, 3, 38, '2014-01-24 17:56:38', 'Cập nhật món SG special chai 2'),
(569, 1, 38, '2014-01-24 17:59:46', 'tính tiền 284.000'),
(570, 3, 59, '2014-01-24 18:04:07', 'Tạo mới giao dịch'),
(571, 3, 59, '2014-01-24 18:04:07', 'Cập nhật món Muc hap gung '),
(572, 3, 59, '2014-01-24 18:04:08', 'Cập nhật món Muc hap gung 2'),
(573, 1, 1, '2014-01-24 18:05:47', 'tính tiền 555.000'),
(574, 3, 1, '2014-01-24 18:06:34', 'Tạo mới giao dịch'),
(575, 3, 1, '2014-01-24 18:06:34', 'Cập nhật món Ca cam con '),
(576, 3, 1, '2014-01-24 18:07:51', 'Cập nhật món Com chien Lang Bien '),
(577, 3, 33, '2014-01-24 18:08:59', 'Tạo mới giao dịch'),
(578, 3, 33, '2014-01-24 18:08:59', 'Cập nhật món Cha gio Lang Bien '),
(579, 3, 33, '2014-01-24 18:09:10', 'Cập nhật món Mi xao hai san '),
(580, 3, 33, '2014-01-24 18:09:11', 'Cập nhật món Mi xao hai san 2'),
(581, 3, 33, '2014-01-24 18:09:38', 'Cập nhật món Muc trung Phu Quoc phan '),
(582, 3, 33, '2014-01-24 18:10:22', 'Cập nhật món Mat ca ngu dai duong hap '),
(583, 3, 33, '2014-01-24 18:10:22', 'Cập nhật món Mat ca ngu dai duong hap 2'),
(584, 3, 36, '2014-01-24 18:11:51', 'Tạo mới giao dịch'),
(585, 3, 36, '2014-01-24 18:11:51', 'Cập nhật món Muc ong phan '),
(586, 3, 36, '2014-01-24 18:11:52', 'Cập nhật món Muc ong phan 2'),
(587, 3, 36, '2014-01-24 18:12:06', 'Cập nhật món Mi xao hai san '),
(588, 3, 36, '2014-01-24 18:12:22', 'Cập nhật món So huyet rang muoi / rang me '),
(589, 3, 40, '2014-01-24 18:13:09', 'Tạo mới giao dịch'),
(590, 3, 40, '2014-01-24 18:13:09', 'Cập nhật món Ca cam con '),
(591, 3, 40, '2014-01-24 18:13:22', 'Cập nhật món Com chien Lang Bien '),
(592, 3, 40, '2014-01-24 18:13:48', 'Cập nhật món Cha gio Lang Bien '),
(593, 3, 40, '2014-01-24 18:13:49', 'Cập nhật món Cha gio Lang Bien 2'),
(594, 3, 40, '2014-01-24 18:13:49', 'Cập nhật món Cha gio Lang Bien 3'),
(595, 3, 39, '2014-01-24 18:14:43', 'Tạo mới giao dịch'),
(596, 3, 39, '2014-01-24 18:14:43', 'Cập nhật món Ca bo da '),
(597, 3, 39, '2014-01-24 18:15:34', 'Cập nhật món Ca bo da '),
(598, 3, 39, '2014-01-24 18:15:35', 'Cập nhật món Ca bo da 2'),
(599, 3, 39, '2014-01-24 18:16:07', 'Cập nhật món Muc trung Phu Quoc phan '),
(600, 3, 2, '2014-01-24 18:16:46', 'Tạo mới giao dịch'),
(601, 3, 2, '2014-01-24 18:16:46', 'Cập nhật món Ca cam con '),
(602, 3, 2, '2014-01-24 18:16:46', 'Cập nhật món Ca cam con 2'),
(603, 3, 2, '2014-01-24 18:16:58', 'Cập nhật món Ghẹ '),
(604, 3, 2, '2014-01-24 18:17:44', 'Cập nhật món Ngheu hap sa '),
(605, 3, 2, '2014-01-24 18:18:04', 'Cập nhật món So huyet rang muoi / rang me '),
(606, 3, 1, '2014-01-24 18:18:35', 'Cập nhật món Muc trung Phu Quoc phan '),
(607, 3, 36, '2014-01-24 18:26:29', 'Cập nhật món Nước ngọt '),
(608, 3, 36, '2014-01-24 18:26:30', 'Cập nhật món Nước ngọt 2'),
(609, 1, 36, '2014-01-24 18:31:07', 'tính tiền 202.000'),
(610, 3, 1, '2014-01-24 18:33:54', 'Cập nhật món Ghẹ '),
(611, 3, 1, '2014-01-24 18:33:54', 'Cập nhật món Ghẹ 2'),
(612, 3, 1, '2014-01-24 18:33:54', 'Cập nhật món Ghẹ 3'),
(613, 3, 1, '2014-01-24 18:34:19', 'Cập nhật món bo tat chai '),
(614, 3, 1, '2014-01-24 18:34:20', 'Cập nhật món bo tat chai 2'),
(615, 3, 1, '2014-01-24 18:34:38', 'Cập nhật món Com chien Lang Bien 3'),
(616, 3, 1, '2014-01-24 18:34:42', 'Cập nhật món Com chien Lang Bien 4'),
(617, 3, 1, '2014-01-24 18:34:42', 'Cập nhật món Com chien Lang Bien 5'),
(618, 3, 1, '2014-01-24 18:34:45', 'Cập nhật món Com chien Lang Bien 6'),
(619, 3, 1, '2014-01-24 18:34:48', 'Cập nhật món Com chien Lang Bien 7'),
(620, 3, 1, '2014-01-24 18:34:50', 'Cập nhật món Com chien Lang Bien '),
(621, 3, 1, '2014-01-24 18:34:50', 'Cập nhật món Com chien Lang Bien 2'),
(622, 3, 1, '2014-01-24 18:34:51', 'Cập nhật món Com chien Lang Bien 3'),
(623, 3, 40, '2014-01-24 18:35:21', 'Cập nhật món Mat ca ngu dai duong hap '),
(624, 3, 40, '2014-01-24 18:35:21', 'Cập nhật món Mat ca ngu dai duong hap 2'),
(625, 3, 40, '2014-01-24 18:35:22', 'Cập nhật món Mat ca ngu dai duong hap 3'),
(626, 3, 38, '2014-01-24 18:37:31', 'Tạo mới giao dịch'),
(627, 3, 38, '2014-01-24 18:37:31', 'Cập nhật món Muc la phan '),
(628, 3, 38, '2014-01-24 18:38:43', 'Cập nhật món So huyet rang muoi / rang me '),
(629, 3, 34, '2014-01-24 18:39:17', 'Tạo mới giao dịch'),
(630, 3, 34, '2014-01-24 18:39:17', 'Cập nhật món Mi xao hai san '),
(631, 3, 34, '2014-01-24 18:39:17', 'Cập nhật món Mi xao hai san 2'),
(632, 3, 2, '2014-01-24 18:42:08', 'Cập nhật món khan '),
(633, 3, 2, '2014-01-24 18:42:33', 'Cập nhật món dau '),
(634, 3, 2, '2014-01-24 18:42:34', 'Cập nhật món dau 2'),
(635, 3, 2, '2014-01-24 18:42:37', 'Cập nhật món dau 3'),
(636, 3, 2, '2014-01-24 18:42:52', 'Cập nhật món SG lon xanh '),
(637, 3, 2, '2014-01-24 18:42:53', 'Cập nhật món SG lon xanh 2'),
(638, 1, 2, '2014-01-24 18:45:37', 'tính tiền 744.000'),
(639, 3, 40, '2014-01-24 19:04:06', 'Cập nhật món Nước ngọt '),
(640, 3, 40, '2014-01-24 19:04:06', 'Cập nhật món Nước ngọt 2'),
(641, 1, 40, '2014-01-24 19:06:56', 'tính tiền 497.000'),
(642, 3, 39, '2014-01-24 19:13:02', 'Cập nhật món Goi bo ba khia Lang Bien '),
(643, 3, 39, '2014-01-24 19:13:32', 'Cập nhật món SG special chai '),
(644, 3, 39, '2014-01-24 19:13:54', 'Cập nhật món dau '),
(645, 3, 39, '2014-01-24 19:14:02', 'Cập nhật món khan '),
(646, 3, 33, '2014-01-24 19:21:17', 'Cập nhật món So huyet rang muoi / rang me '),
(647, 3, 33, '2014-01-24 19:21:18', 'Cập nhật món So huyet rang muoi / rang me 2'),
(648, 3, 1, '2014-01-24 19:23:09', 'Cập nhật món Dau hu Lang Bien '),
(649, 3, 1, '2014-01-24 19:23:10', 'Cập nhật món Dau hu Lang Bien 2'),
(650, 3, 52, '2014-01-24 19:23:52', 'Tạo mới giao dịch'),
(651, 3, 52, '2014-01-24 19:23:52', 'Cập nhật món Muc trung Phu Quoc phan '),
(652, 3, 52, '2014-01-24 19:25:53', 'Cập nhật món ca chach hue '),
(653, 3, 52, '2014-01-24 19:25:53', 'Cập nhật món ca chach hue 2'),
(654, 3, 52, '2014-01-24 19:25:53', 'Cập nhật món ca chach hue 3'),
(655, 3, 52, '2014-01-24 19:26:08', 'Cập nhật món Com chay nuong Lang Bien '),
(656, 3, 52, '2014-01-24 19:26:08', 'Cập nhật món Com chay nuong Lang Bien 2'),
(657, 3, 52, '2014-01-24 19:26:08', 'Cập nhật món Com chay nuong Lang Bien 3'),
(658, 3, 52, '2014-01-24 19:26:53', 'Cập nhật món Muc trung Phu Quoc kg '),
(659, 3, 52, '2014-01-24 19:26:53', 'Cập nhật món Muc trung Phu Quoc kg 2'),
(660, 3, 41, '2014-01-24 19:28:34', 'Tạo mới giao dịch'),
(661, 3, 41, '2014-01-24 19:28:34', 'Cập nhật món Mat ca ngu dai duong hap '),
(662, 3, 41, '2014-01-24 19:29:00', 'Cập nhật món Hau nuong mo hanh '),
(663, 3, 41, '2014-01-24 19:29:18', 'Cập nhật món Ngheu hap sa '),
(664, 3, 41, '2014-01-24 19:29:18', 'Cập nhật món Ngheu hap sa 2'),
(665, 3, 41, '2014-01-24 19:29:34', 'Cập nhật món Bach tuoc kg '),
(666, 3, 41, '2014-01-24 19:29:34', 'Cập nhật món Bach tuoc kg 2'),
(667, 3, 38, '2014-01-24 19:31:01', 'Cập nhật món Cha gio Lang Bien '),
(668, 3, 38, '2014-01-24 19:31:02', 'Cập nhật món Cha gio Lang Bien 2'),
(669, 3, 38, '2014-01-24 19:31:17', 'Cập nhật món Muc trung Phu Quoc phan '),
(670, 3, 38, '2014-01-24 19:31:17', 'Cập nhật món Muc trung Phu Quoc phan 2'),
(671, 3, 44, '2014-01-24 19:33:30', 'Tạo mới giao dịch'),
(672, 3, 44, '2014-01-24 19:33:30', 'Cập nhật món Heo sữa quay phần '),
(673, 3, 44, '2014-01-24 19:33:30', 'Cập nhật món Heo sữa quay phần 2'),
(674, 3, 44, '2014-01-24 19:33:30', 'Cập nhật món Heo sữa quay phần 3'),
(675, 3, 44, '2014-01-24 19:33:59', 'Cập nhật món ca gion phan '),
(676, 3, 44, '2014-01-24 19:34:00', 'Cập nhật món ca gion phan 2'),
(677, 3, 44, '2014-01-24 19:34:00', 'Cập nhật món ca gion phan 3'),
(678, 3, 44, '2014-01-24 19:34:12', 'Cập nhật món Mi xao hai san '),
(679, 3, 44, '2014-01-24 19:34:12', 'Cập nhật món Mi xao hai san 2'),
(680, 3, 44, '2014-01-24 19:34:12', 'Cập nhật món Mi xao hai san 3'),
(681, 3, 44, '2014-01-24 19:34:46', 'Cập nhật món Oc buou nuong tieu '),
(682, 3, 34, '2014-01-24 19:35:58', 'Cập nhật món Gà tà nướng muối ớt '),
(683, 3, 34, '2014-01-24 19:35:58', 'Cập nhật món Gà tà nướng muối ớt 2'),
(684, 3, 34, '2014-01-24 19:36:25', 'Cập nhật món Goi xoai kho ca loc '),
(685, 3, 36, '2014-01-24 19:37:07', 'Tạo mới giao dịch'),
(686, 3, 36, '2014-01-24 19:37:07', 'Cập nhật món Cánh gà chiên nướng mắm '),
(687, 3, 36, '2014-01-24 19:37:08', 'Cập nhật món Cánh gà chiên nướng mắm 2'),
(688, 3, 36, '2014-01-24 19:37:08', 'Cập nhật món Cánh gà chiên nướng mắm 3'),
(689, 3, 41, '2014-01-24 19:38:03', 'Cập nhật món SG đỏ '),
(690, 3, 41, '2014-01-24 19:38:03', 'Cập nhật món SG đỏ 2'),
(691, 3, 41, '2014-01-24 19:38:04', 'Cập nhật món SG đỏ 3'),
(692, 1, 41, '2014-01-24 19:40:43', 'tính tiền 331.000'),
(693, 3, 36, '2014-01-24 19:41:23', 'Cập nhật món So huyet rang muoi / rang me '),
(694, 3, 36, '2014-01-24 19:41:23', 'Cập nhật món So huyet rang muoi / rang me 2'),
(695, 3, 36, '2014-01-24 19:41:41', 'Cập nhật món dau hu chien xa ot '),
(696, 3, 36, '2014-01-24 19:41:41', 'Cập nhật món dau hu chien xa ot 2'),
(697, 3, 29, '2014-01-24 19:42:47', 'Tạo mới giao dịch'),
(698, 3, 29, '2014-01-24 19:42:47', 'Cập nhật món So veo nuong mo hanh '),
(699, 3, 29, '2014-01-24 19:43:12', 'Cập nhật món Com chay nuong Lang Bien '),
(700, 3, 29, '2014-01-24 19:43:13', 'Cập nhật món Com chay nuong Lang Bien 2'),
(701, 3, 29, '2014-01-24 19:43:13', 'Cập nhật món Com chay nuong Lang Bien 3'),
(702, 3, 29, '2014-01-24 19:43:26', 'Cập nhật món Ca cam con '),
(703, 3, 54, '2014-01-24 19:44:18', 'Tạo mới giao dịch'),
(704, 3, 54, '2014-01-24 19:44:18', 'Cập nhật món Muc trung Phu Quoc phan '),
(705, 3, 54, '2014-01-24 19:44:18', 'Cập nhật món Muc trung Phu Quoc phan 2'),
(706, 3, 54, '2014-01-24 19:44:18', 'Cập nhật món Muc trung Phu Quoc phan 3'),
(707, 3, 54, '2014-01-24 19:44:33', 'Cập nhật món Ngheu hap sa '),
(708, 3, 31, '2014-01-24 19:45:16', 'Tạo mới giao dịch'),
(709, 3, 31, '2014-01-24 19:45:16', 'Cập nhật món Ca bo vay '),
(710, 3, 31, '2014-01-24 19:45:16', 'Cập nhật món Ca bo vay 2'),
(711, 3, 31, '2014-01-24 19:45:40', 'Cập nhật món Com chien toi '),
(712, 3, 31, '2014-01-24 19:46:17', 'Cập nhật món So huyet rang muoi / rang me '),
(713, 3, 31, '2014-01-24 19:46:17', 'Cập nhật món So huyet rang muoi / rang me 2'),
(714, 3, 31, '2014-01-24 19:46:38', 'Cập nhật món Ngheu hap sa '),
(715, 3, 31, '2014-01-24 19:46:38', 'Cập nhật món Ngheu hap sa 2'),
(716, 3, 35, '2014-01-24 19:48:01', 'Tạo mới giao dịch'),
(717, 3, 35, '2014-01-24 19:48:01', 'Cập nhật món Hau nuong mo hanh '),
(718, 3, 35, '2014-01-24 19:48:26', 'Cập nhật món Ca bo vay '),
(719, 3, 35, '2014-01-24 19:48:27', 'Cập nhật món Ca bo vay 2'),
(720, 3, 35, '2014-01-24 19:48:27', 'Cập nhật món Ca bo vay 3'),
(721, 3, 53, '2014-01-24 19:49:29', 'Tạo mới giao dịch'),
(722, 3, 53, '2014-01-24 19:49:29', 'Cập nhật món Ca sapa con '),
(723, 3, 53, '2014-01-24 19:49:29', 'Cập nhật món Ca sapa con 2'),
(724, 3, 53, '2014-01-24 19:49:44', 'Cập nhật món banh mi '),
(725, 3, 53, '2014-01-24 19:49:44', 'Cập nhật món banh mi 2'),
(726, 3, 53, '2014-01-24 19:50:10', 'Cập nhật món khan '),
(727, 3, 53, '2014-01-24 19:50:10', 'Cập nhật món khan 2'),
(728, 3, 53, '2014-01-24 19:50:11', 'Cập nhật món khan 3'),
(729, 3, 53, '2014-01-24 19:50:49', 'Cập nhật món SG special chai '),
(730, 3, 53, '2014-01-24 19:50:49', 'Cập nhật món SG special chai 2'),
(731, 3, 53, '2014-01-24 19:51:13', 'Cập nhật món Nước ngọt '),
(732, 3, 53, '2014-01-24 19:51:14', 'Cập nhật món Nước ngọt 2'),
(733, 3, 53, '2014-01-24 19:51:15', 'Cập nhật món Nước ngọt 3'),
(734, 3, 53, '2014-01-24 19:51:15', 'Cập nhật món Nước ngọt 4'),
(735, 3, 52, '2014-01-24 19:52:54', 'Cập nhật món Nước ngọt '),
(736, 3, 52, '2014-01-24 19:52:56', 'Cập nhật món SG special chai '),
(737, 3, 52, '2014-01-24 19:52:56', 'Cập nhật món SG special chai 2'),
(738, 3, 52, '2014-01-24 19:53:11', 'Cập nhật món khan '),
(739, 3, 52, '2014-01-24 19:53:11', 'Cập nhật món khan 2'),
(740, 3, 54, '2014-01-24 19:55:15', 'Cập nhật món Ca nau '),
(741, 3, 33, '2014-01-24 19:59:30', 'Cập nhật món Phú Lễ '),
(742, 3, 33, '2014-01-24 19:59:31', 'Cập nhật món Phú Lễ 2'),
(743, 3, 33, '2014-01-24 19:59:33', 'Cập nhật món Phú Lễ 3'),
(744, 3, 33, '2014-01-24 19:59:33', 'Cập nhật món Phú Lễ 4'),
(745, 3, 33, '2014-01-24 20:00:07', 'Cập nhật món Nước ngọt '),
(746, 3, 33, '2014-01-24 20:00:07', 'Cập nhật món Nước ngọt 2'),
(747, 3, 33, '2014-01-24 20:00:32', 'Cập nhật món dau '),
(748, 3, 37, '2014-01-24 20:02:22', 'Tạo mới giao dịch'),
(749, 3, 37, '2014-01-24 20:02:22', 'Cập nhật món Ngheu hap sa '),
(750, 3, 37, '2014-01-24 20:02:32', 'Cập nhật món dau hu chien xa ot '),
(751, 3, 37, '2014-01-24 20:02:45', 'Cập nhật món So huyet rang muoi / rang me '),
(752, 3, 37, '2014-01-24 20:02:58', 'Cập nhật món 333 chai '),
(753, 1, 37, '2014-01-24 20:05:30', 'tính tiền 160.000'),
(754, 3, 38, '2014-01-24 20:06:13', 'Cập nhật món dau '),
(755, 3, 38, '2014-01-24 20:06:44', 'Cập nhật món SG special chai '),
(756, 3, 35, '2014-01-24 20:08:27', 'Cập nhật món Com chay nuong Lang Bien '),
(757, 3, 35, '2014-01-24 20:08:37', 'Cập nhật món dau '),
(758, 3, 35, '2014-01-24 20:08:46', 'Cập nhật món khan '),
(759, 3, 35, '2014-01-24 20:09:02', 'Cập nhật món SG special chai '),
(760, 1, 38, '2014-01-24 20:09:55', 'tính tiền 501.000'),
(761, 3, 1, '2014-01-24 20:11:42', 'Cập nhật món dau '),
(762, 3, 1, '2014-01-24 20:12:02', 'Cập nhật món SG special chai '),
(763, 3, 1, '2014-01-24 20:12:22', 'Cập nhật món Nước suối '),
(764, 3, 1, '2014-01-24 20:12:44', 'Cập nhật món banh mi '),
(765, 3, 1, '2014-01-24 20:12:48', 'Cập nhật món banh mi 2'),
(766, 3, 1, '2014-01-24 20:12:51', 'Cập nhật món banh mi 3'),
(767, 3, 1, '2014-01-24 20:12:51', 'Cập nhật món banh mi 4'),
(768, 3, 1, '2014-01-24 20:12:52', 'Cập nhật món banh mi 5'),
(769, 3, 1, '2014-01-24 20:12:53', 'Cập nhật món banh mi 6'),
(770, 3, 1, '2014-01-24 20:12:54', 'Cập nhật món banh mi 7'),
(771, 3, 44, '2014-01-24 20:14:14', 'Cập nhật món khan '),
(772, 3, 44, '2014-01-24 20:14:15', 'Cập nhật món khan 2'),
(773, 3, 44, '2014-01-24 20:14:16', 'Cập nhật món khan 3'),
(774, 3, 44, '2014-01-24 20:14:17', 'Cập nhật món khan 4'),
(775, 3, 44, '2014-01-24 20:14:24', 'Cập nhật món dau '),
(776, 3, 44, '2014-01-24 20:14:29', 'Cập nhật món SG special chai '),
(777, 1, 35, '2014-01-24 20:15:24', 'tính tiền 477.000'),
(778, 1, 33, '2014-01-24 20:15:41', 'tính tiền 549.000'),
(779, 3, 53, '2014-01-24 20:18:26', 'Cập nhật món trung chien '),
(780, 3, 53, '2014-01-24 20:19:13', 'Cập nhật món Com chien toi '),
(781, 3, 53, '2014-01-24 20:19:28', 'Cập nhật món Oc mo xao toi '),
(782, 3, 53, '2014-01-24 20:19:57', 'Cập nhật món banh mi 4'),
(783, 3, 53, '2014-01-24 20:20:00', 'Cập nhật món banh mi 5'),
(784, 3, 53, '2014-01-24 20:20:02', 'Cập nhật món banh mi 6'),
(785, 3, 53, '2014-01-24 20:20:05', 'Cập nhật món banh mi 7'),
(786, 1, 1, '2014-01-24 20:20:37', 'tính tiền 1.609.000'),
(787, 1, 44, '2014-01-24 20:20:45', 'tính tiền 411.000'),
(788, 3, 55, '2014-01-24 20:21:47', 'Tạo mới giao dịch'),
(789, 3, 55, '2014-01-24 20:21:47', 'Cập nhật món Com chien Lang Bien '),
(790, 3, 55, '2014-01-24 20:21:59', 'Cập nhật món Com chay nuong Lang Bien '),
(791, 3, 55, '2014-01-24 20:22:20', 'Cập nhật món dau hu chien xa ot '),
(792, 3, 55, '2014-01-24 20:26:48', 'Cập nhật món Gà tà nướng muối ớt '),
(793, 3, 55, '2014-01-24 20:27:05', 'Cập nhật món So huyet rang muoi / rang me '),
(794, 3, 29, '2014-01-24 20:28:02', 'Cập nhật món Com chien Lang Bien '),
(795, 3, 29, '2014-01-24 20:28:34', 'Cập nhật món Muc trung Phu Quoc phan '),
(796, 3, 29, '2014-01-24 20:28:54', 'Cập nhật món banh mi '),
(797, 3, 29, '2014-01-24 20:28:57', 'Cập nhật món banh mi 2'),
(798, 3, 29, '2014-01-24 20:28:58', 'Cập nhật món banh mi 3'),
(799, 3, 29, '2014-01-24 20:28:59', 'Cập nhật món banh mi 4'),
(800, 3, 2, '2014-01-24 20:35:34', 'Tạo mới giao dịch'),
(801, 3, 2, '2014-01-24 20:35:34', 'Cập nhật món ca bong tuong '),
(802, 3, 2, '2014-01-24 20:36:36', 'Cập nhật món Com chien Lang Bien '),
(803, 3, 2, '2014-01-24 20:36:51', 'Cập nhật món Ca duoi phan '),
(804, 3, 2, '2014-01-24 20:37:01', 'Cập nhật món Ngheu hap sa '),
(805, 3, 2, '2014-01-24 20:37:30', 'Cập nhật món Muc trung Phu Quoc phan '),
(806, 3, 2, '2014-01-24 20:37:54', 'Cập nhật món So huyet rang muoi / rang me '),
(807, 3, 29, '2014-01-24 20:38:57', 'Cập nhật món Lau ca Bop '),
(808, 3, 29, '2014-01-24 20:38:57', 'Cập nhật món Lau ca Bop 2'),
(809, 3, 53, '2014-01-24 20:39:58', 'Cập nhật món Com chien Lang Bien '),
(810, 3, 53, '2014-01-24 20:40:27', 'Cập nhật món dau '),
(811, 3, 53, '2014-01-24 20:40:28', 'Cập nhật món dau 2'),
(812, 3, 53, '2014-01-24 20:40:29', 'Cập nhật món dau 3'),
(813, 3, 53, '2014-01-24 20:40:37', 'Cập nhật món SG special chai '),
(814, 1, 53, '2014-01-24 20:42:33', 'tính tiền 382.000'),
(815, 3, 40, '2014-01-24 20:42:56', 'Tạo mới giao dịch'),
(816, 3, 40, '2014-01-24 20:42:56', 'Cập nhật món So huyet rang muoi / rang me '),
(817, 3, 40, '2014-01-24 20:43:14', 'Cập nhật món Ghẹ '),
(818, 3, 40, '2014-01-24 20:43:29', 'Cập nhật món dau '),
(819, 3, 40, '2014-01-24 20:43:33', 'Cập nhật món SG special chai '),
(820, 1, 40, '2014-01-24 20:45:40', 'tính tiền 335.000'),
(821, 1, 39, '2014-01-24 20:46:25', 'tính tiền 396.000'),
(822, 3, 39, '2014-01-24 20:47:19', 'Tạo mới giao dịch'),
(823, 3, 39, '2014-01-24 20:47:19', 'Cập nhật món Ca duoi phan '),
(824, 3, 36, '2014-01-24 20:53:12', 'Cập nhật món Ca sapa con '),
(825, 3, 36, '2014-01-24 20:53:34', 'Cập nhật món Nước ngọt '),
(826, 3, 36, '2014-01-24 20:53:49', 'Cập nhật món SG special chai '),
(827, 3, 36, '2014-01-24 20:54:16', 'Cập nhật món dau '),
(828, 3, 36, '2014-01-24 20:54:17', 'Cập nhật món dau 2'),
(829, 3, 39, '2014-01-24 20:58:57', 'Cập nhật món Ngheu hap sa '),
(830, 3, 39, '2014-01-24 20:59:58', 'Cập nhật món banh mi '),
(831, 3, 31, '2014-01-24 21:00:57', 'Cập nhật món khan '),
(832, 3, 31, '2014-01-24 21:00:57', 'Cập nhật món khan 2'),
(833, 3, 31, '2014-01-24 21:00:58', 'Cập nhật món khan 3'),
(834, 3, 31, '2014-01-24 21:00:58', 'Cập nhật món khan 4'),
(835, 3, 31, '2014-01-24 21:01:40', 'Cập nhật món SG special chai '),
(836, 3, 46, '2014-01-24 21:04:54', 'Tạo mới giao dịch'),
(837, 3, 46, '2014-01-24 21:04:54', 'Cập nhật món Ca duoi kg '),
(838, 3, 46, '2014-01-24 21:04:55', 'Cập nhật món Ca duoi kg 2'),
(839, 3, 46, '2014-01-24 21:05:28', 'Cập nhật món Muc la kg '),
(840, 1, 31, '2014-01-24 21:08:07', 'tính tiền 437.000'),
(841, 3, 55, '2014-01-24 21:09:00', 'Cập nhật món Thuoc 555 '),
(842, 3, 54, '2014-01-24 21:09:36', 'Cập nhật món Ca cam con '),
(843, 3, 54, '2014-01-24 21:09:36', 'Cập nhật món Ca cam con 2'),
(844, 1, 52, '2014-01-24 21:09:57', 'tính tiền 846.000'),
(845, 3, 52, '2014-01-24 21:10:09', 'Tạo mới giao dịch'),
(846, 3, 52, '2014-01-24 21:10:09', 'Cập nhật món ca song con '),
(847, 3, 52, '2014-01-24 21:10:10', 'Cập nhật món ca song con 2'),
(848, 3, 52, '2014-01-24 21:10:22', 'Cập nhật món So huyet rang muoi / rang me '),
(849, 1, 36, '2014-01-24 21:18:49', 'tính tiền 485.000'),
(850, 3, 52, '2014-01-24 21:19:45', 'Cập nhật món Ca cam con '),
(851, 3, 40, '2014-01-24 21:27:31', 'Tạo mới giao dịch'),
(852, 3, 40, '2014-01-24 21:27:31', 'Cập nhật món Nước suối '),
(853, 3, 40, '2014-01-24 21:27:34', 'Cập nhật món SG special chai '),
(854, 3, 40, '2014-01-24 21:27:36', 'Cập nhật món SG special chai 2'),
(855, 3, 40, '2014-01-24 21:27:36', 'Cập nhật món SG special chai 3'),
(856, 3, 40, '2014-01-24 21:27:37', 'Cập nhật món SG special chai 4'),
(857, 3, 40, '2014-01-24 21:27:38', 'Cập nhật món SG special chai 5'),
(858, 3, 40, '2014-01-24 21:27:39', 'Cập nhật món SG special chai 6'),
(859, 3, 29, '2014-01-24 21:29:06', 'Cập nhật món Heneiken chai '),
(860, 3, 29, '2014-01-24 21:29:22', 'Cập nhật món dau '),
(861, 3, 29, '2014-01-24 21:29:24', 'Cập nhật món dau 2'),
(862, 3, 29, '2014-01-24 21:29:25', 'Cập nhật món dau 3'),
(863, 1, 40, '2014-01-24 21:31:00', 'tính tiền 80.000'),
(864, 3, 46, '2014-01-24 21:31:15', 'Cập nhật món Ca cam con '),
(865, 1, 46, '2014-01-24 21:31:18', 'tính tiền 359.000'),
(866, 3, 46, '2014-01-24 21:31:23', 'Tạo mới giao dịch'),
(867, 3, 46, '2014-01-24 21:31:23', 'Cập nhật món Ca cam con '),
(868, 3, 46, '2014-01-24 21:31:24', 'Cập nhật món Ca cam con 2'),
(869, 1, 46, '2014-01-24 21:32:46', 'tính tiền 68.000'),
(870, 1, 29, '2014-01-24 21:32:54', 'tính tiền 1.128.000'),
(871, 3, 34, '2014-01-24 21:39:50', 'Cập nhật món sa lach tron '),
(872, 3, 34, '2014-01-24 21:39:50', 'Cập nhật món sa lach tron 2'),
(873, 3, 34, '2014-01-24 21:40:05', 'Cập nhật món khan '),
(874, 3, 34, '2014-01-24 21:40:12', 'Cập nhật món dau '),
(875, 3, 34, '2014-01-24 21:40:23', 'Cập nhật món SG special chai '),
(876, 3, 54, '2014-01-24 21:42:06', 'Cập nhật món Nước ngọt '),
(877, 3, 54, '2014-01-24 21:42:14', 'Cập nhật món SG special chai '),
(878, 1, 54, '2014-01-24 21:44:21', 'tính tiền 342.000'),
(879, 1, 34, '2014-01-24 21:44:32', 'tính tiền 807.000'),
(880, 3, 2, '2014-01-24 21:50:33', 'Cập nhật món Tiger nâu '),
(881, 3, 2, '2014-01-24 21:50:36', 'Cập nhật món Tiger nâu 2'),
(882, 3, 2, '2014-01-24 21:50:37', 'Cập nhật món Tiger nâu 3'),
(883, 3, 2, '2014-01-24 21:51:48', 'Cập nhật món khan '),
(884, 3, 2, '2014-01-24 21:51:50', 'Cập nhật món khan 2'),
(885, 3, 2, '2014-01-24 21:51:50', 'Cập nhật món khan 3'),
(886, 3, 2, '2014-01-24 21:51:51', 'Cập nhật món khan 4'),
(887, 3, 2, '2014-01-24 21:51:52', 'Cập nhật món khan 5'),
(888, 3, 2, '2014-01-24 21:52:06', 'Cập nhật món dau '),
(889, 3, 39, '2014-01-24 21:53:08', 'Cập nhật món dau '),
(890, 3, 39, '2014-01-24 21:53:08', 'Cập nhật món dau 2'),
(891, 3, 39, '2014-01-24 21:53:13', 'Cập nhật món khan '),
(892, 3, 39, '2014-01-24 21:53:20', 'Cập nhật món SG special chai '),
(893, 3, 39, '2014-01-24 21:53:21', 'Cập nhật món SG special chai 2'),
(894, 3, 55, '2014-01-24 21:55:43', 'Cập nhật món SG special chai '),
(895, 3, 55, '2014-01-24 21:55:43', 'Cập nhật món SG special chai 2'),
(896, 3, 55, '2014-01-24 21:55:57', 'Cập nhật món dau '),
(897, 1, 39, '2014-01-24 21:56:39', 'tính tiền 247.000'),
(898, 1, 2, '2014-01-24 21:56:50', 'tính tiền 611.000'),
(899, 3, 40, '2014-01-24 21:57:08', 'Tạo mới giao dịch'),
(900, 3, 40, '2014-01-24 21:57:08', 'Cập nhật món SG special chai '),
(901, 3, 40, '2014-01-24 21:57:57', 'Cập nhật món dau '),
(902, 1, 55, '2014-01-24 21:58:38', 'tính tiền 734.000'),
(903, 3, 52, '2014-01-24 22:22:14', 'Cập nhật món ech nuong  '),
(904, 3, 52, '2014-01-24 22:22:15', 'Cập nhật món ech nuong  2'),
(905, 3, 52, '2014-01-24 22:23:21', 'Cập nhật món dau '),
(906, 3, 52, '2014-01-24 22:23:39', 'Cập nhật món SG special chai '),
(907, 1, 52, '2014-01-24 22:28:39', 'tính tiền 704.000'),
(908, 1, 40, '2014-01-24 22:28:47', 'tính tiền 58.000');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_term`
--

CREATE TABLE IF NOT EXISTS `tbl_term` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=12 ;

--
-- Dumping data for table `tbl_term`
--

INSERT INTO `tbl_term` (`id`, `name`, `type`) VALUES
(1, 'Tiền Điện', 0),
(2, 'Tiền Nước', 0),
(3, 'Thuế', 0),
(10, 'Tiền Ăn Nhân Viên', 0),
(11, 'CP Khác', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_term_collect`
--

CREATE TABLE IF NOT EXISTS `tbl_term_collect` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Dumping data for table `tbl_term_collect`
--

INSERT INTO `tbl_term_collect` (`id`, `name`) VALUES
(2, 'Phụ Phẩm'),
(3, 'Đặc Biệt'),
(4, 'Ung luong NV');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tracking`
--

CREATE TABLE IF NOT EXISTS `tbl_tracking` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_start` date NOT NULL,
  `date_end` date NOT NULL,
  `paid_general` int(11) NOT NULL,
  `paid_pay_roll` int(11) NOT NULL,
  `paid_import` int(11) NOT NULL,
  `collect_general` int(11) NOT NULL,
  `collect_customer` int(11) NOT NULL,
  `collect_selling_debt` int(11) NOT NULL,
  `collect_selling_nodebt` int(11) NOT NULL,
  `estate_rate` int(11) NOT NULL,
  `store_value` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=15 ;

--
-- Dumping data for table `tbl_tracking`
--

INSERT INTO `tbl_tracking` (`id`, `date_start`, `date_end`, `paid_general`, `paid_pay_roll`, `paid_import`, `collect_general`, `collect_customer`, `collect_selling_debt`, `collect_selling_nodebt`, `estate_rate`, `store_value`) VALUES
(13, '2014-01-01', '2014-01-31', 0, 0, 0, 0, 0, 0, 0, 0, 0),
(14, '2014-02-01', '2014-02-28', 0, 0, 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tracking_course`
--

CREATE TABLE IF NOT EXISTS `tbl_tracking_course` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tracking` int(11) NOT NULL,
  `id_td` int(11) NOT NULL,
  `id_course` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `value` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=753 ;

--
-- Dumping data for table `tbl_tracking_course`
--

INSERT INTO `tbl_tracking_course` (`id`, `id_tracking`, `id_td`, `id_course`, `count`, `price`, `value`) VALUES
(630, 13, 236, 380, 1, 0, 0),
(696, 13, 237, 411, 6, 0, 0),
(697, 13, 237, 606, 0, 0, 0),
(698, 13, 237, 605, 2, 0, 0),
(699, 13, 237, 640, 15, 0, 0),
(700, 13, 237, 638, 1, 0, 0),
(701, 13, 237, 631, 1, 0, 0),
(702, 13, 237, 632, 2, 0, 0),
(703, 13, 237, 655, 1, 0, 0),
(704, 13, 237, 625, 3, 0, 0),
(705, 13, 237, 620, 8, 0, 0),
(706, 13, 237, 649, 1, 0, 0),
(707, 13, 237, 622, 1, 0, 0),
(708, 13, 237, 621, 2, 0, 0),
(709, 13, 237, 633, 1, 0, 0),
(710, 13, 237, 630, 0, 0, 0),
(711, 13, 237, 635, 1, 0, 0),
(712, 13, 237, 616, 2, 0, 0),
(713, 13, 237, 619, 2, 0, 0),
(714, 13, 237, 496, 1, 0, 0),
(715, 13, 237, 585, 5, 0, 0),
(716, 13, 237, 589, 2, 0, 0),
(717, 13, 237, 548, 6, 0, 0),
(718, 13, 237, 587, 2, 0, 0),
(719, 13, 237, 550, 2, 0, 0),
(720, 13, 237, 637, 16, 0, 0),
(721, 13, 237, 613, 4, 0, 0),
(722, 13, 237, 583, 2, 0, 0),
(723, 13, 237, 504, 3, 0, 0),
(724, 13, 237, 503, 3, 0, 0),
(725, 13, 237, 520, 4, 0, 0),
(726, 13, 237, 576, 1, 0, 0),
(727, 13, 237, 574, 1, 0, 0),
(728, 13, 237, 528, 9, 0, 0),
(729, 13, 237, 188, 15, 0, 0),
(730, 13, 237, 510, 1, 0, 0),
(731, 13, 237, 636, 23, 0, 0),
(732, 13, 237, 563, 2, 0, 0),
(733, 13, 237, 579, 5, 0, 0),
(734, 13, 237, 542, 5, 0, 0),
(735, 13, 237, 604, 1, 0, 0),
(736, 13, 237, 601, 1, 0, 0),
(737, 13, 237, 608, 1, 0, 0),
(738, 13, 237, 607, 9, 0, 0),
(739, 13, 237, 522, 10, 0, 0),
(740, 13, 237, 490, 9, 0, 0),
(741, 13, 237, 491, 2, 0, 0),
(742, 13, 237, 540, 1, 0, 0),
(743, 13, 237, 537, 1, 0, 0),
(744, 13, 237, 492, 2, 0, 0),
(745, 13, 237, 116, 20, 0, 0),
(746, 13, 237, 489, 20, 0, 0),
(747, 13, 237, 115, 190, 0, 0),
(748, 13, 237, 531, 9, 0, 0),
(749, 13, 237, 532, 2, 0, 0),
(750, 13, 237, 536, 1, 0, 0),
(751, 13, 237, 648, 1, 0, 0),
(752, 13, 237, 654, 1, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tracking_customer`
--

CREATE TABLE IF NOT EXISTS `tbl_tracking_customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tracking` int(11) NOT NULL,
  `id_customer` int(11) NOT NULL,
  `value_session1` int(11) NOT NULL,
  `value_session2` int(11) NOT NULL,
  `value_collect` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tbl_tracking_customer`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_tracking_daily`
--

CREATE TABLE IF NOT EXISTS `tbl_tracking_daily` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tracking` int(11) NOT NULL,
  `date` date NOT NULL,
  `selling` bigint(20) NOT NULL,
  `import` bigint(20) NOT NULL,
  `store` bigint(20) NOT NULL,
  `paid` bigint(20) NOT NULL,
  `collect` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=245 ;

--
-- Dumping data for table `tbl_tracking_daily`
--

INSERT INTO `tbl_tracking_daily` (`id`, `id_tracking`, `date`, `selling`, `import`, `store`, `paid`, `collect`) VALUES
(214, 13, '2014-01-01', 0, 0, 0, 0, 0),
(215, 13, '2014-01-02', 0, 0, 0, 0, 0),
(216, 13, '2014-01-03', 0, 0, 0, 0, 0),
(217, 13, '2014-01-04', 0, 0, 0, 0, 0),
(218, 13, '2014-01-05', 0, 0, 0, 0, 0),
(219, 13, '2014-01-06', 0, 0, 0, 0, 0),
(220, 13, '2014-01-07', 0, 0, 0, 0, 0),
(221, 13, '2014-01-08', 0, 0, 0, 0, 0),
(222, 13, '2014-01-09', 0, 0, 0, 0, 0),
(223, 13, '2014-01-10', 0, 0, 0, 0, 0),
(224, 13, '2014-01-11', 0, 0, 0, 0, 0),
(225, 13, '2014-01-12', 0, 0, 0, 0, 0),
(226, 13, '2014-01-13', 0, 0, 0, 0, 0),
(227, 13, '2014-01-14', 0, 0, 0, 0, 0),
(228, 13, '2014-01-15', 0, 0, 0, 0, 0),
(229, 13, '2014-01-16', 0, 0, 0, 0, 0),
(230, 13, '2014-01-17', 0, 0, 0, 0, 0),
(231, 13, '2014-01-18', 0, 0, 0, 0, 0),
(232, 13, '2014-01-19', 0, 0, 0, 0, 0),
(233, 13, '2014-01-20', 0, 0, 0, 0, 0),
(234, 13, '2014-01-21', 0, 0, 0, 0, 0),
(235, 13, '2014-01-22', 0, 0, 0, 0, 0),
(236, 13, '2014-01-23', 0, 0, 0, 0, 0),
(237, 13, '2014-01-24', 15573000, 0, 0, 0, 0),
(238, 13, '2014-01-25', 0, 0, 0, 0, 0),
(239, 13, '2014-01-26', 0, 0, 0, 0, 0),
(240, 13, '2014-01-27', 0, 0, 0, 0, 0),
(241, 13, '2014-01-28', 0, 0, 0, 0, 0),
(242, 13, '2014-01-29', 0, 0, 0, 0, 0),
(243, 13, '2014-01-30', 0, 0, 0, 0, 0),
(244, 13, '2014-01-31', 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tracking_store`
--

CREATE TABLE IF NOT EXISTS `tbl_tracking_store` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tracking` int(11) NOT NULL,
  `id_td` int(11) NOT NULL,
  `id_resource` int(11) NOT NULL,
  `count_old` float NOT NULL,
  `count_import` float NOT NULL,
  `count_export` float NOT NULL,
  `price` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1861 ;

--
-- Dumping data for table `tbl_tracking_store`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_unit`
--

CREATE TABLE IF NOT EXISTS `tbl_unit` (
  `id` int(25) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=32 ;

--
-- Dumping data for table `tbl_unit`
--

INSERT INTO `tbl_unit` (`id`, `name`) VALUES
(1, 'Ly'),
(2, 'Điếu'),
(3, 'Chai'),
(4, 'Lon'),
(5, 'Dĩa'),
(6, 'Thùng'),
(7, 'Két'),
(9, 'Bịch'),
(10, 'Gói'),
(20, 'Trái'),
(21, 'Cái'),
(22, 'Hủ'),
(23, 'Kg'),
(24, 'Con'),
(25, 'Bao'),
(26, 'Cây'),
(27, 'Hộp'),
(28, 'Miếng'),
(29, 'Bó'),
(30, 'Phần'),
(31, 'Thố');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE IF NOT EXISTS `tbl_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pass` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gender` int(11) NOT NULL,
  `note` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `datecreate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dateupdate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `dateactivity` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `type` tinyint(4) NOT NULL,
  `code` varchar(13) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `name`, `email`, `pass`, `gender`, `note`, `datecreate`, `dateupdate`, `dateactivity`, `type`, `code`) VALUES
(1, 'Tuấn', 'tuanbuithanh@gmail.com', 'admin068368', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 4, ''),
(3, 'Thái', 'thai@gmail.com', '123456', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 4, '');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_collect_customer`
--
ALTER TABLE `tbl_collect_customer`
  ADD CONSTRAINT `tbl_customer_collect_1` FOREIGN KEY (`idcustomer`) REFERENCES `tbl_customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_collect_general`
--
ALTER TABLE `tbl_collect_general`
  ADD CONSTRAINT `tbl_collect_general_1` FOREIGN KEY (`id_term`) REFERENCES `tbl_term_collect` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_course`
--
ALTER TABLE `tbl_course`
  ADD CONSTRAINT `tbl_course_1` FOREIGN KEY (`idcategory`) REFERENCES `tbl_category` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_order_import`
--
ALTER TABLE `tbl_order_import`
  ADD CONSTRAINT `tbl_order_import_1` FOREIGN KEY (`idsupplier`) REFERENCES `tbl_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_order_import_detail`
--
ALTER TABLE `tbl_order_import_detail`
  ADD CONSTRAINT `tbl_order_import_detail_1` FOREIGN KEY (`idorder`) REFERENCES `tbl_order_import` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_order_import_detail_2` FOREIGN KEY (`idresource`) REFERENCES `tbl_resource` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_paid_customer`
--
ALTER TABLE `tbl_paid_customer`
  ADD CONSTRAINT `tbl_customer_paid_1` FOREIGN KEY (`idcustomer`) REFERENCES `tbl_customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_paid_employee`
--
ALTER TABLE `tbl_paid_employee`
  ADD CONSTRAINT `tbl_paid_employee_ibfk_1` FOREIGN KEY (`id_employee`) REFERENCES `tbl_employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_paid_general`
--
ALTER TABLE `tbl_paid_general`
  ADD CONSTRAINT `tbl_paid_general_1` FOREIGN KEY (`id_term`) REFERENCES `tbl_term` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_paid_pay_roll`
--
ALTER TABLE `tbl_paid_pay_roll`
  ADD CONSTRAINT `tbl_paid_pay_roll_ibfk_1` FOREIGN KEY (`id_employee`) REFERENCES `tbl_employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_paid_supplier`
--
ALTER TABLE `tbl_paid_supplier`
  ADD CONSTRAINT `tbl_supplier_paid_1` FOREIGN KEY (`idsupplier`) REFERENCES `tbl_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_pay_roll`
--
ALTER TABLE `tbl_pay_roll`
  ADD CONSTRAINT `tbl_pay_roll_ibfk_1` FOREIGN KEY (`id_employee`) REFERENCES `tbl_employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_r2c`
--
ALTER TABLE `tbl_r2c`
  ADD CONSTRAINT `tbl_r2c_1` FOREIGN KEY (`id_course`) REFERENCES `tbl_course` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_r2c_2` FOREIGN KEY (`id_resource`) REFERENCES `tbl_resource` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_resource`
--
ALTER TABLE `tbl_resource`
  ADD CONSTRAINT `tbl_resource_1` FOREIGN KEY (`idsupplier`) REFERENCES `tbl_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_session`
--
ALTER TABLE `tbl_session`
  ADD CONSTRAINT `tbl_session_1` FOREIGN KEY (`idtable`) REFERENCES `tbl_table` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_session_2` FOREIGN KEY (`iduser`) REFERENCES `tbl_user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_session_3` FOREIGN KEY (`idcustomer`) REFERENCES `tbl_customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_session_detail`
--
ALTER TABLE `tbl_session_detail`
  ADD CONSTRAINT `tbl_session_detail_1` FOREIGN KEY (`idsession`) REFERENCES `tbl_session` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_session_detail_2` FOREIGN KEY (`idcourse`) REFERENCES `tbl_course` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_table`
--
ALTER TABLE `tbl_table`
  ADD CONSTRAINT `tbl_table_1` FOREIGN KEY (`iddomain`) REFERENCES `tbl_domain` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
