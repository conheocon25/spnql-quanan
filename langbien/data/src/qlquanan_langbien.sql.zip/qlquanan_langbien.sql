-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 23, 2014 at 04:46 PM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `qlquanan_langbien`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_app`
--

CREATE TABLE IF NOT EXISTS `tbl_app` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(125) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(50) CHARACTER SET utf8 NOT NULL,
  `banner` varchar(125) CHARACTER SET utf8 NOT NULL,
  `prefix` varchar(50) CHARACTER SET utf8 NOT NULL,
  `alias` varchar(256) CHARACTER SET utf8 NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_activity` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `type` tinyint(4) NOT NULL,
  `page_view` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_app`
--

INSERT INTO `tbl_app` (`id`, `name`, `phone`, `address`, `email`, `banner`, `prefix`, `alias`, `date_created`, `date_modified`, `date_activity`, `type`, `page_view`) VALUES
(1, 'Karaoke Ba Đức', '0945 03 07 09', 'Phó Cơ Điều P3 - TPVL', '', 'data/images/banner/logo.png', 'tbl_', 'tbl_', '2012-06-30 17:00:00', '0000-00-00 00:00:00', '2012-12-26 07:28:02', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

CREATE TABLE IF NOT EXISTS `tbl_category` (
  `id` int(25) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `picture` binary(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=36 ;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`id`, `name`, `picture`) VALUES
(3, 'Mực', NULL),
(8, 'Cá biển', NULL),
(11, 'BIA', NULL),
(12, 'Cá sông', NULL),
(13, 'Lẩu', NULL),
(15, 'Nghêu - sò ', NULL),
(16, 'Bò', NULL),
(17, 'Xào', NULL),
(18, 'Rượu', NULL),
(19, 'Gỏi', NULL),
(20, 'Cơm', NULL),
(21, 'Tôm - hàu', NULL),
(22, 'Tự nhâp', NULL),
(23, 'NƯỚC GIẢI KHÁT', NULL),
(24, 'Khai Vị', NULL),
(25, 'Cua - Ghẹ', NULL),
(26, 'Gà', NULL),
(27, 'Se Sẻ', NULL),
(28, 'Nai', NULL),
(30, 'Thuốc Hút', NULL),
(31, 'Đậu nành rau', NULL),
(32, 'TRÁI CÂY', NULL),
(33, 'Khăn lạnh', NULL),
(34, 'Ốc mỡ', NULL),
(35, 'Món Đặc Biệt', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_collect_customer`
--

CREATE TABLE IF NOT EXISTS `tbl_collect_customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idcustomer` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_customer_collect_1` (`idcustomer`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tbl_collect_customer`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_collect_general`
--

CREATE TABLE IF NOT EXISTS `tbl_collect_general` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_term` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_collect_1` (`id_term`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

--
-- Dumping data for table `tbl_collect_general`
--

INSERT INTO `tbl_collect_general` (`id`, `id_term`, `date`, `value`, `note`) VALUES
(6, 3, '2013-12-04', 10000000, 'Bổ sung tiền quỹ');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_config`
--

CREATE TABLE IF NOT EXISTS `tbl_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `param` varchar(125) COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=10 ;

--
-- Dumping data for table `tbl_config`
--

INSERT INTO `tbl_config` (`id`, `param`, `value`) VALUES
(5, 'DISCOUNT', '0'),
(6, 'ROW_PER_PAGE', '12'),
(7, 'GUEST_VISIT', '9247'),
(8, 'EVERY_5_MINUTES', '2000'),
(9, 'CATEGORY_AUTO', '22');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_course`
--

CREATE TABLE IF NOT EXISTS `tbl_course` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idcategory` int(25) DEFAULT NULL,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `shortname` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `unit` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `price1` bigint(20) NOT NULL,
  `price2` bigint(20) NOT NULL,
  `price3` bigint(20) NOT NULL,
  `price4` bigint(20) NOT NULL,
  `picture` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `prepare` int(11) NOT NULL,
  `is_discount` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `foreign_field` (`idcategory`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=489 ;

--
-- Dumping data for table `tbl_course`
--

INSERT INTO `tbl_course` (`id`, `idcategory`, `name`, `shortname`, `unit`, `price1`, `price2`, `price3`, `price4`, `picture`, `prepare`, `is_discount`) VALUES
(107, 3, 'Mực hấp gừng', 'hấp gừng', 'Dĩa', 58000, 58000, 58000, 58000, '', 1, 0),
(108, 3, 'Mực chiên nước mắm', 'chiên nước mắm', 'Dĩa', 58000, 58000, 58000, 58000, '', 1, 0),
(111, 3, 'Mực Nướng Sa Tế', 'Mực Nướng Sa Tế', 'Kg', 58000, 58000, 58000, 58000, '', 1, 0),
(115, 11, 'SG special chai', 'SG chai xanh', 'Chai', 13000, 13000, 13000, 13000, '', 0, 0),
(116, 11, 'SG đỏ', 'SG đỏ', 'Chai', 10000, 10000, 10000, 10000, '', 0, 0),
(165, 18, 'Phú Lễ', 'Phú Lễ', 'Chai', 80000, 80000, 80000, 80000, '', 0, 0),
(167, 18, 'Volka Men', 'Volka Men', 'Chai', 80000, 80000, 80000, 80000, '', 0, 0),
(188, 11, 'Heneiken chai', 'Ken chai', 'Chai', 16000, 16000, 16000, 16000, '', 0, 0),
(189, 11, 'Heneiken lon', 'Ken lon', 'Lon', 18000, 18000, 18000, 18000, '', 0, 0),
(190, 11, 'Tiger nâu', 'Tiger nâu', 'Chai', 14000, 14000, 14000, 14000, '', 0, 0),
(191, 11, 'Tiger bạc', 'Tiger bạc', 'Chai', 15000, 15000, 15000, 15000, '', 0, 0),
(243, 22, 'gà ta quay', 'gà ta quay', 'Dĩa', 100000, 100000, 100000, 100000, '', 0, 0),
(244, 23, 'Lavie 500ml', 'Lavie 500ml', 'Chai', 10000, 10000, 10000, 10000, '', 1, 1),
(245, 23, 'Pepsi', 'Pepsi', 'Lon', 12000, 12000, 12000, 12000, '', 1, 1),
(246, 23, 'Sting', 'Sting', 'Lon', 12000, 12000, 12000, 12000, '', 1, 0),
(247, 22, 'khoai mon chien', '', 'Dĩa', 25000, 25000, 25000, 25000, '', 0, 0),
(248, 24, 'Cà Tím Nướng Mỡ Hành', 'cà tím nướng mỡ hành', 'Dĩa', 30000, 30000, 30000, 30000, '', 1, 0),
(249, 24, 'Khoai Môn Chiên Nước Mắm', 'Khoai môn chiên nước mắm', 'Dĩa', 38000, 38000, 38000, 38000, '', 1, 0),
(250, 24, 'Khoai Tây Chiên', 'Khoai tây chiên', 'Dĩa', 38000, 38000, 38000, 38000, '', 1, 0),
(251, 24, 'Đậu Hủ Non Chiên Giòn', 'Đậu hủ non chiên giòn', 'Dĩa', 48000, 48000, 48000, 48000, '', 1, 0),
(252, 24, 'Đậu Hủ Hấp Cải Thìa', 'Đậu hủ hấp cải thìa', 'Dĩa', 48000, 48000, 48000, 48000, '', 1, 0),
(253, 24, 'Chả Giò Hải Sản', 'Chả giò hải sản', 'Dĩa', 58000, 58000, 58000, 58000, '', 1, 0),
(254, 24, 'Tôm Sú Rang Muối Hồng Kông', 'Tôm sú rang muối hồng kông', 'Dĩa', 68000, 68000, 68000, 68000, '', 1, 0),
(255, 24, 'Tôm Lăn Bột', 'Tôm lăn bột', 'Dĩa', 68000, 68000, 68000, 68000, '', 1, 0),
(256, 24, 'Khô Mực Rang Tiêu', 'Khô mực rang tiêu', 'Dĩa', 58000, 58000, 58000, 58000, '', 1, 0),
(257, 24, 'Khô Mực Chiên Giòn', 'Khô mực chiên giòn', 'Dĩa', 58000, 58000, 58000, 58000, '', 1, 0),
(258, 24, 'Khô Mực Nướng', 'Khô mực nướng', 'Dĩa', 58000, 58000, 58000, 58000, '', 1, 0),
(259, 24, 'Rau Luộc + Trứng Hồng Đào', 'Rau luộc + trứng hồng đào', 'Dĩa', 38000, 38000, 38000, 38000, '', 1, 0),
(260, 24, 'Rau Muống Xào Tỏi', 'Rau muống xào tỏi', 'Dĩa', 38000, 38000, 38000, 38000, '', 1, 0),
(261, 24, 'Rau Luộc Kho Qụet', 'Rau luộc kho quẹt', 'Dĩa', 38000, 38000, 38000, 38000, '', 1, 0),
(262, 24, 'Cơm Cháy Kho Qụet', 'Cơm cháy kho quẹt ', 'Dĩa', 48000, 48000, 48000, 48000, '', 1, 0),
(263, 24, 'Salad Hải Sản', 'Salad hải sản', 'Dĩa', 58000, 58000, 58000, 58000, '', 1, 0),
(264, 24, 'Salad Dầu Giấm', 'Salad dầu giấm', 'Dĩa', 58000, 58000, 58000, 58000, '', 1, 0),
(265, 19, 'Gỏi Mực Thái', 'Gỏi mực thái', 'Dĩa', 55000, 55000, 55000, 55000, '', 1, 0),
(266, 19, 'Gỏi Dưa Leo Hải Sản', 'Gỏi dưa leo hải sản', 'Dĩa', 55000, 55000, 55000, 55000, '', 1, 0),
(267, 19, 'Gỏi Tôm Thái', 'Gỏi tôm thái', 'Dĩa', 55000, 55000, 55000, 55000, '', 1, 0),
(268, 17, 'Mì Xào Hải Sản', 'Mì xào hải sản', 'Dĩa', 55000, 55000, 55000, 55000, '', 1, 0),
(269, 17, 'Mì Xào Tôm', 'Mì xào tôm', 'Dĩa', 55000, 55000, 55000, 55000, '', 1, 0),
(270, 20, 'Cơm Chiên Hải Sản', 'Cơm Chiên Hải Sản', 'Dĩa', 55000, 55000, 55000, 55000, '', 1, 0),
(271, 20, 'Cơm Chiên Trứng', 'Cơm Chiên Trứng', 'Dĩa', 48000, 48000, 48000, 48000, '', 10, 0),
(272, 20, 'Cơm Xào Hải Sản', 'Cơm Xào Hải Sản', 'Dĩa', 55000, 55000, 55000, 55000, '', 10, 0),
(273, 8, 'Cá Bóng Mú Đen Ăn Sống Mù Tạt', 'Cá Bóng Mú Đen Ăn Sống Mù Tạt', 'Kg', 380000, 380000, 380000, 380000, '', 1, 0),
(274, 8, 'Cá Bóng Mú Đen Nướng Muối Ớt', 'Cá Bóng Mú Đen Nướng Muối Ớt', 'Kg', 380000, 380000, 380000, 380000, '', 1, 0),
(275, 8, 'Cá Bóng Mú Đen Nướng Sa Tế Cay', 'Cá Bóng Mú Đen Nướng Sa Tế Cay', 'Kg', 380000, 380000, 380000, 380000, '', 1, 0),
(276, 8, 'Cá Bóng Mú Đen Chưng Tương', 'Cá Bóng Mú Đen Chưng Tương', 'Kg', 380000, 380000, 380000, 380000, '', 1, 0),
(277, 8, 'Cá Bống Mú Đen Hấp Hồng kông', 'Cá Bống Mú Đen Hấp Hồng kông', 'Kg', 380000, 380000, 380000, 380000, '', 1, 0),
(278, 8, 'Cá Bống Mú Đen Hấp Tàu Xì', 'Cá Bống Mú Đen Hấp Tàu Xì', 'Kg', 380000, 380000, 380000, 380000, '', 1, 0),
(279, 8, 'Cá Bống Mú Đen Hấp Kỳ Lân', 'Cá Bống Mú Đen Hấp  Kỳ Lân', 'Kg', 380000, 380000, 380000, 380000, '', 1, 0),
(280, 8, 'Cá Bóng Mú Đen Nấu Lẩu', 'Cá Bóng Mú Đen Nấu Lẩu', 'Kg', 380000, 380000, 380000, 380000, '', 1, 0),
(281, 8, 'Cá  Tầm Ăn Sống Mù Tạt', 'Cá  Tầm Ăn Sống Mù Tạt', 'Kg', 350000, 350000, 350000, 350000, '', 1, 0),
(282, 8, 'Cá Tầm Nướng Muối Ớt ', 'Cá Tầm Nướng Muối Ớt ', 'Kg', 350000, 350000, 350000, 350000, '', 1, 0),
(283, 8, 'Cá Tầm Nướng Xa Tế Cay', 'Cá Tầm Nướng Xa Tế Cay', 'Kg', 350000, 350000, 350000, 350000, '', 1, 0),
(284, 8, 'Cá Tầm Chưng Tương', 'Cá Tầm Chưng Tương', 'Kg', 350000, 350000, 350000, 350000, '', 1, 0),
(285, 8, 'Cá Tầm Hấp Hồng Kông', 'Cá Tầm Hấp Hồng Kông', 'Kg', 350000, 350000, 350000, 350000, '', 1, 0),
(286, 8, 'Cá Tầm Hấp Kỳ Lân', 'Cá Tầm Hấp Kỳ Lân', 'Kg', 350000, 350000, 350000, 350000, '', 1, 0),
(287, 8, 'Cá Tầm Nấu Lẩu', 'Cá Tầm Nấu Lẩu', 'Kg', 350000, 350000, 350000, 350000, '', 1, 0),
(288, 12, 'Cá Chạch Quế Chiên Nước Mắm', 'Cá Chạch Quế Chiên Nước Mắm', 'Kg', 380000, 380000, 380000, 380000, '', 1, 0),
(289, 12, 'Cá Chạch Quế Chiên Giòn', 'Cá Chạch Quế Chiên Giòn', 'Kg', 380000, 380000, 380000, 380000, '', 1, 0),
(290, 12, 'Cá Chạch Quế Nướng Muối Ớt', 'Cá Chạch Quế Nướng Muối Ớt', 'Kg', 380000, 380000, 380000, 380000, '', 1, 0),
(292, 12, 'Cá Chạch Quế Nướng Xa Tế Cay', 'Cá Chạch Quế Nướng Xa Tế Cay', 'Kg', 380000, 380000, 380000, 380000, '', 1, 0),
(293, 12, 'Cá Chạch Quế Nướng Mọi', 'Cá Chạch Quế Nướng Mọi', 'Kg', 380000, 380000, 380000, 380000, '', 1, 0),
(295, 12, 'Cá Chạch Quế Nấu Lẩu', 'Cá Chạch Quế Nấu Lẩu', 'Kg', 380000, 380000, 380000, 380000, '', 1, 0),
(300, 12, 'Cá Chép Giòn Ăn Sống Mù Tạt', 'Cá Chép Giòn Ăn Sống Mù Tạt', 'Kg', 380000, 380000, 380000, 380000, '', 1, 0),
(301, 12, 'Cá Chép Giòn Nướng Muối Ớt', 'Cá Chép Giòn Nướng Muối Ớt', 'Kg', 380000, 380000, 380000, 380000, '', 1, 0),
(303, 12, 'Cá Chép Giòn Nướng xa Tế Cay', 'Cá Chép Giòn Nướng xa Tế Cay', 'Kg', 380000, 380000, 380000, 380000, '', 1, 0),
(304, 12, 'Cá Chép Giòn Chưng Tương', 'Cá Chép Giòn Chưng Tương', 'Kg', 380000, 380000, 380000, 380000, '', 1, 0),
(305, 12, 'Cá Chép Giòn Hấp Hồng Kông', 'Cá Chép Giòn Hấp Hồng Kông', 'Kg', 380000, 380000, 380000, 380000, '', 1, 0),
(306, 12, 'Cá Chép Giòn Hấp Kỳ Lân', 'Cá Chép Giòn Hấp Kỳ Lân', 'Kg', 380000, 380000, 380000, 380000, '', 1, 0),
(307, 12, 'Cá Chép Giòn Nấu Lẩu', 'Cá Chép Giòn Nấu Lẩu', 'Kg', 380000, 380000, 380000, 380000, '', 1, 0),
(308, 12, 'Cá Heo Nhỏ Ăn Sống Mù Tạt', 'CHNMT', 'Kg', 1, 1, 1, 1, '', 10, 0),
(309, 12, 'Cá Heo Nhỏ Nướng Muối Ớt', 'CHNNMO', 'Kg', 1, 1, 1, 1, '', 15, 0),
(310, 12, 'Cá Heo Nhỏ Nướng Sa Tế Cay', ' CHNNSTC', 'Kg', 1, 1, 1, 1, '', 15, 0),
(311, 12, 'Cá Heo Nhỏ Chưng Tương', 'CHNCT', 'Kg', 1, 1, 1, 1, '', 10, 0),
(312, 12, 'Cá Heo Nhỏ Hấp Hồng Kông-Hấp Tàu Xì', 'CHNHHK', 'Kg', 1, 1, 1, 1, '', 10, 0),
(313, 12, 'Cá Heo Nhỏ Hấp Kỳ Lân', 'CHNHKL', 'Kg', 1, 1, 1, 1, '', 10, 0),
(314, 12, 'Cá Heo Nhỏ Nấu Lẩu', 'CHNNL', 'Kg', 1, 1, 1, 1, '', 10, 0),
(315, 8, 'Cá Hồng Biển Ăn Sống Mù Tạt', 'Cá Hồng Biển Ăn Sống Mù Tạt', 'Kg', 280000, 280000, 280000, 280000, '', 1, 0),
(316, 8, 'Cá Hồng Biển Nướng Muối Ớt', 'Cá Hồng Biển Nướng Muối Ớt', 'Kg', 280000, 280000, 280000, 280000, '', 1, 0),
(317, 8, 'Cá Hồng Biển Nướng Sa Tế Cay', 'Cá Hồng Biển Nướng Sa Tế Cay', 'Kg', 280000, 280000, 280000, 280000, '', 1, 0),
(318, 8, 'Cá Hồng Biển Chưng Tương', 'Cá Hồng Biển Chưng Tương', 'Kg', 280000, 280000, 280000, 280000, '', 1, 0),
(319, 8, 'Cá Hồng Biển Hấp Hồng Kông', 'Cá Hồng Biển Hấp Hồng Kông', 'Kg', 280000, 280000, 280000, 280000, '', 1, 0),
(320, 8, 'Cá Hồng Biển Hấp Kỳ Lân', 'Cá Hồng Biển Hấp Kỳ Lân', 'Kg', 280000, 280000, 280000, 280000, '', 1, 0),
(321, 8, 'Cá Hồng Biển Nấu Lẩu', 'Cá Hồng Biển Nấu Lẩu', 'Kg', 280000, 280000, 280000, 280000, '', 1, 0),
(322, 8, 'Cá Bốp Nướng Muối Ớt', 'Cá Bốp Nướng Muối Ớt', 'Kg', 188000, 188000, 188000, 188000, '', 1, 0),
(323, 8, 'Cá Bốp Nướng Sa Tế Cay', 'Cá Bốp Nướng Sa Tế Cay', 'Kg', 188000, 188000, 188000, 188000, '', 1, 0),
(324, 8, 'Cá Bốp Lúc Lắc', 'Cá Bốp Lúc Lắc', 'Kg', 188000, 188000, 188000, 188000, '', 1, 0),
(325, 8, 'Cá Bốp Chưng Tương ', 'Cá Bốp Chưng Tương ', 'Kg', 188000, 188000, 188000, 188000, '', 1, 0),
(326, 8, 'Cá Bốp Nấu Lẩu', 'Cá Bốp Nấu Lẩu', 'Kg', 188000, 188000, 188000, 188000, '', 1, 0),
(327, 8, 'Cá Cam Nướng Sa Tế Cay', 'Cá Cam Nướng Sa Tế Cay', 'Kg', 108000, 108000, 108000, 108000, '', 1, 0),
(328, 8, 'Cá Cam Nướng Muối Ớt', 'Cá Cam Nướng Muối Ớt', 'Kg', 108000, 108000, 108000, 108000, '', 1, 0),
(329, 8, 'Cá Cam Hấp Hành', 'Cá Cam Hấp Hành', 'Kg', 108000, 108000, 108000, 108000, '', 1, 0),
(330, 8, 'Cá Sapa Nướng Muối Ớt', 'Cá Sapa Nướng Muối Ớt', 'Dĩa', 88000, 88000, 88000, 88000, '', 1, 0),
(331, 8, 'Cá Sapa Nướng Sa Tế Cay', 'Cá Sapa Nướng Sa Tế Cay', 'Dĩa', 88000, 88000, 88000, 88000, '', 1, 0),
(332, 8, 'Cá Bò Da Nướng Muối Ớt', 'Cá Bò Da Nướng Muối Ớt', 'Dĩa', 128000, 128000, 128000, 128000, '', 1, 0),
(333, 8, 'Cá Bò Da Nướng Sa Tế Cay', 'Cá Bò Da Nướng Sa Tế Cay', 'Dĩa', 128000, 128000, 128000, 128000, '', 1, 0),
(334, 21, 'Tôm Lóng Ăn Sống Mù Tạt', 'Tôm Lóng Ăn Sống Mù Tạt', 'Kg', 290000, 290000, 290000, 290000, '', 1, 0),
(335, 21, 'Tôm Lóng Nướng Muối Ớt', 'Tôm Lóng Nướng Muối Ớt', 'Kg', 290000, 290000, 290000, 290000, '', 15, 0),
(336, 21, 'Tôm Lóng Nướng Sa Tế Cay', 'Tôm Lóng Nướng Sa Tế Cay', 'Kg', 290000, 290000, 290000, 290000, '', 1, 0),
(337, 21, 'Tôm Lóng Hấp Bia', 'Tôm Lóng Hấp Bia', 'Kg', 290000, 290000, 290000, 290000, '', 1, 0),
(339, 21, 'Tôm Sú Nướng Muối Ớt', 'Tôm Sú Nướng Muối Ớt', 'Kg', 280000, 280000, 280000, 280000, '', 1, 0),
(340, 21, 'Tôm Sú Nướng Sa Tế  Cay', 'Tôm Sú Nướng Sa Tế  Cay', 'Kg', 280000, 280000, 280000, 280000, '', 1, 0),
(341, 25, 'Cua Rang Muối', 'Cua Rang Muối', 'Kg', 280000, 280000, 280000, 280000, '', 1, 0),
(342, 25, 'Cua Hấp Bia ', 'Cua Hấp Bia ', 'Kg', 280000, 280000, 280000, 280000, '', 1, 0),
(343, 25, 'Cua Hấp Nước Dừa', 'Cua Hấp Nước Dừa', 'Kg', 280000, 280000, 280000, 280000, '', 1, 0),
(344, 25, 'Cua Luộc', 'Cua Luộc', 'Kg', 280000, 280000, 280000, 280000, '', 1, 0),
(345, 25, 'Cua Nấu Lẩu', 'Cua Nấu Lẩu', 'Kg', 280000, 280000, 280000, 280000, '', 1, 0),
(346, 25, 'Ghẹ Rang Muối', 'Ghẹ Rang Muối', 'Kg', 380000, 380000, 380000, 380000, '', 1, 0),
(347, 25, 'Ghẹ Hấp Bia', 'Ghẹ Hấp Bia', 'Kg', 380000, 380000, 380000, 380000, '', 1, 0),
(348, 25, 'Ghẹ Hấp Nước Dừa', 'Ghẹ Hấp Nước Dừa', 'Kg', 380000, 380000, 380000, 380000, '', 1, 0),
(349, 25, 'Ghẹ Luộc', 'Ghẹ Luộc', 'Kg', 380000, 380000, 380000, 380000, '', 1, 0),
(350, 25, 'Ghẹ Nấu Lẩu', 'Ghẹ Nấu Lẩu', 'Kg', 380000, 380000, 380000, 380000, '', 1, 0),
(351, 15, 'Sò Huyết Rang Muối', 'Sò Huyết Rang Muối', 'Dĩa', 55000, 55000, 55000, 55000, '', 1, 0),
(352, 15, 'Sò Huyết Rang Muối Hồng Kông', 'Sò Huyết Rang Muối Hồng Kông', 'Dĩa', 58000, 58000, 58000, 58000, '', 1, 0),
(353, 15, 'Sò Huyết Rang Me ', 'Sò Huyết Rang Me ', 'Dĩa', 55000, 55000, 55000, 55000, '', 1, 0),
(354, 15, 'Sò Huyết Cháy Tỏi', 'Sò Huyết Cháy Tỏi', 'Dĩa', 55000, 55000, 55000, 55000, '', 1, 0),
(355, 15, 'Sò Huyết Lacost', 'Sò Huyết Lacost', 'Dĩa', 58000, 58000, 58000, 58000, '', 1, 0),
(356, 15, 'Sò Huyết Tứ Xuyên', 'Sò Huyết Tứ Xuyên', 'Dĩa', 58000, 58000, 58000, 58000, '', 1, 0),
(357, 15, 'Sò Huyết Xào Rau Râm', 'Sò Huyết Xào Rau Râm', 'Dĩa', 58000, 58000, 58000, 58000, '', 1, 0),
(358, 15, 'Sò Huyết Nướng Mọi', 'Sò Huyết Nướng Mọi', 'Dĩa', 58000, 58000, 58000, 58000, '', 1, 0),
(359, 15, 'Nghêu Hấp Gừng', 'Nghêu Hấp Gừng', 'Dĩa', 55000, 55000, 55000, 55000, '', 1, 0),
(360, 15, 'Nghêu Hấp Thái', 'Nghêu Hấp Thái', 'Dĩa', 55000, 55000, 55000, 55000, '', 1, 0),
(361, 21, 'Hàu Sữa Nướng Mỡ Hành', 'Hàu Sữa Nướng Mỡ Hành', 'Con', 18000, 18000, 18000, 18000, '', 1, 0),
(362, 21, 'Hàu Sữa Đút Lò', 'Hàu Sữa Đút Lò', 'Con', 18000, 18000, 18000, 18000, '', 1, 0),
(363, 21, 'Hàu Sữa Nướng Phô Mai', 'Hàu Sữa Nướng Phô Mai', 'Con', 18000, 18000, 18000, 18000, '', 1, 0),
(364, 21, 'Hàu Sữa Nướng Trứng Cúc', 'Hàu Sữa Nướng Trứng Cúc', 'Con', 18000, 18000, 18000, 18000, '', 1, 0),
(365, 26, 'Gà Hấp Bia', 'Gà Hấp Bia', 'Dĩa', 118000, 118000, 118000, 118000, '', 1, 0),
(366, 26, 'Gà Hấp Cải Thìa', 'Gà Hấp Cải Thìa', 'Dĩa', 118000, 118000, 118000, 118000, '', 1, 0),
(367, 26, 'Gà Nướng Muối Ớt', 'Gà Nướng Muối Ớt', 'Dĩa', 118000, 118000, 118000, 118000, '', 1, 0),
(368, 26, 'Cánh Gà Chiên Nước Mắm', 'Cánh Gà Chiên Nước Mắm', 'Dĩa', 55000, 55000, 55000, 55000, '', 1, 0),
(369, 26, 'Chân Gà Chiên Nước Mắm', 'Chân Gà Chiên Nước Mắm', 'Dĩa', 55000, 55000, 55000, 55000, '', 1, 0),
(370, 13, 'Lẩu Gà Chanh ỚT', 'Lẩu Gà Chanh ỚT', 'Cái', 138000, 138000, 138000, 138000, '', 1, 0),
(371, 13, 'Lẩu Gà Lá Giang', 'Lẩu Gà Lá Giang', 'Cái', 148000, 148000, 148000, 148000, '', 1, 0),
(372, 16, 'Bò Lúc Lắc + Khoai Tây', 'Bò Lúc Lắc + Khoai Tây', 'Dĩa', 118000, 118000, 118000, 118000, '', 1, 0),
(373, 16, 'Bò Xào Chua Ngọt', 'Bò Xào Chua Ngọt', 'Dĩa', 55000, 55000, 55000, 55000, '', 1, 0),
(374, 16, 'Bò Xào Củ Hành', 'Bò Xào Củ Hành', 'Dĩa', 58000, 58000, 58000, 58000, '', 1, 0),
(375, 16, 'Bò Xào Khổ Qua', 'Bò Xào Khổ Qua', 'Dĩa', 58000, 58000, 58000, 58000, '', 1, 0),
(376, 16, 'Bò Tái Chanh', 'Bò Tái Chanh', 'Dĩa', 55000, 55000, 55000, 55000, '', 1, 0),
(377, 16, 'Bò Nướng Muối Ớt', 'Bò Nướng Muối Ớt', 'Dĩa', 118000, 118000, 118000, 118000, '', 1, 0),
(378, 16, 'Bò Nướng Sa Tế', 'Bò Nướng Sa Tế', 'Dĩa', 58000, 58000, 58000, 58000, '', 1, 0),
(379, 16, 'Bò Né', 'Bò Né', 'Dĩa', 118000, 118000, 118000, 118000, '', 1, 0),
(380, 16, 'Bò Bốp Thấu', 'Bò Bốp Thấu', 'Dĩa', 55000, 55000, 55000, 55000, '', 1, 0),
(381, 3, 'Mực Nướng Muối Ớt', 'Mực Nướng Muối Ớt', 'Kg', 58000, 58000, 58000, 58000, '', 1, 0),
(382, 3, 'Mực Chiên Giòn', 'Mực Chiên Giòn', 'Kg', 58000, 58000, 58000, 58000, '', 1, 0),
(383, 17, 'Mì xào giòn', 'Mì xào giòn', 'Dĩa', 58000, 58000, 58000, 58000, '', 1, 0),
(384, 27, 'Se Sẻ Nướng Muối Ớt', 'Se Sẻ Nướng Muối Ớt', 'Dĩa', 58000, 58000, 58000, 58000, '', 1, 0),
(385, 27, 'Se Sẻ Rôti', 'rôti', 'Dĩa', 58000, 58000, 58000, 58000, '', 1, 0),
(386, 27, 'Se Sẻ Nướng Sa Tế', 'Nướng Sa tế', 'Dĩa', 58000, 58000, 58000, 58000, '', 1, 0),
(387, 8, 'Cá Tầm Hấp Tàu Xì', 'Cá Tầm Hấp Tàu Xì', 'Kg', 350000, 350000, 350000, 350000, '', 1, 0),
(388, 8, 'Cá Hồng Biển Hấp Tàu Xì', 'Cá Hồng Biển Hấp Tàu Xì', 'Kg', 280000, 280000, 280000, 280000, '', 1, 0),
(389, 8, 'Cá Đuối Nướng Muối Ớt', 'Cá Đuối Nướng Muối Ớt', 'Kg', 350000, 350000, 350000, 350000, '', 1, 0),
(390, 8, 'Cá Đuối Nướng Xa tế Cay', 'Cá Đuối Nướng Xa tế Cay', 'Kg', 350000, 350000, 350000, 350000, '', 1, 0),
(391, 8, 'Cá Đuối Hấp Hành', 'Cá Đuối Hấp Hành', 'Kg', 350000, 350000, 350000, 350000, '', 1, 0),
(392, 8, 'Cá Đuối Nấu Lẩu', 'Cá Đuối Nấu Lẩu', 'Kg', 350000, 350000, 350000, 350000, '', 1, 0),
(393, 12, 'Cá chép Giòn Hấp Tàu Xì', 'Cá chép Giòn Hấp Tàu Xì', 'Kg', 380000, 380000, 380000, 380000, '', 1, 0),
(394, 21, 'Tôm Lóng Hấp Nước Dừa', 'Tôm Lóng Hấp Nước Dừa', 'Kg', 290000, 290000, 290000, 290000, '', 1, 0),
(395, 21, 'Tôm Sú Hấp Bia', 'Tôm Sú Hấp Bia', 'Kg', 280000, 280000, 280000, 280000, '', 1, 0),
(396, 21, 'Tôm Sú Hấp Nước Dừa', 'Tôm Sú Hấp Nước Dừa', 'Kg', 280000, 280000, 280000, 280000, '', 1, 0),
(398, 21, 'Hàu Sữa Nướng Mọi', 'Hàu Sữa Nướng Mọi', 'Con', 18000, 18000, 18000, 18000, '', 1, 0),
(399, 26, 'Lẩu Gà Chanh Ớt', 'Lẩu Gà Chanh Ớt', 'Cái', 138000, 138000, 138000, 138000, '', 1, 0),
(400, 26, 'Lẩu Gà Lá Giang', 'Lẩu Gà Lá Giang', 'Cái', 148000, 148000, 148000, 148000, '', 1, 0),
(401, 28, 'Nai Nướng Ngũ Vị', 'Nai Nướng Ngũ Vị', 'Dĩa', 58000, 58000, 58000, 58000, '', 1, 0),
(402, 28, 'Nai Xào Sa tế', 'Nai Xào Sa tế', 'Dĩa', 58000, 58000, 58000, 58000, '', 1, 0),
(404, 28, 'Nai Né', 'Nai Né', 'Cái', 88000, 88000, 88000, 88000, '', 1, 0),
(405, 11, 'Sagota', 'Sagota', 'Lon', 14000, 14000, 14000, 14000, '', 0, 0),
(406, 23, 'Trà C2', 'Trà C2', 'Chai', 10000, 10000, 10000, 10000, '', 0, 0),
(407, 18, ' Bồ Đào Đá', ' Bồ Đào Đá', 'Chai', 108000, 108000, 108000, 108000, '', 0, 0),
(408, 30, 'Thuốc Mèo', 'Thuốc Mèo', 'Gói', 22000, 22000, 22000, 22000, '', 0, 0),
(409, 30, 'Thuốc 555', 'Thuốc 555', 'Cái', 30000, 30000, 30000, 30000, '', 0, 0),
(410, 30, 'Quẹt gas', 'Quẹt gas', 'Cái', 5000, 5000, 5000, 5000, '', 0, 0),
(411, 11, 'Sagota vàng', 'Sagota vàng', 'Lon', 11000, 11000, 11000, 11000, '', 0, 0),
(412, 31, 'Đậu nành rau', 'Đậu nành rau', 'Bịch', 20000, 20000, 20000, 20000, '', 0, 0),
(414, 8, 'Cá  Quế Nướng Sa Tế', 'Cá  Quế Nướng Sa Tế', 'Kg', 380000, 380000, 380000, 380000, '', 1, 0),
(415, 8, 'Cá  Quế Nướng Muối Ớt Cay', 'Cá  Quế Nướng Muối Ớt Cay', 'Kg', 380000, 380000, 380000, 380000, '', 1, 0),
(416, 8, 'Cá  Quế Nấu Lẩu', 'Cá  Quế Nấu Lẩu', 'Kg', 380000, 380000, 380000, 380000, '', 1, 0),
(417, 22, 'Karaoke', '', 'Bịch', 460000, 460000, 460000, 460000, '', 0, 0),
(418, 22, 'Kho quẹt thêm', 'Kho quẹt thêm', 'Cái', 30000, 30000, 30000, 30000, '', 1, 0),
(419, 22, 'Mì khô', 'Mì khô', 'Dĩa', 15, 15, 15, 15, '', 1, 0),
(420, 32, 'Trái cây', 'Trái cây', 'Dĩa', 38000, 38000, 38000, 38000, '', 1, 0),
(421, 13, 'Lẩu thái Hải sản', 'Lẩu thái Hải sản', 'Cái', 128000, 128000, 128000, 128000, '', 1, 0),
(422, 13, 'Mì Gói', 'Mì Gói', 'Gói', 5000, 5000, 5000, 5000, '', 1, 0),
(423, 22, 'Mì khô', '', 'Dĩa', 15000, 15000, 15000, 15000, '', 0, 0),
(424, 33, 'Khăn lạnh', 'Khăn lạnh', 'Cái', 2000, 2000, 2000, 2000, '', 1, 0),
(425, 8, 'Cá Lăng Vàng Nướng Muối Ớt', 'Cá Lăng Vàng Nướng Muối Ớt', 'Kg', 350000, 350000, 350000, 350000, '', 0, 0),
(426, 8, 'Cá Lăng Vàng Nướng Sa Tế Cay', 'Cá Lăng Vàng Nướng Sa Tế Cay', 'Kg', 350000, 350000, 350000, 350000, '', 1, 0),
(427, 8, 'Cá Lăng Vàng Nấu lẩu', 'Cá Lăng Vàng Nấu lẩu', 'Kg', 350000, 350000, 350000, 350000, '', 1, 0),
(429, 25, 'Càng Cua Đá Rang me', 'Càng Cua Đá Rang me', 'Dĩa', 55000, 55000, 55000, 55000, '', 1, 0),
(430, 25, 'Càng Cua Đá Cháy Tỏi', 'Càng Cua Đá Cháy Tỏi', 'Dĩa', 55000, 55000, 55000, 55000, '', 1, 0),
(431, 25, 'Càng Cúm Rang Muối Tuyết', 'Càng Cúm Rang Muối Tuyết', 'Dĩa', 58000, 58000, 58000, 58000, '', 1, 0),
(432, 25, 'Càng Cúm Rang Me ', 'Càng Cúm Rang Me ', 'Dĩa', 58000, 58000, 58000, 58000, '', 1, 0),
(433, 25, 'Càng Cúm Cháy Tỏi', 'Càng Cúm Cháy Tỏi', 'Dĩa', 58000, 58000, 58000, 58000, '', 1, 0),
(434, 25, 'Càng Ghẹ Rang Muối Tuyết', 'Càng Ghẹ Rang Muối Tuyết', 'Dĩa', 88000, 88000, 88000, 88000, '', 1, 0),
(435, 25, 'Càng Ghẹ Rang Me', 'Càng Ghẹ Rang Me', 'Dĩa', 88000, 88000, 88000, 88000, '', 1, 0),
(436, 25, 'Càng Ghẹ Cháy Tỏi', 'Càng Ghẹ Cháy Tỏi', 'Dĩa', 88000, 88000, 88000, 88000, '', 1, 0),
(437, 20, 'Cơm Chiên Ghẹ', 'Cơm Chiên Ghẹ', 'Dĩa', 55000, 55000, 55000, 55000, '', 1, 0),
(438, 3, 'Mực xào rau ', 'Mực xào rau ', 'Dĩa', 58000, 58000, 58000, 58000, '', 1, 0),
(439, 33, 'Mù Tạt', 'Mù Tạt', 'Chai', 20000, 20000, 20000, 20000, '', 0, 0),
(441, 22, 'Bánh mì', '', 'Bịch', 5000, 5000, 5000, 5000, '', 0, 0),
(442, 22, 'Thuốc 555 Vàng', '', 'Bịch', 35000, 35000, 35000, 35000, '', 0, 0),
(443, 21, 'Tôm Sông Nướng Muối Ớt', 'Tôm Sông Nướng Muối Ớt', 'Kg', 320000, 320000, 320000, 320000, '', 1, 0),
(444, 21, 'Tôm Sông Nướng Sa Tế Cay', 'Tôm Sông Nướng Sa Tế Cay', 'Kg', 320000, 320000, 320000, 320000, '', 1, 0),
(445, 22, 'Gà nguyên con', 'ga nguyen con', 'Kg', 150000, 150000, 150000, 150000, '', 1, 0),
(446, 22, 'Tôm càng xanh', 'tom cang xanh', 'Kg', 320000, 320000, 320000, 320000, '', 1, 0),
(447, 22, 'Tôm sú nướng muối ớt', 'tom su nuong', 'Dĩa', 65000, 65000, 65000, 65000, '', 1, 0),
(448, 12, 'Cá chạch quế sốt me', 'Cá chạch quế sốt me', 'Kg', 380000, 380000, 380000, 380000, '', 1, 0),
(449, 22, 'Chả cá chiên', '', 'Dĩa', 0, 0, 0, 0, '', 1, 0),
(450, 8, 'Cá Nhám Nướng Muối Ớt', 'Cá Nhám Nướng Muối Ớt', 'Kg', 180000, 180000, 180000, 180000, '', 1, 0),
(451, 8, 'Cá Nhám Nướng Sa Tế', 'Cá Nhám Nướng Sa Tế', 'Kg', 180000, 180000, 180000, 180000, '', 1, 0),
(452, 28, 'Nai Xào Chua Ngọt', 'Nai Xào Chua Ngọt', 'Dĩa', 58000, 58000, 58000, 58000, '', 1, 0),
(453, 34, 'Ốc mỡ cháy tỏi', 'Ốc mỡ cháy tỏi', 'Kg', 220000, 220000, 220000, 220000, '', 1, 0),
(454, 24, 'Càng cua bách hoa', 'Càng cua bách hoa', 'Dĩa', 55000, 55000, 55000, 55000, '', 1, 0),
(455, 22, 'Thuốc hút', '', 'Gói', 25000, 25000, 25000, 25000, '', 0, 0),
(456, 21, 'Tôm Sông Hấp Nước Dừa', 'Tôm Sông Hấp Nước Dừa', 'Kg', 320000, 320000, 320000, 320000, '', 1, 0),
(457, 24, 'Đậu Hủ Nướng Giấy Bạc', 'Đậu Hủ Nướng Giấy Bạc', 'Dĩa', 48000, 48000, 48000, 48000, '', 1, 0),
(458, 24, 'Đậu Hủ Tứ Xuyên', 'Đậu Hủ Tứ Xuyên', 'Dĩa', 55000, 55000, 55000, 55000, '', 1, 0),
(459, 24, 'Chả Giò Ghẹ', 'Chả Giò Ghẹ', 'Dĩa', 58000, 58000, 58000, 58000, '', 1, 0),
(460, 24, 'Rau Củ Chiên giòn', 'Rau Củ Chiên giòn', 'Dĩa', 48000, 48000, 48000, 48000, '', 1, 0),
(461, 24, 'Trứng Cuộn Tôm', 'Trứng Cuộn Tôm', 'Dĩa', 55000, 55000, 55000, 55000, '', 1, 0),
(462, 24, 'Ốc Hấp Gừng', 'Ốc Hấp Gừng', 'Dĩa', 55000, 55000, 55000, 55000, '', 1, 0),
(463, 24, 'Chả Tôm Cuốn Đậu Bắp', 'Chả Tôm Cuốn Đậu Bắp', 'Dĩa', 55000, 55000, 55000, 55000, '', 1, 0),
(464, 35, 'Khoai Môn Ba Đức', 'Khoai Môn Ba Đức', 'Dĩa', 55000, 55000, 55000, 55000, '', 1, 0),
(465, 35, 'Cơm Chiên Ba Đức', 'Cơm Chiên Ba Đức', 'Dĩa', 55000, 55000, 55000, 55000, '', 1, 0),
(466, 35, 'Lẩu Gà Ba Đức', 'Lẩu Gà Ba Đức', 'Cái', 58000, 58000, 58000, 58000, '', 1, 0),
(467, 35, 'Lẩu Thái Ba Đức', 'Lẩu Thái Ba Đức', 'Cái', 88000, 88000, 88000, 88000, '', 1, 0),
(468, 35, 'Hải Sản Nướng Ba Đức', 'Hải Sản Nướng Ba Đức', 'Cái', 88000, 88000, 88000, 88000, '', 1, 0),
(469, 35, 'Cá Chạch Quế Ba Đức', 'Cá Chạch Quế Ba Đức', 'Dĩa', 128000, 128000, 128000, 128000, '', 14, 0),
(470, 8, 'Cá Nhám Nấu Lẩu', 'Cá Nhám Nấu Lẩu', 'Kg', 160000, 160000, 160000, 160000, '', 1, 0),
(471, 21, 'Tôm Sông Hấp Bia', 'Tôm Sông Hấp Bia', 'Kg', 320000, 320000, 320000, 320000, '', 1, 0),
(472, 21, 'Tôm Sông Ăn Sống Mù Tạt', 'Tôm Sông Ăn Sống Mù Tạt', 'Kg', 320000, 320000, 320000, 320000, '', 1, 0),
(473, 3, 'Mực Hấp Thố', 'Mực Hấp Thố', 'Dĩa', 58000, 58000, 58000, 58000, '', 1, 0),
(474, 8, 'Cá Sapa Nướng Giấy Bạc', 'Cá Sapa Nướng Giấy Bạc', 'Dĩa', 88000, 88000, 88000, 88000, '', 1, 0),
(475, 25, 'Càng Cua Đá Rang Muối', 'Càng Cua Đá Rang Muối', 'Dĩa', 55000, 55000, 55000, 55000, '', 1, 0),
(476, 34, 'Ốc Dùi Nướng Tiêu', 'Ốc Dùi Nướng Tiêu', 'Dĩa', 48000, 48000, 48000, 48000, '', 1, 0),
(477, 26, 'Chân Gà Nướng Muối Ớt', 'Chân Gà Nướng Muối Ớt', 'Dĩa', 55000, 55000, 55000, 55000, '', 1, 0),
(478, 13, 'Lẩu Bạch Tuộc', 'Lẩu Bạch Tuộc', 'Kg', 320000, 320000, 320000, 320000, '', 1, 0),
(479, 13, 'Lẩu Cua Đồng', 'Lẩu Cua Đồng', 'Cái', 128000, 128000, 128000, 128000, '', 1, 0),
(480, 13, 'Lẩu Bò Nhúng Mẻ', 'Lẩu Bò Nhúng Mẻ', 'Cái', 148000, 148000, 148000, 148000, '', 1, 0),
(481, 13, 'Lẩu Cá Bóp Nấu Mẻ', 'Lẩu Cá Bóp Nấu Mẻ', 'Cái', 148000, 148000, 148000, 148000, '', 1, 0),
(482, 13, 'Lẩu Cháo Hào', 'Lẩu Cháo Hào', 'Cái', 128000, 128000, 128000, 128000, '', 1, 0),
(483, 13, 'Lẩu Cháo Sò Huyết', 'Lẩu Cháo Sò Huyết', 'Cái', 128000, 128000, 128000, 128000, '', 1, 0),
(484, 28, 'Nai xong khói', 'Nai xong khói', 'Dĩa', 58000, 58000, 58000, 58000, '', 1, 0),
(485, 34, 'Ốc mỡ rang me', 'Ốc mỡ rang me', 'Kg', 220000, 220000, 220000, 220000, '', 1, 0),
(486, 22, 'Chùm ruột', '', 'Bịch', 20000, 20000, 20000, 20000, '', 0, 0),
(487, 34, 'Ốc Dùi Hấp Tiêu', 'Ốc Dùi Hấp Tiêu', 'Con', 10000, 10000, 10000, 10000, '', 1, 0),
(488, 22, 'Thuốc hút', '', 'Gói', 22000, 22000, 22000, 22000, '', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_course_log`
--

CREATE TABLE IF NOT EXISTS `tbl_course_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_table` int(11) NOT NULL,
  `id_course` int(11) NOT NULL,
  `date_time` datetime NOT NULL,
  `count` int(11) NOT NULL,
  `state` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=568 ;

--
-- Dumping data for table `tbl_course_log`
--

INSERT INTO `tbl_course_log` (`id`, `id_table`, `id_course`, `date_time`, `count`, `state`) VALUES
(565, 1, 380, '2014-01-23 22:37:54', 1, 0),
(566, 1, 380, '2014-01-23 22:37:57', 1, 0),
(567, 1, 380, '2014-01-23 22:37:57', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_customer`
--

CREATE TABLE IF NOT EXISTS `tbl_customer` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  `card` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `discount` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=24 ;

--
-- Dumping data for table `tbl_customer`
--

INSERT INTO `tbl_customer` (`id`, `name`, `type`, `card`, `phone`, `address`, `note`, `discount`) VALUES
(1, 'Khách lẻ', 0, '1', '', '', '', 0),
(12, 'Khách VIP1', 1, 'vip1', '0919 111 222', 'Vĩnh Long', '', 5),
(13, 'Khách VIP2', 1, 'vip2', '0949 959997', 'Đồng Tháp', '', 10);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_domain`
--

CREATE TABLE IF NOT EXISTS `tbl_domain` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

--
-- Dumping data for table `tbl_domain`
--

INSERT INTO `tbl_domain` (`id`, `name`) VALUES
(1, 'KHU A'),
(2, 'KHU B'),
(3, 'KHU C'),
(4, 'KHU D'),
(5, 'KH MUA VỀ');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_employee`
--

CREATE TABLE IF NOT EXISTS `tbl_employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `job` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `gender` tinyint(2) NOT NULL,
  `phone` varchar(13) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `salary_base` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=11 ;

--
-- Dumping data for table `tbl_employee`
--

INSERT INTO `tbl_employee` (`id`, `name`, `job`, `gender`, `phone`, `address`, `salary_base`) VALUES
(2, 'Nguyễn Văn A', 'Phục vụ', 0, '', 'Đồng Tháp', 3000000),
(6, 'Nguyễn Văn B', 'NV Bếp', 0, '', 'Đồng Tháp', 2500000),
(7, 'Nguyễn Văn C', 'Bếp chính', 0, '', 'Đồng Tháp', 5500000),
(8, 'Nguyễn Văn D', 'NV bếp', 0, '', 'Đồng Tháp', 2500000),
(9, 'Nguyễn Văn E', 'NV PV', 0, '', 'Đồng Tháp', 2500000),
(10, 'Nguyễn Văn F', 'NV PV', 1, '', 'Đồng Tháp', 1300000);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_guest`
--

CREATE TABLE IF NOT EXISTS `tbl_guest` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(16) CHARACTER SET latin1 NOT NULL,
  `entry_time` varchar(32) CHARACTER SET latin1 NOT NULL,
  `exit_time` varchar(32) CHARACTER SET latin1 NOT NULL,
  `agent` varchar(16) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=150 ;

--
-- Dumping data for table `tbl_guest`
--

INSERT INTO `tbl_guest` (`id`, `ip`, `entry_time`, `exit_time`, `agent`) VALUES
(149, '115.78.94.118', '1383319305', '1383322905', '115.78.94.118');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_notify`
--

CREATE TABLE IF NOT EXISTS `tbl_notify` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  `message` varchar(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tbl_notify`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_order_import`
--

CREATE TABLE IF NOT EXISTS `tbl_order_import` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idsupplier` int(11) NOT NULL,
  `date` date NOT NULL,
  `description` varchar(50) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_order_import_1` (`idsupplier`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=352 ;

--
-- Dumping data for table `tbl_order_import`
--

INSERT INTO `tbl_order_import` (`id`, `idsupplier`, `date`, `description`) VALUES
(350, 16, '2013-12-28', ''),
(351, 13, '2014-01-17', '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order_import_detail`
--

CREATE TABLE IF NOT EXISTS `tbl_order_import_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idorder` int(11) NOT NULL,
  `idresource` int(11) NOT NULL,
  `count` float NOT NULL,
  `price` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_order_import_detail_1` (`idorder`),
  KEY `tbl_order_import_detail_2` (`idresource`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=641 ;

--
-- Dumping data for table `tbl_order_import_detail`
--

INSERT INTO `tbl_order_import_detail` (`id`, `idorder`, `idresource`, `count`, `price`) VALUES
(636, 350, 169, 2, 16000),
(637, 350, 168, 2, 15000),
(638, 350, 170, 1, 25000),
(639, 351, 114, 0.2, 230000),
(640, 351, 115, 0.3, 230000);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_paid_customer`
--

CREATE TABLE IF NOT EXISTS `tbl_paid_customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idcustomer` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_customer_paid_1` (`idcustomer`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tbl_paid_customer`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_paid_employee`
--

CREATE TABLE IF NOT EXISTS `tbl_paid_employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_employee` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(150) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_employee` (`id_employee`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `tbl_paid_employee`
--

INSERT INTO `tbl_paid_employee` (`id`, `id_employee`, `date`, `value`, `note`) VALUES
(3, 2, '2014-01-16', 10, 'bep ung');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_paid_general`
--

CREATE TABLE IF NOT EXISTS `tbl_paid_general` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_term` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_paid_1` (`id_term`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=167 ;

--
-- Dumping data for table `tbl_paid_general`
--

INSERT INTO `tbl_paid_general` (`id`, `id_term`, `date`, `value`, `note`) VALUES
(9, 10, '2013-04-01', 157000, 'Chi tiền chợ'),
(10, 10, '2013-04-02', 146000, 'Tiền chợ'),
(11, 10, '2013-04-03', 189000, 'Tiền chợ'),
(12, 10, '2013-04-04', 184000, 'Tiền chợ'),
(20, 11, '2013-04-06', 163000, 'Chi mua đồ điện '),
(21, 11, '2013-12-04', 250000, 'Mua CB'),
(22, 11, '2013-04-07', 57000, 'Trái cây cúng+bao kiếng trái cây'),
(66, 2, '2013-04-30', 2100000, 'Tạm tính'),
(111, 3, '2013-07-31', 1500000, 'Thuế TTĐB Tháng 07'),
(112, 1, '2013-07-31', 4000000, 'Tiền điện T07'),
(113, 2, '2013-07-31', 2000000, 'Tiền nước T07'),
(155, 3, '2013-08-31', 800000, 'Thuế TTĐB T08'),
(156, 3, '2013-09-30', 850000, 'Thuế TTĐB T09'),
(158, 1, '2013-08-31', 5800000, 'Tiền điện T08'),
(159, 1, '2013-09-30', 3700000, 'Tiền điện T09'),
(160, 2, '2013-08-31', 2200000, 'Tiền nước T08'),
(161, 2, '2013-09-30', 2300000, 'Tiền nước T09'),
(163, 1, '2013-05-31', 4700000, 'Tiền điện T05'),
(164, 1, '2013-06-30', 3900000, 'Tiền điện T06'),
(165, 2, '2013-05-31', 2350000, 'Tiền nước T05'),
(166, 2, '2013-06-30', 2260000, 'Tiền nước T06');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_paid_pay_roll`
--

CREATE TABLE IF NOT EXISTS `tbl_paid_pay_roll` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_employee` int(11) NOT NULL,
  `date` date NOT NULL,
  `value_base` int(11) NOT NULL,
  `value_sub` int(11) NOT NULL,
  `value_pre` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_paid_pay_roll_1` (`id_employee`),
  KEY `id_employee` (`id_employee`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tbl_paid_pay_roll`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_paid_supplier`
--

CREATE TABLE IF NOT EXISTS `tbl_paid_supplier` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idsupplier` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_supplier_paid_1` (`idsupplier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tbl_paid_supplier`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_pay_roll`
--

CREATE TABLE IF NOT EXISTS `tbl_pay_roll` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_employee` int(11) NOT NULL,
  `date` date NOT NULL,
  `state` int(11) NOT NULL,
  `extra` int(11) NOT NULL,
  `late` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_employee` (`id_employee`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=97 ;

--
-- Dumping data for table `tbl_pay_roll`
--

INSERT INTO `tbl_pay_roll` (`id`, `id_employee`, `date`, `state`, `extra`, `late`) VALUES
(32, 2, '2013-10-01', 1, 0, 0),
(33, 2, '2013-10-02', 1, 0, 0),
(34, 2, '2013-10-03', 1, 0, 0),
(35, 2, '2013-10-04', 1, 0, 0),
(36, 2, '2013-10-05', 1, 0, 0),
(37, 2, '2013-10-06', 1, 0, 0),
(38, 2, '2013-10-07', 1, 0, 0),
(39, 2, '2013-10-08', 1, 0, 0),
(40, 2, '2013-10-09', 1, 0, 0),
(41, 2, '2013-10-10', 1, 0, 0),
(42, 2, '2013-10-11', 1, 0, 0),
(43, 2, '2013-10-12', 1, 0, 0),
(44, 2, '2013-10-13', 1, 0, 0),
(45, 2, '2013-10-14', 1, 0, 0),
(46, 2, '2013-10-15', 1, 0, 0),
(47, 2, '2013-10-16', 1, 0, 0),
(48, 2, '2013-10-17', 1, 0, 0),
(49, 2, '2013-10-18', 1, 0, 0),
(50, 2, '2013-10-19', 1, 0, 0),
(51, 2, '2013-10-20', 1, 0, 0),
(52, 2, '2013-10-21', 1, 0, 0),
(53, 2, '2013-10-22', 1, 0, 0),
(54, 2, '2013-10-23', 1, 0, 0),
(55, 2, '2013-10-24', 1, 0, 0),
(56, 2, '2013-10-25', 1, 0, 0),
(57, 2, '2013-10-26', 1, 0, 0),
(58, 2, '2013-10-27', 1, 0, 0),
(59, 2, '2013-10-28', 1, 0, 0),
(60, 2, '2013-10-29', 1, 0, 0),
(61, 2, '2013-10-30', 1, 0, 0),
(62, 2, '2013-10-31', 1, 0, 0),
(63, 6, '2013-12-14', 1, 0, 0),
(64, 7, '2014-01-09', 1, 0, 0),
(66, 2, '2013-12-01', 0, 0, 0),
(67, 2, '2013-12-02', 0, 0, 0),
(68, 2, '2013-12-03', 0, 0, 0),
(69, 2, '2013-12-04', 0, 0, 0),
(70, 2, '2013-12-05', 0, 0, 0),
(71, 2, '2013-12-06', 0, 0, 0),
(72, 2, '2013-12-07', 0, 0, 0),
(73, 2, '2013-12-08', 0, 0, 0),
(74, 2, '2013-12-09', 0, 0, 0),
(75, 2, '2013-12-10', 0, 0, 0),
(76, 2, '2013-12-11', 0, 0, 0),
(77, 2, '2013-12-12', 0, 0, 0),
(78, 2, '2013-12-13', 0, 0, 0),
(79, 2, '2013-12-14', 0, 0, 0),
(80, 2, '2013-12-15', 0, 0, 0),
(81, 2, '2013-12-16', 0, 0, 0),
(82, 2, '2013-12-17', 0, 0, 0),
(83, 2, '2013-12-18', 0, 0, 0),
(84, 2, '2013-12-19', 0, 0, 0),
(85, 2, '2013-12-20', 0, 0, 0),
(86, 2, '2013-12-21', 0, 0, 0),
(87, 2, '2013-12-22', 0, 0, 0),
(88, 2, '2013-12-23', 0, 0, 0),
(89, 2, '2013-12-24', 0, 0, 0),
(90, 2, '2013-12-25', 0, 0, 0),
(91, 2, '2013-12-26', 0, 0, 0),
(92, 2, '2013-12-27', 0, 0, 0),
(93, 2, '2013-12-28', 1, 0, 0),
(94, 2, '2013-12-29', 1, 0, 0),
(95, 2, '2013-12-30', 1, 0, 0),
(96, 2, '2013-12-31', 1, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_r2c`
--

CREATE TABLE IF NOT EXISTS `tbl_r2c` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_course` int(11) NOT NULL,
  `id_resource` int(11) NOT NULL,
  `value1` double NOT NULL,
  `value2` double NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_r2c_1` (`id_course`),
  KEY `tbl_r2c_2` (`id_resource`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tbl_r2c`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_resource`
--

CREATE TABLE IF NOT EXISTS `tbl_resource` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `idsupplier` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `unit` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `price` int(10) NOT NULL,
  `description` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_resource_1` (`idsupplier`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=211 ;

--
-- Dumping data for table `tbl_resource`
--

INSERT INTO `tbl_resource` (`id`, `idsupplier`, `name`, `unit`, `price`, `description`) VALUES
(105, 21, 'SG special chai', 'Chai', 9600, ''),
(106, 21, 'SG special lon', 'Lon', 11000, ''),
(107, 21, 'SG đỏ', 'Chai', 6600, ''),
(108, 21, 'Heneiken chai', 'Chai', 12050, ''),
(109, 21, 'Heneiken lon', 'Lon', 14000, ''),
(110, 21, 'Tiger nâu', 'Chai', 11000, ''),
(111, 21, 'Tiger bạc', 'Chai', 12000, ''),
(112, 28, 'Sagota', 'Lon', 12500, ''),
(113, 28, 'Sagota vàng', 'Lon', 11000, ''),
(114, 13, 'Cua biển', 'Kg', 230000, ''),
(115, 13, 'Ghẹ', 'Kg', 230000, ''),
(116, 13, 'Cá nhám', 'Kg', 90000, ''),
(117, 13, 'Cá đuối', 'Kg', 230000, ''),
(118, 13, 'Cá chạch quế', 'Kg', 270000, ''),
(119, 13, 'Cá quế', 'Kg', 270000, ''),
(120, 18, 'Gà ', 'Kg', 90000, ''),
(121, 19, 'Cá sapa ', 'Kg', 57000, ''),
(122, 19, 'Cá cam', 'Kg', 1, ''),
(123, 19, 'Cá bò da', 'Kg', 1, ''),
(124, 15, 'Sò huyết', 'Kg', 90000, ''),
(125, 15, 'Nghêu', 'Kg', 35000, ''),
(126, 14, 'Đá cắt', 'Kg', 800, ''),
(127, 14, 'Đá xay', 'Kg', 750, ''),
(128, 14, 'Đá cây', 'Kg', 600, ''),
(129, 22, 'Pepsi ', 'Lon', 6900, ''),
(130, 22, 'Sting lon', 'Lon', 6300, ''),
(131, 22, 'Trà C2', 'Chai', 4300, ''),
(132, 22, 'Suối lavie(500ml)', 'Chai', 3500, ''),
(133, 23, 'Rượu volka men', 'Chai', 1, ''),
(134, 23, 'Rượu phú lễ', 'Chai', 1, ''),
(135, 23, 'Rượu bồ đào đá', 'Chai', 1, ''),
(136, 17, 'Đường', 'Kg', 16000, ''),
(137, 17, 'Muối bọt', 'Bịch', 1, ''),
(138, 17, 'Muối hột', 'Bịch', 1, ''),
(139, 17, 'Bột ngọt', 'Bịch', 45000, ''),
(140, 17, 'Tương ớt', 'Chai', 52000, ''),
(141, 17, 'Tương cà', 'Chai', 1, ''),
(142, 17, 'Tương xí muội', 'Chai', 1, ''),
(143, 17, 'Dầu hào', 'Chai', 30000, ''),
(144, 17, 'Nước tương', 'Chai', 1, ''),
(145, 17, 'Mù tạt nhật', 'Chai', 1, ''),
(146, 17, 'Sữa ngôi sao', 'Hộp', 16000, ''),
(147, 17, 'Bột chiên giòn', 'Bịch', 5000, ''),
(148, 17, 'Bột chiên xù(lớn)', 'Bịch', 1, ''),
(149, 17, 'Bột chiên xù(nhỏ)', 'Bịch', 7000, ''),
(150, 17, 'Dầu ăn', 'Thùng', 650000, ''),
(151, 17, 'Dầu mè', 'Chai', 1, ''),
(152, 17, 'Bột tàu xì', 'Kg', 1, ''),
(153, 17, 'Sa tế', 'Chai', 1, ''),
(154, 17, 'Ngũ vị hương', 'Bịch', 1, ''),
(155, 17, 'Nước tương nam dương', 'Chai', 1, ''),
(156, 17, 'Bột nghệ', 'Kg', 1, ''),
(157, 17, 'Tiêu xay', 'Kg', 1, ''),
(158, 17, 'Tiêu sọ', 'Kg', 1, ''),
(159, 17, 'Bột cà ri', 'Bịch', 1, ''),
(160, 17, 'Đậu hà lan ', 'Lon', 1, ''),
(161, 16, 'Cần tàu', 'Kg', 20000, ''),
(162, 16, 'Gừng', 'Kg', 26000, ''),
(163, 16, 'Ghiền', 'Kg', 0, ''),
(164, 16, 'Rau muống', 'Kg', 8000, ''),
(165, 16, 'Salad lụa', 'Kg', 14000, ''),
(166, 16, 'Cà rốt', 'Kg', 17500, ''),
(167, 16, 'Rau sống', 'Kg', 18000, ''),
(168, 16, 'Hành lá', 'Kg', 15000, ''),
(169, 16, 'Hành tây', 'Kg', 16000, ''),
(170, 16, 'Hành tím', 'Kg', 25000, ''),
(171, 16, 'Rau râm', 'Kg', 10000, ''),
(172, 16, 'Rau nhúc', 'Kg', 0, ''),
(173, 16, 'Cù nèo', 'Kg', 0, ''),
(174, 16, 'Cải ngọt', 'Kg', 0, ''),
(175, 16, 'Cải thìa', 'Kg', 10000, ''),
(176, 17, 'Tỏi củ', 'Kg', 18000, ''),
(177, 16, 'Sả cộng', 'Kg', 10000, ''),
(178, 16, 'Ớt đà lạt', 'Kg', 0, ''),
(179, 16, 'Ớt hiểm xanh', 'Kg', 40000, ''),
(180, 16, 'Ớt sừng', 'Kg', 50000, ''),
(181, 16, 'Khoai môn', 'Kg', 20000, ''),
(182, 16, 'Khoai tây', 'Kg', 28000, ''),
(183, 16, 'Khổ hoa', 'Kg', 0, ''),
(184, 16, 'Dưa leo', 'Kg', 9000, ''),
(185, 16, 'Cà chua', 'Kg', 13000, ''),
(186, 16, 'Đậu bắp', 'Kg', 0, ''),
(187, 16, 'Khóm ', 'Trái', 9000, ''),
(188, 16, 'Cải thảo', 'Kg', 0, ''),
(189, 16, 'Chanh', 'Kg', 8000, ''),
(190, 16, 'Hạnh', 'Kg', 0, ''),
(191, 16, 'Khế', 'Kg', 0, ''),
(192, 16, 'Mồng tơi', 'Kg', 0, ''),
(193, 16, 'Mướp ', 'Kg', 0, ''),
(194, 16, 'Bầu', 'Kg', 0, ''),
(195, 16, 'Ngò rai', 'Kg', 0, ''),
(196, 16, 'Ngò ôm', 'Kg', 0, ''),
(197, 26, 'Đồ khui', 'Cái', 5000, ''),
(198, 26, 'Xô đá', 'Cái', 0, ''),
(199, 26, 'Gấp đá', 'Cái', 0, ''),
(200, 13, 'Cá chép giòn', 'Kg', 280000, ''),
(201, 13, 'Cá lăng', 'Kg', 75000, ''),
(202, 13, 'Cá lăng vàng', 'Kg', 250000, ''),
(203, 15, 'Mực ống', 'Kg', 160000, ''),
(205, 16, 'Nấm rơm', 'Kg', 50000, ''),
(206, 16, 'Củ cải trắng', 'Kg', 8000, ''),
(207, 16, 'Ngò rí', 'Kg', 40000, ''),
(208, 27, 'Mì gói', 'Gói', 2400, ''),
(209, 27, 'Phô mai', 'Miếng', 5000, ''),
(210, 16, 'Bắp chuối', 'Kg', 20000, '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_session`
--

CREATE TABLE IF NOT EXISTS `tbl_session` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idtable` int(11) NOT NULL,
  `iduser` int(11) NOT NULL,
  `idcustomer` int(11) NOT NULL,
  `idemployee` int(11) NOT NULL,
  `datetime` datetime NOT NULL,
  `datetimeend` datetime DEFAULT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  `discount_value` int(11) NOT NULL,
  `discount_percent` int(11) NOT NULL,
  `surtax` int(11) NOT NULL,
  `payment` int(11) NOT NULL,
  `value` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idtable` (`idtable`),
  KEY `iduser` (`iduser`),
  KEY `tbl_session_3` (`idcustomer`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=149 ;

--
-- Dumping data for table `tbl_session`
--

INSERT INTO `tbl_session` (`id`, `idtable`, `iduser`, `idcustomer`, `idemployee`, `datetime`, `datetimeend`, `note`, `status`, `discount_value`, `discount_percent`, `surtax`, `payment`, `value`) VALUES
(148, 1, 3, 1, 2, '2014-01-23 22:37:54', '2014-01-23 22:37:54', '', 1, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_session_detail`
--

CREATE TABLE IF NOT EXISTS `tbl_session_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idsession` int(11) NOT NULL,
  `idcourse` int(11) NOT NULL,
  `count` float NOT NULL,
  `price` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idsession` (`idsession`),
  KEY `idcourse` (`idcourse`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=770 ;

--
-- Dumping data for table `tbl_session_detail`
--

INSERT INTO `tbl_session_detail` (`id`, `idsession`, `idcourse`, `count`, `price`) VALUES
(769, 148, 380, 0.5, 55000);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_store`
--

CREATE TABLE IF NOT EXISTS `tbl_store` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(125) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_store`
--

INSERT INTO `tbl_store` (`id`, `name`, `note`) VALUES
(1, 'Kho nhà', 'Ghi chú gì đây ?');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_supplier`
--

CREATE TABLE IF NOT EXISTS `tbl_supplier` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `debt` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=29 ;

--
-- Dumping data for table `tbl_supplier`
--

INSERT INTO `tbl_supplier` (`id`, `name`, `phone`, `address`, `note`, `debt`) VALUES
(13, 'CÁ - CUA - GHẸ SỐNG', '', 'Can Tho', '', 0),
(14, 'NƯỚC ĐÁ - ĐL TRÍ', '', 'Vĩnh Long', '', 0),
(15, 'NGHÊU - SÒ - MỰC', '', 'Cần thơ', '', 0),
(16, 'RAU QUẢ', '', 'Chợ Vĩnh long', '', 0),
(17, 'GIA VỊ - TẠP HÓA A', '', 'Chợ Vĩnh long', '', 0),
(18, 'GIA CẦM - CH A', '', 'Vĩnh long', '', 0),
(19, 'HÀNG CẤP ĐÔNG - METRO CẦN THƠ', '', 'Metro Cần Thơ', '', 0),
(20, 'GAS - CTY A', '', 'Vĩnh long', '', 0),
(21, 'BIA - CTY CP DU LỊCH CỬU LONG', '0703 828 042', 'Chưa cập nhật', '', 0),
(22, 'NƯỚC GIẢI KHÁT - NPP ĐOAN TRANG', '', 'Đoan trang', '', 0),
(23, 'RƯỢU - NPP CẦN THƠ', '', '', '', 0),
(24, 'Rượu nội', '', '', '', 0),
(25, 'Vật dụng bếp', '', '', '', 0),
(26, 'Vật dụng tổ bàn', '', '', '', 0),
(27, 'TẠP HÓA 01', '', 'Chợ  Vĩnh long', '', 0),
(28, 'BIA - CTY SAGOTA', 'Chưa cập nhật', 'Chưa cập nhật', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_table`
--

CREATE TABLE IF NOT EXISTS `tbl_table` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iddomain` int(11) NOT NULL,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `iduser` int(11) DEFAULT NULL,
  `type` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `iddomain` (`iddomain`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=49 ;

--
-- Dumping data for table `tbl_table`
--

INSERT INTO `tbl_table` (`id`, `iddomain`, `name`, `iduser`, `type`) VALUES
(1, 1, 'P. 01', 1, '0'),
(2, 1, 'P. 02', 1, '0'),
(14, 2, 'C. 07', 1, '0'),
(15, 2, 'C. 08', 1, '0'),
(16, 2, 'C. 09', 1, '0'),
(26, 3, 'B. 18', 1, '0'),
(27, 3, 'B. 19', 1, '0'),
(28, 3, 'B. 20', 1, '0'),
(29, 3, 'B. 21', 1, '0'),
(30, 3, 'B. 22', 1, '0'),
(31, 3, 'B. 23', 1, '0'),
(32, 3, 'B. 24', 1, '0'),
(33, 3, 'B. 25', 1, '0'),
(34, 4, 'HT. 10', 1, '0'),
(35, 4, 'HT. 11', 1, '0'),
(36, 4, 'HT. 12', 1, '0'),
(37, 4, 'HT. 13', 1, '0'),
(38, 4, 'HT. 14', 1, '0'),
(39, 4, 'HT. 15', 1, '0'),
(40, 4, 'HT. 16', 1, '0'),
(41, 4, 'HT. 17', 1, '0'),
(44, 1, 'P. 03', 1, '0'),
(45, 2, 'C10', 1, '0'),
(46, 5, 'Dịch vụ', 1, '0');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_table_log`
--

CREATE TABLE IF NOT EXISTS `tbl_table_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iduser` int(11) NOT NULL,
  `idtable` int(11) NOT NULL,
  `datetime` datetime NOT NULL,
  `note` varchar(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=525 ;

--
-- Dumping data for table `tbl_table_log`
--

INSERT INTO `tbl_table_log` (`id`, `iduser`, `idtable`, `datetime`, `note`) VALUES
(520, 3, 1, '2014-01-23 22:37:54', 'Tạo mới giao dịch'),
(521, 3, 1, '2014-01-23 22:37:54', 'Cập nhật món Bò Bốp Thấu '),
(522, 3, 1, '2014-01-23 22:37:57', 'Cập nhật món Bò Bốp Thấu 2'),
(523, 3, 1, '2014-01-23 22:37:57', 'Cập nhật món Bò Bốp Thấu 3'),
(524, 1, 1, '2014-01-23 22:45:10', 'tính tiền 27.000');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_term`
--

CREATE TABLE IF NOT EXISTS `tbl_term` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=12 ;

--
-- Dumping data for table `tbl_term`
--

INSERT INTO `tbl_term` (`id`, `name`, `type`) VALUES
(1, 'Tiền Điện', 0),
(2, 'Tiền Nước', 0),
(3, 'Thuế', 0),
(10, 'Tiền Ăn Nhân Viên', 0),
(11, 'CP Khác', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_term_collect`
--

CREATE TABLE IF NOT EXISTS `tbl_term_collect` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Dumping data for table `tbl_term_collect`
--

INSERT INTO `tbl_term_collect` (`id`, `name`) VALUES
(2, 'Phụ Phẩm'),
(3, 'Đặc Biệt'),
(4, 'Ung luong NV');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tracking`
--

CREATE TABLE IF NOT EXISTS `tbl_tracking` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_start` date NOT NULL,
  `date_end` date NOT NULL,
  `paid_general` int(11) NOT NULL,
  `paid_pay_roll` int(11) NOT NULL,
  `paid_import` int(11) NOT NULL,
  `collect_general` int(11) NOT NULL,
  `collect_customer` int(11) NOT NULL,
  `collect_selling_debt` int(11) NOT NULL,
  `collect_selling_nodebt` int(11) NOT NULL,
  `estate_rate` int(11) NOT NULL,
  `store_value` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=15 ;

--
-- Dumping data for table `tbl_tracking`
--

INSERT INTO `tbl_tracking` (`id`, `date_start`, `date_end`, `paid_general`, `paid_pay_roll`, `paid_import`, `collect_general`, `collect_customer`, `collect_selling_debt`, `collect_selling_nodebt`, `estate_rate`, `store_value`) VALUES
(13, '2014-01-01', '2014-01-31', 0, 0, 0, 0, 0, 0, 0, 0, 0),
(14, '2014-02-01', '2014-02-28', 0, 0, 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tracking_course`
--

CREATE TABLE IF NOT EXISTS `tbl_tracking_course` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tracking` int(11) NOT NULL,
  `id_td` int(11) NOT NULL,
  `id_course` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `value` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=631 ;

--
-- Dumping data for table `tbl_tracking_course`
--

INSERT INTO `tbl_tracking_course` (`id`, `id_tracking`, `id_td`, `id_course`, `count`, `price`, `value`) VALUES
(630, 13, 236, 380, 1, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tracking_customer`
--

CREATE TABLE IF NOT EXISTS `tbl_tracking_customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tracking` int(11) NOT NULL,
  `id_customer` int(11) NOT NULL,
  `value_session1` int(11) NOT NULL,
  `value_session2` int(11) NOT NULL,
  `value_collect` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tbl_tracking_customer`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_tracking_daily`
--

CREATE TABLE IF NOT EXISTS `tbl_tracking_daily` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tracking` int(11) NOT NULL,
  `date` date NOT NULL,
  `selling` bigint(20) NOT NULL,
  `import` bigint(20) NOT NULL,
  `store` bigint(20) NOT NULL,
  `paid` bigint(20) NOT NULL,
  `collect` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=245 ;

--
-- Dumping data for table `tbl_tracking_daily`
--

INSERT INTO `tbl_tracking_daily` (`id`, `id_tracking`, `date`, `selling`, `import`, `store`, `paid`, `collect`) VALUES
(214, 13, '2014-01-01', 0, 0, 0, 0, 0),
(215, 13, '2014-01-02', 0, 0, 0, 0, 0),
(216, 13, '2014-01-03', 0, 0, 0, 0, 0),
(217, 13, '2014-01-04', 0, 0, 0, 0, 0),
(218, 13, '2014-01-05', 0, 0, 0, 0, 0),
(219, 13, '2014-01-06', 0, 0, 0, 0, 0),
(220, 13, '2014-01-07', 0, 0, 0, 0, 0),
(221, 13, '2014-01-08', 0, 0, 0, 0, 0),
(222, 13, '2014-01-09', 0, 0, 0, 0, 0),
(223, 13, '2014-01-10', 0, 0, 0, 0, 0),
(224, 13, '2014-01-11', 0, 0, 0, 0, 0),
(225, 13, '2014-01-12', 0, 0, 0, 0, 0),
(226, 13, '2014-01-13', 0, 0, 0, 0, 0),
(227, 13, '2014-01-14', 0, 0, 0, 0, 0),
(228, 13, '2014-01-15', 0, 0, 0, 0, 0),
(229, 13, '2014-01-16', 0, 0, 0, 0, 0),
(230, 13, '2014-01-17', 0, 0, 0, 0, 0),
(231, 13, '2014-01-18', 0, 0, 0, 0, 0),
(232, 13, '2014-01-19', 0, 0, 0, 0, 0),
(233, 13, '2014-01-20', 0, 0, 0, 0, 0),
(234, 13, '2014-01-21', 0, 0, 0, 0, 0),
(235, 13, '2014-01-22', 0, 0, 0, 0, 0),
(236, 13, '2014-01-23', 27000, 0, 0, 0, 0),
(237, 13, '2014-01-24', 0, 0, 0, 0, 0),
(238, 13, '2014-01-25', 0, 0, 0, 0, 0),
(239, 13, '2014-01-26', 0, 0, 0, 0, 0),
(240, 13, '2014-01-27', 0, 0, 0, 0, 0),
(241, 13, '2014-01-28', 0, 0, 0, 0, 0),
(242, 13, '2014-01-29', 0, 0, 0, 0, 0),
(243, 13, '2014-01-30', 0, 0, 0, 0, 0),
(244, 13, '2014-01-31', 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tracking_store`
--

CREATE TABLE IF NOT EXISTS `tbl_tracking_store` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tracking` int(11) NOT NULL,
  `id_td` int(11) NOT NULL,
  `id_resource` int(11) NOT NULL,
  `count_old` float NOT NULL,
  `count_import` float NOT NULL,
  `count_export` float NOT NULL,
  `price` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1861 ;

--
-- Dumping data for table `tbl_tracking_store`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_unit`
--

CREATE TABLE IF NOT EXISTS `tbl_unit` (
  `id` int(25) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=30 ;

--
-- Dumping data for table `tbl_unit`
--

INSERT INTO `tbl_unit` (`id`, `name`) VALUES
(1, 'Ly'),
(2, 'Điếu'),
(3, 'Chai'),
(4, 'Lon'),
(5, 'Dĩa'),
(6, 'Thùng'),
(7, 'Két'),
(9, 'Bịch'),
(10, 'Gói'),
(20, 'Trái'),
(21, 'Cái'),
(22, 'Hủ'),
(23, 'Kg'),
(24, 'Con'),
(25, 'Bao'),
(26, 'Cây'),
(27, 'Hộp'),
(28, 'Miếng'),
(29, 'Bó');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE IF NOT EXISTS `tbl_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pass` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gender` int(11) NOT NULL,
  `note` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `datecreate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dateupdate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `dateactivity` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `type` tinyint(4) NOT NULL,
  `code` varchar(13) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `name`, `email`, `pass`, `gender`, `note`, `datecreate`, `dateupdate`, `dateactivity`, `type`, `code`) VALUES
(1, 'Tuấn', 'tuanbuithanh@gmail.com', 'admin068368', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 4, ''),
(3, 'Thái', 'thai@gmail.com', '123456', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 4, '');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_collect_customer`
--
ALTER TABLE `tbl_collect_customer`
  ADD CONSTRAINT `tbl_customer_collect_1` FOREIGN KEY (`idcustomer`) REFERENCES `tbl_customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_collect_general`
--
ALTER TABLE `tbl_collect_general`
  ADD CONSTRAINT `tbl_collect_general_1` FOREIGN KEY (`id_term`) REFERENCES `tbl_term_collect` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_course`
--
ALTER TABLE `tbl_course`
  ADD CONSTRAINT `tbl_course_1` FOREIGN KEY (`idcategory`) REFERENCES `tbl_category` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_order_import`
--
ALTER TABLE `tbl_order_import`
  ADD CONSTRAINT `tbl_order_import_1` FOREIGN KEY (`idsupplier`) REFERENCES `tbl_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_order_import_detail`
--
ALTER TABLE `tbl_order_import_detail`
  ADD CONSTRAINT `tbl_order_import_detail_1` FOREIGN KEY (`idorder`) REFERENCES `tbl_order_import` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_order_import_detail_2` FOREIGN KEY (`idresource`) REFERENCES `tbl_resource` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_paid_customer`
--
ALTER TABLE `tbl_paid_customer`
  ADD CONSTRAINT `tbl_customer_paid_1` FOREIGN KEY (`idcustomer`) REFERENCES `tbl_customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_paid_employee`
--
ALTER TABLE `tbl_paid_employee`
  ADD CONSTRAINT `tbl_paid_employee_ibfk_1` FOREIGN KEY (`id_employee`) REFERENCES `tbl_employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_paid_general`
--
ALTER TABLE `tbl_paid_general`
  ADD CONSTRAINT `tbl_paid_general_1` FOREIGN KEY (`id_term`) REFERENCES `tbl_term` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_paid_pay_roll`
--
ALTER TABLE `tbl_paid_pay_roll`
  ADD CONSTRAINT `tbl_paid_pay_roll_ibfk_1` FOREIGN KEY (`id_employee`) REFERENCES `tbl_employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_paid_supplier`
--
ALTER TABLE `tbl_paid_supplier`
  ADD CONSTRAINT `tbl_supplier_paid_1` FOREIGN KEY (`idsupplier`) REFERENCES `tbl_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_pay_roll`
--
ALTER TABLE `tbl_pay_roll`
  ADD CONSTRAINT `tbl_pay_roll_ibfk_1` FOREIGN KEY (`id_employee`) REFERENCES `tbl_employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_r2c`
--
ALTER TABLE `tbl_r2c`
  ADD CONSTRAINT `tbl_r2c_1` FOREIGN KEY (`id_course`) REFERENCES `tbl_course` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_r2c_2` FOREIGN KEY (`id_resource`) REFERENCES `tbl_resource` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_resource`
--
ALTER TABLE `tbl_resource`
  ADD CONSTRAINT `tbl_resource_1` FOREIGN KEY (`idsupplier`) REFERENCES `tbl_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_session`
--
ALTER TABLE `tbl_session`
  ADD CONSTRAINT `tbl_session_1` FOREIGN KEY (`idtable`) REFERENCES `tbl_table` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_session_2` FOREIGN KEY (`iduser`) REFERENCES `tbl_user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_session_3` FOREIGN KEY (`idcustomer`) REFERENCES `tbl_customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_session_detail`
--
ALTER TABLE `tbl_session_detail`
  ADD CONSTRAINT `tbl_session_detail_1` FOREIGN KEY (`idsession`) REFERENCES `tbl_session` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_session_detail_2` FOREIGN KEY (`idcourse`) REFERENCES `tbl_course` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_table`
--
ALTER TABLE `tbl_table`
  ADD CONSTRAINT `tbl_table_1` FOREIGN KEY (`iddomain`) REFERENCES `tbl_domain` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
