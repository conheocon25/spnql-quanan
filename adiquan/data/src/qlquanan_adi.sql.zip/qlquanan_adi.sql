-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 21, 2014 at 09:35 AM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `qlquanan_adi`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_app`
--

CREATE TABLE IF NOT EXISTS `tbl_app` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(125) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(50) CHARACTER SET utf8 NOT NULL,
  `banner` varchar(125) CHARACTER SET utf8 NOT NULL,
  `prefix` varchar(50) CHARACTER SET utf8 NOT NULL,
  `alias` varchar(256) CHARACTER SET utf8 NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_activity` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `type` tinyint(4) NOT NULL,
  `page_view` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_app`
--

INSERT INTO `tbl_app` (`id`, `name`, `phone`, `address`, `email`, `banner`, `prefix`, `alias`, `date_created`, `date_modified`, `date_activity`, `type`, `page_view`) VALUES
(1, 'Adi quán', '0919 153 189', 'Long Xuyên An Giang', '', '', 'tbl_', 'tbl_', '2012-06-30 17:00:00', '0000-00-00 00:00:00', '2012-12-26 07:28:02', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

CREATE TABLE IF NOT EXISTS `tbl_category` (
  `id` int(25) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `picture` binary(255) DEFAULT NULL,
  `enable` int(11) NOT NULL,
  `order` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=50 ;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`id`, `name`, `picture`, `enable`, `order`) VALUES
(11, 'BIA', NULL, 1, 5),
(37, 'RUOU', NULL, 1, 5),
(38, 'CÁNH, CHÂN GÀ, ẾCH,DẾ', NULL, 1, 3),
(40, 'GÀ TA', NULL, 1, 2),
(41, 'ĐẶC BIỆT', NULL, 1, 1),
(42, 'CHÁO, MÌ, CƠM, LẨU,SÚP', NULL, 1, 2),
(43, 'CUA GẠCH, GHẸ', NULL, 1, 3),
(44, 'NGHÊU, SÒ, HÀU', NULL, 1, 3),
(45, 'ca bap', NULL, 1, 3),
(46, 'BÒ, TÔM,  MỰC,HEO', NULL, 1, 2),
(47, 'HẢI SẢN.ca chep gion.ca nheo.ca hong ', NULL, 1, 3),
(48, 'KHĂN, ĐẬU', NULL, 1, 4),
(49, 'GỌI THÊM', NULL, 1, 4);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_collect_customer`
--

CREATE TABLE IF NOT EXISTS `tbl_collect_customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idcustomer` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_customer_collect_1` (`idcustomer`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_collect_customer`
--

INSERT INTO `tbl_collect_customer` (`id`, `idcustomer`, `date`, `value`, `note`) VALUES
(1, 24, '2014-02-28', 18000, '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_collect_general`
--

CREATE TABLE IF NOT EXISTS `tbl_collect_general` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_term` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_collect_1` (`id_term`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

--
-- Dumping data for table `tbl_collect_general`
--

INSERT INTO `tbl_collect_general` (`id`, `id_term`, `date`, `value`, `note`) VALUES
(6, 3, '2013-12-04', 10000000, 'Bổ sung tiền quỹ');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_config`
--

CREATE TABLE IF NOT EXISTS `tbl_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `param` varchar(125) COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=16 ;

--
-- Dumping data for table `tbl_config`
--

INSERT INTO `tbl_config` (`id`, `param`, `value`) VALUES
(5, 'DISCOUNT', '0'),
(6, 'ROW_PER_PAGE', '12'),
(7, 'GUEST_VISIT', '9247'),
(8, 'EVERY_5_MINUTES', '2000'),
(9, 'CATEGORY_AUTO', '11'),
(10, 'NAME', 'ADI QUÁN'),
(11, 'ADDRESS', 'TP Long Xuyên An Giang'),
(12, 'PHONE', '0919 153 189'),
(13, 'SWITCH_BOARD_CALL', '1'),
(14, 'RECEIPT_VIRTUAL_DOUBLE', '1'),
(15, 'N_MONTH_LOG', '1');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_course`
--

CREATE TABLE IF NOT EXISTS `tbl_course` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idcategory` int(25) DEFAULT NULL,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `shortname` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `unit` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `price1` bigint(20) NOT NULL,
  `price2` bigint(20) NOT NULL,
  `price3` bigint(20) NOT NULL,
  `price4` bigint(20) NOT NULL,
  `picture` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `prepare` int(11) NOT NULL,
  `is_discount` int(11) NOT NULL,
  `enable` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `foreign_field` (`idcategory`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=794 ;

--
-- Dumping data for table `tbl_course`
--

INSERT INTO `tbl_course` (`id`, `idcategory`, `name`, `shortname`, `unit`, `price1`, `price2`, `price3`, `price4`, `picture`, `prepare`, `is_discount`, `enable`) VALUES
(115, 11, 'SG chai xanh', 'SG chai xanh', 'Chai', 12000, 12000, 12000, 12000, '', 0, 0, 1),
(116, 11, 'SG do', 'SG do', 'Chai', 9000, 9000, 9000, 9000, '', 0, 0, 1),
(188, 11, 'Heneiken chai', 'Ken chai', 'Chai', 16000, 16000, 16000, 16000, '', 0, 0, 1),
(189, 11, 'Heneiken lon', 'Ken lon', 'Lon', 19000, 19000, 19000, 19000, '', 0, 0, 1),
(190, 11, 'Tiger nau', 'Tiger nau', 'Chai', 12000, 12000, 12000, 12000, '', 0, 0, 1),
(191, 11, 'Tiger bac', 'Tiger bac', 'Chai', 14000, 14000, 14000, 14000, '', 0, 0, 1),
(405, 11, '333 lon', '333 lon', 'Lon', 11000, 11000, 11000, 11000, '', 0, 0, 1),
(411, 11, '333 chai', '333 chai', 'Chai', 10000, 10000, 10000, 10000, '', 0, 0, 1),
(489, 11, 'SG lon xanh', 'SG lon xanh', 'Lon', 13000, 13000, 13000, 13000, '', 0, 0, 1),
(490, 11, 'Nuoc ngot', 'Nuoc ngot', 'Chai', 12000, 12000, 12000, 12000, '', 0, 0, 1),
(491, 11, 'Nuoc suoi', 'Nuoc suoi', 'Chai', 8000, 8000, 8000, 8000, '', 0, 0, 1),
(492, 37, 'Phu Le', 'Phu Le', 'Chai', 75000, 75000, 75000, 75000, '', 0, 0, 1),
(493, 37, 'Volka lon', 'Volka lon', 'Chai', 105000, 105000, 105000, 105000, '', 0, 0, 1),
(494, 37, 'Volka nho', 'Volka nho', 'Chai', 65000, 65000, 65000, 65000, '', 0, 0, 1),
(495, 38, 'Canh ga nuong muoi ot', 'Canh ga nuong muoi ot', 'Dĩa', 55000, 55000, 55000, 55000, '', 0, 1, 1),
(496, 38, 'Canh ga chien nuoc mam', 'Canh ga chien nuoc mam', 'Dĩa', 55000, 55000, 55000, 55000, '', 0, 1, 1),
(497, 38, 'Canh ga nuong ngu vi', 'Canh ga nuong ngu vi', 'Dĩa', 55000, 55000, 55000, 55000, '', 0, 1, 1),
(498, 38, 'Canh ga nuong chao', 'Canh ga nuong chao', 'Chai', 55000, 55000, 55000, 55000, '', 0, 1, 1),
(503, 40, 'Ga ta nuong muoi ot', 'Ga ta nuong muoi ot', 'Con', 250000, 250000, 250000, 250000, '', 0, 1, 1),
(504, 40, 'Ga ta hap hanh', 'Ga ta hap hanh', 'Con', 250000, 250000, 250000, 250000, '', 0, 1, 1),
(505, 40, 'Ga ta nuong ngu vi', 'Ga ta nuong ngu vi', 'Con', 250000, 250000, 250000, 250000, '', 0, 1, 1),
(506, 40, 'Ga ta nuong chao', 'Ga ta nuong chao', 'Con', 250000, 250000, 250000, 250000, '', 0, 1, 1),
(507, 40, 'Gà ta nướng chao', 'Gà ta nướng chao', 'Con', 250000, 250000, 250000, 250000, '', 0, 1, 1),
(508, 40, 'Ga ta quay lu', 'Ga ta quay lu', 'Con', 250000, 250000, 250000, 250000, '', 0, 1, 1),
(509, 40, 'Ga ta nau la giang', 'Ga ta nau la giang', 'Con', 250000, 250000, 250000, 250000, '', 0, 1, 1),
(510, 41, 'Heo sua quay phan', 'Heo sua quay phan', 'Phần', 150000, 150000, 150000, 150000, '', 0, 1, 1),
(511, 41, 'Heo sua quay con', 'Heo sua quay con', 'Con', 650000, 650000, 650000, 650000, '', 0, 1, 1),
(512, 42, 'Chao ngheu', 'Chao ngheu', 'Thố', 45000, 45000, 45000, 45000, '', 0, 1, 1),
(513, 42, 'Chao bo bam', 'Chao bo bam', 'Thố', 60000, 60000, 60000, 60000, '', 0, 1, 1),
(514, 42, 'Chao hao', 'Chao hao', 'Thố', 60000, 60000, 60000, 60000, '', 0, 1, 1),
(515, 42, 'Chao hai san', 'Chao hai san', 'Thố', 60000, 60000, 60000, 60000, '', 0, 1, 1),
(516, 42, 'Chao muc', 'Chao muc', 'Thố', 60000, 60000, 60000, 60000, '', 0, 1, 1),
(517, 42, 'Chao tom', 'Chao tom', 'Thố', 60000, 60000, 60000, 60000, '', 0, 1, 1),
(518, 42, 'Chao so huyet', 'Chao so huyet', 'Thố', 60000, 60000, 60000, 60000, '', 0, 1, 1),
(519, 43, 'Cua thit', 'Cua thit', 'Kg', 270000, 270000, 270000, 270000, '', 0, 1, 1),
(520, 43, 'Ghe', 'Ghe', 'Kg', 290000, 290000, 290000, 290000, '', 0, 1, 1),
(522, 44, 'Ngheu hap sa', 'Ngheu hap sa', 'Phần', 40000, 40000, 40000, 40000, '', 0, 1, 1),
(523, 44, 'Ngheu hap thai', 'Ngheu hap thai', 'Phần', 40000, 40000, 40000, 40000, '', 0, 1, 1),
(524, 44, 'Ngheu xao la hue', 'Ngheu xao la hue', 'Phần', 40000, 40000, 40000, 40000, '', 0, 1, 1),
(525, 44, 'So long hap xa', 'So long hap xa', 'Phần', 45000, 45000, 45000, 45000, '', 0, 1, 1),
(526, 44, 'So long nuong mo hanh', 'So long nuong mo hanh', 'Phần', 45000, 45000, 45000, 45000, '', 0, 1, 1),
(527, 44, 'Hau nuong pho mai', 'Hau nuong pho mai', 'Con', 12000, 12000, 12000, 12000, '', 0, 1, 1),
(528, 44, 'Hau nuong mo hanh', 'Hau nuong mo hanh', 'Con', 12000, 12000, 12000, 12000, '', 0, 1, 1),
(529, 44, 'Hau tai chanh', 'Hau tai chanh', 'Con', 12000, 12000, 12000, 12000, '', 0, 1, 1),
(530, 44, 'So huyet luoc / nuong', 'So huyet luoc / nuong', 'Dĩa', 45000, 45000, 45000, 45000, '', 0, 1, 1),
(531, 44, 'So huyet rang muoi / rang me', 'So huyet rang muoi / rang me', 'Dĩa', 45000, 45000, 45000, 45000, '', 0, 1, 1),
(532, 44, 'So huyet rang muoi / rang me', 'So huyet rang muoi / rang me', 'Dĩa', 45000, 45000, 45000, 45000, '', 0, 1, 1),
(533, 44, 'So diep nuong mo hanh', 'So diep nuong mo hanh', 'Dĩa', 40000, 40000, 40000, 40000, '', 0, 1, 1),
(534, 44, 'So diep nuong pho mai', 'So diep nuong pho mai', 'Dĩa', 40000, 40000, 40000, 40000, '', 0, 1, 1),
(535, 44, 'So veo hap xa', 'So veo hap xa', 'Dĩa', 45000, 45000, 45000, 45000, '', 0, 1, 1),
(536, 44, 'So veo nuong mo hanh', 'So veo nuong mo hanh', 'Dĩa', 45000, 45000, 45000, 45000, '', 0, 1, 1),
(537, 44, 'Oc mo xao toi', 'Oc mo xao toi', 'Dĩa', 60000, 60000, 60000, 60000, '', 0, 1, 1),
(538, 44, 'Oc mo xao hanh', 'Oc mo xao hanh', 'Dĩa', 60000, 60000, 60000, 60000, '', 0, 1, 1),
(539, 44, 'Oc mo xao me ', 'Oc mo xao me ', 'Dĩa', 60000, 60000, 60000, 60000, '', 0, 1, 1),
(540, 44, 'Oc buou nuong tieu', 'Oc buou nuong tieu', 'Dĩa', 40000, 40000, 40000, 40000, '', 0, 1, 1),
(541, 44, 'Oc buou hap xa', 'Oc buou hap xa', 'Dĩa', 40000, 40000, 40000, 40000, '', 0, 1, 1),
(542, 42, 'Mi xao hai san', 'Mi xao hai san', 'Dĩa', 60000, 60000, 60000, 60000, '', 0, 1, 1),
(543, 42, 'Mi xao thap cam', 'Mi xao thap cam', 'Dĩa', 60000, 60000, 60000, 60000, '', 0, 1, 1),
(544, 42, 'Mi xao bo', 'Mi xao bo', 'Dĩa', 60000, 60000, 60000, 60000, '', 0, 1, 1),
(545, 42, 'Muc xao sa te', 'Muc xao sa te', 'Dĩa', 60000, 60000, 60000, 60000, '', 0, 1, 1),
(546, 42, 'Muc xao chua ngot', 'Muc xao chua ngot', 'Dĩa', 60000, 60000, 60000, 60000, '', 0, 1, 1),
(547, 42, 'Bun xao Singapore', 'Bun xao Singapore', 'Dĩa', 65000, 65000, 65000, 65000, '', 0, 1, 1),
(548, 42, 'Com chien Lang Bien', 'Com chien Lang Bien', 'Dĩa', 60000, 60000, 60000, 60000, '', 0, 1, 1),
(549, 42, 'Com chien Tu Quy', 'Com chien Tu Quy', 'Dĩa', 60000, 60000, 60000, 60000, '', 0, 1, 1),
(550, 42, 'Com chien toi', 'Com chien toi', 'Dĩa', 35000, 35000, 35000, 35000, '', 0, 1, 1),
(551, 42, 'Com chien Thuong Hai', 'Com chien Thuong Hai', 'Dĩa', 60000, 60000, 60000, 60000, '', 0, 1, 1),
(552, 42, 'Com chien trung', 'Com chien trung', 'Dĩa', 45000, 45000, 45000, 45000, '', 0, 1, 1),
(553, 42, 'Com chien la xanh', 'Com chien la xanh', 'Dĩa', 60000, 60000, 60000, 60000, '', 0, 1, 1),
(554, 42, 'Com chien hai san', 'Com chien hai san', 'Dĩa', 60000, 60000, 60000, 60000, '', 0, 1, 1),
(555, 42, 'Com chien Duong Chau', 'Com chien Duong Chau', 'Dĩa', 60000, 60000, 60000, 60000, '', 0, 1, 1),
(557, 42, 'Lau xi quach', 'Lau xi quach', 'Cái', 105000, 105000, 105000, 105000, '', 0, 1, 1),
(558, 42, 'Lau dau hai san', 'Lau dau hai san', 'Cái', 105000, 105000, 105000, 105000, '', 0, 1, 1),
(559, 42, 'Lau hai san', 'Lau hai san', 'Cái', 105000, 105000, 105000, 105000, '', 0, 1, 1),
(560, 42, 'Lau ca mang chua', 'Lau ca mang chua', 'Cái', 120000, 120000, 120000, 120000, '', 0, 1, 1),
(561, 42, 'Lau Thai hai san', 'Lau Thai hai san', 'Cái', 105000, 105000, 105000, 105000, '', 0, 1, 1),
(562, 42, 'Lau dau ca Hoi', 'Lau dau ca Hoi', 'Cái', 98000, 98000, 98000, 98000, '', 0, 1, 1),
(563, 42, 'Lau ca Bop', 'Lau ca Bop', 'Cái', 120000, 120000, 120000, 120000, '', 0, 1, 1),
(564, 42, 'Lau muc', 'Lau muc', 'Cái', 120000, 120000, 120000, 120000, '', 0, 1, 1),
(565, 42, 'Lau tom', 'Lau tom', 'Cái', 120000, 120000, 120000, 120000, '', 0, 1, 1),
(566, 42, 'Lau cua gach, lau ghe', 'Lau cua gach, lau ghe', 'Cái', 0, 0, 0, 0, '', 0, 1, 1),
(567, 38, 'Chan ga nuong muoi ot', 'Chan ga nuong muoi ot', 'Dĩa', 55000, 55000, 55000, 55000, '', 0, 1, 1),
(568, 38, 'Chan ga hap hanh', 'Chan ga hap hanh', 'Dĩa', 55000, 55000, 55000, 55000, '', 0, 1, 1),
(569, 38, 'Chan ga nuong ngu vi', 'Chan ga nuong ngu vi', 'Dĩa', 55000, 55000, 55000, 55000, '', 0, 1, 1),
(570, 38, 'Chan ga nuong chao', 'Chan ga nuong chao', 'Dĩa', 55000, 55000, 55000, 55000, '', 0, 1, 1),
(571, 45, 'Goi cu hu dua tom thit', 'Goi cu hu dua tom thit', 'Dĩa', 55000, 55000, 55000, 55000, '', 0, 1, 1),
(572, 45, 'Goi rau muong dong tom thit', 'Goi rau muong dong tom thit', 'Dĩa', 55000, 55000, 55000, 55000, '', 0, 1, 1),
(573, 45, 'Goi rau muong dong hai san', 'Goi rau muong dong hai san', 'Dĩa', 55000, 55000, 55000, 55000, '', 0, 1, 1),
(574, 45, 'Goi xoai kho ca loc', 'Goi xoai kho ca loc', 'Dĩa', 65000, 65000, 65000, 65000, '', 0, 1, 1),
(575, 45, 'Goi dien dien hai san', 'Goi dien dien hai san', 'Dĩa', 0, 0, 0, 0, '', 0, 1, 1),
(576, 45, 'Goi bo ba khia Lang Bien', 'Goi bo ba khia Lang Bien', 'Dĩa', 70000, 70000, 70000, 70000, '', 0, 1, 1),
(577, 45, 'Goi muc tom Thai', 'Goi muc tom Thai', 'Dĩa', 55000, 55000, 55000, 55000, '', 0, 1, 1),
(578, 45, 'Goi rau nhut hai san', 'Goi rau nhut hai san', 'Dĩa', 55000, 55000, 55000, 55000, '', 0, 1, 1),
(579, 41, 'Mat ca ngu dai duong hap', 'Mat ca ngu dai duong hap', 'Phần', 60000, 60000, 60000, 60000, '', 0, 1, 1),
(580, 41, 'Mat ca ngu dai duong lau', 'Mat ca ngu dai duong lau', 'Cái', 120000, 120000, 120000, 120000, '', 0, 1, 1),
(581, 41, 'Ca lang cha ca La Vong', 'Ca lang cha ca La Vong', 'Kg', 190000, 190000, 190000, 190000, '', 0, 1, 1),
(582, 41, 'Ca lang lau chua', 'Ca lang lau chua', 'Kg', 190000, 190000, 190000, 190000, '', 0, 1, 1),
(583, 41, 'Dau hu Lang Bien', 'Dau hu Lang Bien', 'Dĩa', 70000, 70000, 70000, 70000, '', 0, 1, 1),
(584, 41, 'Sua tuoi chien gion', 'Sua tuoi chien gion', 'Dĩa', 50000, 50000, 50000, 50000, '', 0, 1, 1),
(585, 41, 'Cha gio Lang Bien', 'Cha gio Lang Bien', 'Dĩa', 60000, 60000, 60000, 60000, '', 0, 1, 1),
(586, 41, 'Bo nuong Lang Bien', 'Bo nuong Lang Bien', 'Dĩa', 70000, 70000, 70000, 70000, '', 0, 1, 1),
(587, 41, 'Com chien Lang Bien', 'Com chien Lang Bien', 'Dĩa', 60000, 60000, 60000, 60000, '', 0, 1, 1),
(588, 41, 'Bun xao Lang Bien', 'Bun xao Lang Bien', 'Dĩa', 65000, 65000, 65000, 65000, '', 0, 1, 1),
(589, 41, 'Com chay nuong Lang Bien', 'Com chay nuong Lang Bien', 'Dĩa', 60000, 60000, 60000, 60000, '', 0, 1, 1),
(590, 41, 'Lau ca mang chua', 'Lau ca mang chua', 'Dĩa', 120000, 120000, 120000, 120000, '', 0, 1, 1),
(591, 45, 'Rau muong/nhut xao hai san', 'Rau muong/nhut xao hai san', 'Dĩa', 55000, 55000, 55000, 55000, '', 0, 1, 1),
(592, 45, 'Rau muong xao toi', 'Rau muong xao toi', 'Dĩa', 35000, 35000, 35000, 35000, '', 0, 1, 1),
(593, 45, 'Rau muong xao bo', 'Rau muong xao bo', 'Dĩa', 60000, 60000, 60000, 60000, '', 0, 1, 1),
(594, 46, 'Bo luc lac', 'Bo luc lac', 'Dĩa', 65000, 65000, 65000, 65000, '', 0, 1, 1),
(595, 46, 'Bo bit tet', 'Bo bit tet', 'Dĩa', 65000, 65000, 65000, 65000, '', 0, 1, 1),
(596, 46, 'Bo nuong lui', 'Bo nuong lui', 'Dĩa', 65000, 65000, 65000, 65000, '', 0, 1, 1),
(597, 46, 'Bo napoleon', 'Bo napoleon', 'Dĩa', 65000, 65000, 65000, 65000, '', 0, 1, 1),
(598, 46, 'Tom nuong muoi ot', 'Tom nuong muoi ot', 'Dĩa', 65000, 65000, 65000, 65000, '', 0, 1, 1),
(599, 46, 'Tom nuong sa te', 'Tom nuong sa te', 'Dĩa', 65000, 65000, 65000, 65000, '', 0, 1, 1),
(600, 46, 'Tom nuong moi', 'Tom nuong moi', 'Dĩa', 65000, 65000, 65000, 65000, '', 0, 1, 1),
(601, 46, 'Muc ong', 'Muc ong', 'Phần', 70000, 70000, 70000, 70000, '', 0, 1, 1),
(602, 46, 'Muc ong kg', 'Muc ong kg', 'Kg', 280000, 280000, 280000, 280000, '', 0, 1, 1),
(603, 46, 'Muc la', 'Muc la', 'Phần', 75000, 75000, 75000, 75000, '', 0, 1, 1),
(604, 46, 'Muc la kg', 'Muc la kg', 'Kg', 300000, 300000, 300000, 300000, '', 0, 1, 1),
(605, 46, 'Bach tuoc', 'Bach tuoc', 'Phần', 70000, 70000, 70000, 70000, '', 0, 1, 1),
(606, 46, 'Bach tuoc kg', 'Bach tuoc kg', 'Kg', 200000, 200000, 200000, 200000, '', 0, 1, 1),
(607, 46, 'Muc trung Phu Quoc', 'Muc trung Phu Quoc', 'Phần', 80000, 80000, 80000, 80000, '', 0, 1, 1),
(608, 46, 'Muc trung Phu Quoc kg', 'Muc trung Phu Quoc kg', 'Kg', 320000, 320000, 320000, 320000, '', 0, 1, 1),
(609, 46, 'Muc chien gion', 'Muc chien gion', 'Dĩa', 58000, 58000, 58000, 58000, '', 0, 1, 1),
(610, 46, 'Muc hap gung', 'Muc hap gung', 'Dĩa', 58000, 58000, 58000, 58000, '', 0, 1, 1),
(611, 46, 'Muc chien nuoc mam', 'Muc chien nuoc mam', 'Dĩa', 58000, 58000, 58000, 58000, '', 0, 1, 1),
(612, 45, 'Khoai tay chien', 'Khoai tay chien', 'Dĩa', 30000, 30000, 30000, 30000, '', 0, 1, 1),
(613, 45, 'dau hu chien xa ot', 'dau hu chien xa ot', 'Dĩa', 30000, 30000, 30000, 30000, '', 0, 1, 1),
(614, 45, 'Dau hu chien gion', 'Dau hu chien gion', 'Dĩa', 30000, 30000, 30000, 30000, '', 0, 1, 1),
(615, 41, 'Cha ca thac lac Lang Bien', 'Cha ca thac lac Lang Bien', 'Dĩa', 65000, 65000, 65000, 65000, '', 0, 1, 1),
(616, 47, 'Ca sapa con', 'Ca sapa con', 'Con', 58000, 58000, 58000, 58000, '', 0, 1, 1),
(617, 47, 'Ca xuong xanh', 'Ca xuong xanh', 'Phần', 55000, 55000, 55000, 55000, '', 0, 1, 1),
(618, 47, 'Ca xuong xanh kg', 'Ca xuong xanh kg', 'Kg', 170000, 170000, 170000, 170000, '', 0, 1, 1),
(619, 47, 'ca song con', 'ca song con', 'Con', 50000, 50000, 50000, 50000, '', 0, 1, 1),
(620, 47, 'Ca cam con', 'Ca cam con', 'Con', 70000, 70000, 70000, 70000, '', 0, 1, 1),
(621, 47, 'Ca duoi', 'Ca duoi', 'Phần', 55000, 55000, 55000, 55000, '', 0, 1, 1),
(622, 47, 'Ca duoi kg', 'Ca duoi kg', 'Kg', 160000, 160000, 160000, 160000, '', 0, 1, 1),
(623, 47, 'Ca thu Nhat', 'Ca thu Nhat', 'Phần', 55000, 55000, 55000, 55000, '', 0, 1, 1),
(624, 47, 'Ca nhong', 'Ca nhong', 'Phần', 70000, 70000, 70000, 70000, '', 0, 1, 1),
(625, 47, 'Ca bop', 'Ca bop', 'Phần', 60000, 60000, 60000, 60000, '', 0, 1, 1),
(626, 47, 'Ca bop kg', 'Ca bop kg', 'Kg', 290000, 290000, 290000, 290000, '', 0, 1, 1),
(627, 47, 'Dau ca hoi', 'Dau ca hoi', 'Phần', 55000, 55000, 55000, 55000, '', 0, 1, 1),
(628, 47, 'Ca mat kien', 'Ca mat kien', 'Phần', 70000, 70000, 70000, 70000, '', 0, 1, 1),
(629, 47, 'Ca ria', 'Ca ria', 'Con', 50000, 50000, 50000, 50000, '', 0, 1, 1),
(630, 47, 'Ca nau', 'Ca nau', 'Kg', 220000, 220000, 220000, 220000, '', 0, 1, 1),
(631, 47, 'Ca bo da', 'Ca bo da', 'Kg', 220000, 220000, 220000, 220000, '', 0, 1, 1),
(632, 47, 'Ca bo vay', 'Ca bo vay', 'Kg', 140000, 140000, 140000, 140000, '', 0, 1, 1),
(633, 47, 'ca gion', 'ca gion', 'Phần', 60000, 60000, 60000, 60000, '', 0, 1, 1),
(634, 47, 'ca gion kg', 'ca gion kg', 'Kg', 290000, 290000, 290000, 290000, '', 0, 1, 1),
(635, 47, 'ca ngu dai duong kg', 'ca ngu dai duong kg', 'Kg', 250000, 250000, 250000, 250000, '', 0, 1, 1),
(636, 48, 'Khan', 'Khan', 'Cái', 2000, 2000, 2000, 2000, '', 0, 1, 1),
(637, 48, 'Dau', 'Dau', 'Bao', 10000, 10000, 10000, 10000, '', 0, 1, 1),
(638, 49, 'Bo tat chai', 'Bo tat chai', 'Chai', 35000, 35000, 35000, 35000, '', 0, 1, 1),
(639, 49, 'Bo tat chen', 'Bo tat chen', 'Chai', 10000, 10000, 10000, 10000, '', 0, 1, 1),
(640, 49, 'Banh mi', 'Banh mi', 'Cái', 4000, 4000, 4000, 4000, '', 0, 1, 1),
(641, 49, 'Bun them', 'Bun them', 'Dĩa', 10000, 10000, 10000, 10000, '', 0, 1, 1),
(642, 49, 'Rau them', 'Rau them', 'Dĩa', 10000, 10000, 10000, 10000, '', 0, 1, 1),
(643, 49, 'Muc them', 'Muc them', 'Dĩa', 50000, 50000, 50000, 50000, '', 0, 1, 1),
(644, 45, 'Rau luoc thap cam, kho quet', 'Rau luoc thap cam, kho quet', 'Dĩa', 50000, 50000, 50000, 50000, '', 0, 1, 1),
(645, 49, 'Thuoc Hero', 'Thuoc Hero', 'Bao', 18000, 18000, 18000, 18000, '', 0, 1, 1),
(646, 49, 'Thuoc JET', 'Thuoc JET', 'Bao', 20000, 20000, 20000, 20000, '', 0, 1, 1),
(647, 49, 'Thuoc meo', 'Thuoc meo', 'Bao', 25000, 25000, 25000, 25000, '', 0, 1, 1),
(648, 49, 'Thuoc 555', 'Thuoc 555', 'Bao', 30000, 30000, 30000, 30000, '', 0, 1, 1),
(649, 47, 'ca chach hue', 'ca chach hue', 'Kg', 290000, 290000, 290000, 290000, '', 0, 1, 1),
(650, 47, 'ca chach hue nuong', 'ca chach hue nuong', 'Phần', 70000, 70000, 70000, 70000, '', 0, 1, 1),
(651, 47, 'ca chach hue', 'ca chach hue', 'Kg', 290000, 290000, 290000, 290000, '', 0, 1, 1),
(652, 45, 'sa lach tron', 'sa lach tron', 'Dĩa', 30000, 30000, 30000, 30000, '', 0, 1, 1),
(653, 45, 'sa lach tron', 'sa lach tron', 'Dĩa', 30000, 30000, 30000, 30000, '', 0, 1, 1),
(654, 49, 'Trung chien', 'Trung chien', 'Dĩa', 35000, 35000, 35000, 35000, '', 0, 1, 1),
(655, 47, 'ca bong tuong', 'ca bong tuong', 'Kg', 360000, 360000, 360000, 360000, '', 0, 1, 1),
(656, 38, 'Ech nuong ', 'Ech nuong ', 'Dĩa', 60000, 60000, 60000, 60000, '', 0, 1, 1),
(657, 38, 'Ech nau lau', 'Ech nau lau', 'Cái', 120000, 120000, 120000, 120000, '', 0, 1, 1),
(658, 47, 'ca chep gion', 'ca chep gion', 'Kg', 360000, 360000, 360000, 360000, '', 0, 1, 1),
(659, 47, 'ca nheo', 'ca nheo', 'Kg', 170000, 170000, 170000, 170000, '', 0, 1, 1),
(660, 46, 'tom cang', 'tom cang', 'Kg', 580000, 580000, 580000, 580000, '', 0, 1, 1),
(661, 47, 'ca lan vang', 'ca lan vang', 'Kg', 320000, 320000, 320000, 320000, '', 0, 1, 1),
(662, 47, 'ca hong', 'ca hong', 'Kg', 320000, 320000, 320000, 320000, '', 0, 1, 1),
(663, 49, 'kim chi', 'kim chi', 'Dĩa', 10000, 10000, 10000, 10000, '', 0, 1, 1),
(664, 43, 'ghe sua', 'ghe sua', 'Dĩa', 50000, 50000, 50000, 50000, '', 0, 1, 1),
(665, 47, 'lau mat ca ngu dai duong', 'lau mat ca ngu dai duong', 'Cái', 120000, 120000, 120000, 120000, '', 0, 1, 1),
(666, 47, 'ca chet', 'ca chet', 'Kg', 220000, 220000, 220000, 220000, '', 0, 1, 1),
(667, 47, 'ca ngu dai duong', 'ca ngu dai duong', 'Dĩa', 75000, 75000, 75000, 75000, '', 0, 1, 1),
(668, 49, 'trai cay', 'trai cay', 'Dĩa', 20000, 20000, 20000, 20000, '', 0, 1, 1),
(669, 47, 'ca that lac', 'ca that lac', 'Dĩa', 65000, 65000, 65000, 65000, '', 0, 1, 1),
(670, 45, 'CANH HE', 'CANH HE', 'Phần', 35000, 35000, 35000, 35000, '', 0, 1, 1),
(671, 37, 'RUOU HENNESSY', 'RUOU HENNESSY', 'Chai', 1200000, 1200000, 1200000, 1200000, '', 0, 0, 1),
(672, 46, 'muc nang', 'muc nang', 'Dĩa', 70000, 70000, 70000, 70000, '', 0, 1, 1),
(673, 49, 'mi them', 'mi them', 'Dĩa', 10000, 10000, 10000, 10000, '', 0, 1, 1),
(674, 42, 'mi xao chay', 'mi xao chai', 'Dĩa', 45000, 45000, 45000, 45000, '', 0, 1, 1),
(675, 46, 'tom su', 'tom su', 'Kg', 320000, 320000, 320000, 320000, '', 0, 1, 1),
(676, 47, 'lau ca gion', 'lau ca gion', 'Cái', 120000, 120000, 120000, 120000, '', 0, 1, 1),
(677, 49, 'com trang', 'com trang', 'Dĩa', 10000, 10000, 10000, 10000, '', 0, 1, 1),
(678, 49, 'pho mai', 'pho mai', 'Cái', 3000, 3000, 3000, 3000, '', 0, 1, 1),
(679, 42, 'lau bach tuot ', 'lau bach tuot', 'Cái', 110000, 110000, 110000, 110000, '', 0, 1, 0),
(680, 46, 'bo xao', 'bo xao', 'Dĩa', 70000, 70000, 70000, 70000, '', 0, 1, 0),
(681, 49, 'sup hai san', 'sup hai san', 'Cái', 15000, 15000, 15000, 15000, '', 0, 1, 0),
(682, 49, 'hot vit', 'hot vit', 'Cái', 8000, 8000, 8000, 8000, '', 0, 1, 0),
(683, 46, 'tom su', 'tom su', 'Dĩa', 58000, 58000, 58000, 58000, '', 0, 1, 0),
(684, 49, 'ca bop them', 'ca bop them', 'Dĩa', 60000, 60000, 60000, 60000, '', 1, 1, 0),
(685, 49, 'com ca mam', 'com ca mam', 'Dĩa', 60000, 60000, 60000, 60000, '', 0, 1, 0),
(686, 49, 'ca moi xao cu hanh', 'ca moi xao cu hanh', 'Dĩa', 40000, 40000, 40000, 40000, '', 1, 1, 0),
(687, 49, 'phu thu', 'phu thu', 'Bao', 50000, 50000, 50000, 50000, '', 1, 1, 0),
(688, 46, 'muc sua ', 'muc sua', 'Dĩa', 65000, 65000, 65000, 65000, '', 1, 1, 0),
(689, 49, 'muc sua chien gion', 'muc sua chien gion', 'Dĩa', 65000, 65000, 65000, 65000, '', 0, 1, 0),
(690, 47, 'ca mang ech', 'ca', 'Kg', 240000, 240000, 240000, 240000, '', 0, 1, 0),
(691, 47, 'lau ca ngu', 'lau', 'Bao', 130000, 130000, 130000, 130000, '', 1, 1, 0),
(692, 44, 'So To', 'So to', 'Con', 12000, 12000, 12000, 12000, '', 1, 1, 0),
(693, 49, 'rau luoc', 'rau luoc', 'Dĩa', 25000, 25000, 25000, 25000, '', 0, 1, 0),
(694, 49, 'mi xao chay', 'mi xao chay', 'Dĩa', 45000, 45000, 45000, 45000, '', 0, 1, 0),
(695, 47, 'ca chim', 'chim', 'Kg', 330000, 330000, 330000, 330000, '', 1, 1, 0),
(696, 47, 'lau dau ca hoi nau chua', 'lau dau ca hoi nau chua', 'Cái', 110000, 110000, 110000, 110000, '', 0, 1, 0),
(697, 49, 'ca them', 'ca them', 'Dĩa', 65000, 65000, 65000, 65000, '', 0, 1, 0),
(698, 49, 'bong cai xao dau hu', 'bong cai xao dau hu', 'Dĩa', 40000, 40000, 40000, 40000, '', 0, 1, 0),
(699, 47, 'ca lang ', 'ca lang', 'Kg', 190000, 190000, 190000, 190000, '', 0, 1, 0),
(700, 42, 'goi xoai tom kho', 'goi xoai tom kho', 'Dĩa', 55000, 55000, 55000, 55000, '', 0, 1, 0),
(701, 49, 'quet ga', 'quet ga', 'Cái', 5000, 5000, 5000, 5000, '', 1, 1, 0),
(702, 43, 'ghe cai', 'ghe cai', 'Kg', 330000, 330000, 330000, 330000, '', 0, 1, 0),
(703, 49, 'pho mai', 'pho mai', 'Cái', 5000, 5000, 5000, 5000, '', 0, 1, 0),
(704, 46, 'muc nang', 'muc nang', 'Kg', 240000, 240000, 240000, 240000, '', 10, 1, 0),
(705, 47, 'ca chem', 'ca chem', 'Kg', 170000, 170000, 170000, 170000, '', 0, 1, 0),
(706, 49, 'hot vit xao cai chua', 'hot vit xao cai chua', 'Dĩa', 35000, 35000, 35000, 35000, '', 0, 1, 0),
(708, 41, 'Lẩu Riêu cua/ghẹ Làng Biển', 'Lẩu riêu', 'Cái', 160000, 160000, 160000, 160000, '', 1, 1, 0),
(709, 46, 'suon bo nuong', 'suon bo nuong', 'Dĩa', 70000, 70000, 70000, 70000, '', 0, 1, 0),
(710, 46, 'suon heo', 'suon heo', 'Dĩa', 60000, 60000, 60000, 60000, '', 0, 1, 0),
(711, 46, 'suon heo nau cai chua', 'suon heo nau cai chua', 'Cái', 120000, 120000, 120000, 120000, '', 0, 1, 0),
(712, 42, 'mi xao nam', 'mi xao nam', 'Dĩa', 60000, 60000, 60000, 60000, '', 0, 1, 0),
(713, 42, ' mi trung', 'mi trung', 'Cái', 35000, 35000, 35000, 35000, '', 1, 1, 0),
(714, 43, 'cua gach', 'cua gach', 'Kg', 330000, 330000, 330000, 330000, '', 0, 1, 0),
(715, 49, 'nam bao ngu', 'nam bao ngu', 'Cái', 40000, 40000, 40000, 40000, '', 0, 1, 0),
(716, 49, 'dau hu them', 'dau hu them', 'Dĩa', 20000, 20000, 20000, 20000, '', 0, 1, 0),
(717, 49, 'tien hoa', 'tien hoa', 'Bao', 200000, 200000, 200000, 200000, '', 0, 1, 0),
(718, 49, 'ca rot', 'ca rot', 'Dĩa', 20000, 20000, 20000, 20000, '', 0, 1, 0),
(719, 47, 'CA ET', 'CA ET', 'Kg', 190000, 190000, 190000, 190000, '', 0, 1, 0),
(720, 49, 'banh trang', 'banh trang', 'Bịch', 5000, 5000, 5000, 5000, '', 0, 1, 0),
(721, 47, 'ca chia voi', 'ca chia voi', 'Con', 120000, 120000, 120000, 120000, '', 0, 1, 0),
(722, 47, 'ca tat ke', 'ca tat ke', 'Kg', 260000, 260000, 260000, 260000, '', 0, 1, 0),
(723, 47, 'ca bo hom', 'ca bo hom', 'Kg', 290000, 290000, 290000, 290000, '', 0, 1, 0),
(724, 47, 'cha ca lang bien', 'cha ca lang bien', 'Dĩa', 60000, 60000, 60000, 60000, '', 0, 1, 0),
(725, 49, 'trung luoc', 'trung luoc', 'Cái', 8000, 8000, 8000, 8000, '', 0, 1, 0),
(726, 45, 'bong cai xao toi', 'bong cai xao toi', 'Dĩa', 40000, 40000, 40000, 40000, '', 0, 1, 0),
(727, 45, 'bong cai xao hai san', 'bong cai xao hai san', 'Dĩa', 60000, 60000, 60000, 60000, '', 0, 1, 0),
(728, 45, 'cai ngot/thia xao dau hao', 'cai ngot/thia xao dau hao', 'Dĩa', 35000, 35000, 35000, 35000, '', 0, 1, 0),
(729, 45, 'cai thia/ngot xao hai san', 'cai thia/ngot xao hai san', 'Dĩa', 55000, 55000, 55000, 55000, '', 0, 1, 0),
(730, 45, 'salat tron bo trung', 'salat tron bo trung', 'Dĩa', 60000, 60000, 60000, 60000, '', 0, 1, 0),
(731, 45, 'salat dau dam', 'salat dau dam', 'Dĩa', 30000, 30000, 30000, 30000, '', 0, 1, 0),
(732, 45, 'can nuoc xao toi', 'can nuoc xao toi', 'Dĩa', 35000, 35000, 35000, 35000, '', 0, 1, 0),
(733, 45, 'can nuoc xao bo', 'can nuoc xao bo', 'Dĩa', 60000, 60000, 60000, 60000, '', 0, 1, 0),
(734, 45, 'dau bap nuong/luoc cham chao', 'dau bap nuong/luoc cham chao', 'Dĩa', 35000, 35000, 35000, 35000, '', 0, 1, 0),
(735, 45, 'kho qua cha bong', 'kho qua cha bong', 'Dĩa', 35000, 35000, 35000, 35000, '', 0, 1, 0),
(736, 47, 'ca chuon', 'ca chuon', 'Kg', 160000, 160000, 160000, 160000, '', 0, 1, 0),
(737, 49, 'gio hoa', 'gio hoa', 'Bao', 200000, 200000, 200000, 200000, '', 0, 1, 0),
(738, 49, 'nam them', 'nam them', 'Dĩa', 20000, 20000, 20000, 20000, '', 0, 1, 0),
(739, 43, 'cang ghe rang muoi', 'cang ghe rang muoi', 'Phần', 65000, 65000, 65000, 65000, '', 0, 1, 0),
(740, 43, 'cang ghe rang me', 'cang ghe rang me', 'Phần', 65000, 65000, 65000, 65000, '', 0, 1, 0),
(741, 41, 'cang cua dong', 'cang cua dong', 'Dĩa', 65000, 65000, 65000, 65000, '', 0, 1, 0),
(742, 49, 'cai chua chien trung', 'cai chua chien trung', 'Dĩa', 30000, 30000, 30000, 30000, '', 0, 1, 0),
(743, 41, 'dau hu trung chien', 'dau hu trung chien', 'Phần', 60000, 60000, 60000, 60000, '', 0, 1, 0),
(744, 49, 'thuoc esse', 'thuoc esse', 'Bao', 25000, 25000, 25000, 25000, '', 0, 1, 0),
(745, 47, 'ca lo', 'ca lo', 'Phần', 70000, 70000, 70000, 70000, '', 0, 1, 0),
(746, 43, 'con cua cum', 'con cua cum', 'Con', 30000, 30000, 30000, 30000, '', 0, 1, 0),
(747, 44, 'so mai', 'so mai', 'Con', 35000, 35000, 35000, 35000, '', 0, 1, 0),
(748, 44, 'oc co', 'oc co', 'Phần', 50000, 50000, 50000, 50000, '', 0, 1, 0),
(749, 47, 'ca mu chien/nuong', 'ca mu chien/nuong', 'Phần', 60000, 60000, 60000, 60000, '', 0, 1, 0),
(750, 47, 'ca mu', 'ca mu', 'Con', 55000, 55000, 55000, 55000, '', 0, 1, 0),
(751, 47, 'ca ria lau', 'ca ria lau', 'Cái', 120000, 120000, 120000, 120000, '', 0, 1, 0),
(752, 47, 'ca nham lau', 'ca nham lau', 'Cái', 120000, 120000, 120000, 120000, '', 0, 1, 0),
(753, 47, 'ca nham nuong muoi ot', 'ca nham nuong muoi ot', 'Phần', 60000, 60000, 60000, 60000, '', 0, 1, 0),
(754, 47, 'ca sao', 'ca sao', 'Con', 120000, 120000, 120000, 120000, '', 0, 1, 0),
(755, 47, 'ca khoai', 'ca khoai', 'Phần', 80000, 80000, 80000, 80000, '', 0, 1, 0),
(756, 47, 'ca khoai lau/hap', 'ca khoai lau/hap', 'Cái', 120000, 120000, 120000, 120000, '', 0, 1, 0),
(757, 47, 'ca nham', 'ca nham', 'Kg', 190000, 190000, 190000, 190000, '', 0, 1, 0),
(758, 43, 'cua da', 'cua da', 'Con', 25000, 25000, 25000, 25000, '', 0, 1, 0),
(759, 47, 'ca duoi nuong', 'ca duoi nuong', 'Phần', 55000, 55000, 55000, 55000, '', 0, 1, 0),
(760, 47, 'ca duoi hap', 'ca duoi hap', 'Phần', 75000, 75000, 75000, 75000, '', 0, 1, 0),
(761, 47, 'ca duoi lau', 'ca duoi lau', 'Phần', 110000, 110000, 110000, 110000, '', 0, 1, 0),
(762, 47, 'dau ca hoi lau', 'dau ca hoi lau', 'Cái', 110000, 110000, 110000, 110000, '', 0, 1, 0),
(763, 42, 'lau hai san lang bien', 'lau hai san lang bien', 'Cái', 130000, 130000, 130000, 130000, '', 0, 1, 0),
(764, 46, 'muc hap hanh gung', 'muc hap hanh gung', 'Phần', 75000, 75000, 75000, 75000, '', 0, 1, 0),
(765, 42, 'lau muc trung', 'lau muc trung', 'Cái', 130000, 130000, 130000, 130000, '', 0, 1, 0),
(766, 46, 'muc trung hap hanh gung', 'muc trung hap hanh gung', 'Phần', 85000, 85000, 85000, 85000, '', 0, 1, 0),
(767, 47, 'ca mu hap/chung tuong', 'ca mu hap/chung tuong', 'Phần', 85000, 85000, 85000, 85000, '', 0, 1, 0),
(768, 42, 'lau chua ca mu', 'lau chua ca mu', 'Cái', 120000, 120000, 120000, 120000, '', 0, 1, 0),
(769, 47, 'bao tu ca bop xao', 'bao tu ca bop xao', 'Phần', 55000, 55000, 55000, 55000, '', 0, 1, 0),
(770, 42, 'lau bao tu ca bop nau chua', 'lau bao tu ca bop nau chua', 'Cái', 120000, 120000, 120000, 120000, '', 0, 1, 0),
(771, 42, 'lau ca chach hue nau chua', 'lau ca chach hue nau chua', 'Cái', 130000, 130000, 130000, 130000, '', 0, 1, 0),
(772, 42, 'sup cua', 'sup cua', 'Cái', 50000, 50000, 50000, 50000, '', 0, 1, 0),
(773, 42, 'sup hai san', 'sup hai san', 'Cái', 50000, 50000, 50000, 50000, '', 0, 1, 0),
(774, 42, 'sup tom', 'sup tom', 'Cái', 50000, 50000, 50000, 50000, '', 0, 1, 0),
(775, 42, 'sup muc', 'sup muc', 'Cái', 50000, 50000, 50000, 50000, '', 0, 1, 0),
(776, 46, 'bach tuoc hap hanh gung', 'bach tuoc hap hanh gung', 'Phần', 80000, 80000, 80000, 80000, '', 0, 1, 0),
(778, 47, 'ca tat ke', 'ca tat ke', 'Con', 90000, 90000, 90000, 90000, '', 0, 1, 0),
(779, 44, 'oc lat luoc xa', 'oc lat luoc xa', 'Phần', 50000, 50000, 50000, 50000, '', 0, 1, 0),
(780, 47, 'ca ngan', 'ca ngan', 'Con', 30000, 30000, 30000, 30000, '', 0, 1, 0),
(781, 47, 'ca du mot nang', 'ca du mot nang', 'Phần', 70000, 70000, 70000, 70000, '', 0, 1, 0),
(782, 47, 'ca chia voi kg', 'ca chia voi kg', 'Kg', 290000, 290000, 290000, 290000, '', 0, 1, 0),
(783, 46, 'tom song', 'tom song', 'Kg', 460000, 460000, 460000, 460000, '', 0, 1, 0),
(784, 47, 'ca phen rau hap', 'ca phen rau hap', 'Phần', 85000, 85000, 85000, 85000, '', 0, 1, 0),
(785, 47, 'ca phen rau nuong', 'ca phen rau nuong', 'Con', 70000, 70000, 70000, 70000, '', 0, 1, 0),
(786, 47, 'ca nau', 'ca nau', 'Con', 60000, 60000, 60000, 60000, '', 0, 1, 0),
(787, 44, 'oc buou nau chuoi dau', 'oc buou nau chuoi dau', 'Thố', 80000, 80000, 80000, 80000, '', 0, 1, 0),
(788, 44, 'oc buou them', 'oc buou them', 'Phần', 50000, 50000, 50000, 50000, '', 0, 1, 0),
(789, 41, 'com chay nuong', 'com chay nuong', 'Phần', 30000, 30000, 30000, 30000, '', 0, 1, 0),
(790, 47, 'ca he', 'ca he', 'Con', 40000, 40000, 40000, 40000, '', 0, 1, 0),
(791, 47, 'ca mu kg', 'ca mu kg', 'Kg', 340000, 340000, 340000, 340000, '', 0, 1, 0),
(792, 42, 'lau ca ngu dai duong', 'lau ca ngu dai duong', 'Cái', 130000, 130000, 130000, 130000, '', 0, 1, 0),
(793, 38, 'De chien bo', 'De chien bo', 'Phần', 55000, 55000, 55000, 55000, '', 0, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_course_log`
--

CREATE TABLE IF NOT EXISTS `tbl_course_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_table` int(11) NOT NULL,
  `id_course` int(11) NOT NULL,
  `date_time` datetime NOT NULL,
  `count` int(11) NOT NULL,
  `state` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=802 ;

--
-- Dumping data for table `tbl_course_log`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_customer`
--

CREATE TABLE IF NOT EXISTS `tbl_customer` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  `card` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `discount` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=25 ;

--
-- Dumping data for table `tbl_customer`
--

INSERT INTO `tbl_customer` (`id`, `name`, `type`, `card`, `phone`, `address`, `note`, `discount`) VALUES
(1, 'Khách lẻ', 0, '1', '', '', '', 0),
(24, 'tuan', 0, '123456', '0909099999', '', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_domain`
--

CREATE TABLE IF NOT EXISTS `tbl_domain` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=8 ;

--
-- Dumping data for table `tbl_domain`
--

INSERT INTO `tbl_domain` (`id`, `name`) VALUES
(1, 'KHU TUM'),
(2, 'KHU VIP'),
(3, 'KHU TRONG'),
(4, 'KHU NGOÀI'),
(5, 'KH MUA VỀ'),
(7, 'ĐẶT TIỆC');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_employee`
--

CREATE TABLE IF NOT EXISTS `tbl_employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `job` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `gender` tinyint(2) NOT NULL,
  `phone` varchar(13) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `salary_base` int(11) NOT NULL,
  `card` varchar(14) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=23 ;

--
-- Dumping data for table `tbl_employee`
--

INSERT INTO `tbl_employee` (`id`, `name`, `job`, `gender`, `phone`, `address`, `salary_base`, `card`) VALUES
(2, 'quang', 'Phục vụ', 0, '', 'Đồng Tháp', 3000000, ''),
(6, 'dat', 'NV', 0, '', 'Đồng Tháp', 2500000, ''),
(7, 'khanh', 'pv', 1, '', 'Đồng Tháp', 5500000, ''),
(8, 'mu ', 'pv bep nuong', 0, '', 'Đồng Tháp', 3000000, ''),
(9, 'thom', 'NV PV', 0, '', 'Đồng Tháp', 2800000, ''),
(10, 'a phong bep', 'bep nuong', 1, '', 'Đồng Tháp', 6000000, ''),
(11, 'son ', 'bep nuong', 0, '', '', 3500000, ''),
(12, 'a thanh', 'bao ve', 0, '', '', 3000000, ''),
(13, 'cuong', 'phu bep', 0, '', '', 3500000, ''),
(14, 'co tap vu', '', 1, '', '', 3000000, ''),
(15, 'thu ', '', 1, '', '', 2800000, ''),
(16, 'huong', 'nv pv', 1, '', '', 2800000, ''),
(17, 'DU', 'NV BEP', 0, '', '', 4500000, ''),
(18, 'hau', 'nv bep', 0, '', '', 5500000, ''),
(21, 'nam', 'nv pv', 0, '', '', 2000000, ''),
(22, 'an ', 'nv pv', 0, '', '', 2000000, '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_guest`
--

CREATE TABLE IF NOT EXISTS `tbl_guest` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(16) CHARACTER SET latin1 NOT NULL,
  `entry_time` varchar(32) CHARACTER SET latin1 NOT NULL,
  `exit_time` varchar(32) CHARACTER SET latin1 NOT NULL,
  `agent` varchar(16) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=150 ;

--
-- Dumping data for table `tbl_guest`
--

INSERT INTO `tbl_guest` (`id`, `ip`, `entry_time`, `exit_time`, `agent`) VALUES
(149, '115.78.94.118', '1383319305', '1383322905', '115.78.94.118');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_notify`
--

CREATE TABLE IF NOT EXISTS `tbl_notify` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  `message` varchar(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tbl_notify`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_order_import`
--

CREATE TABLE IF NOT EXISTS `tbl_order_import` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idsupplier` int(11) NOT NULL,
  `date` date NOT NULL,
  `description` varchar(50) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_order_import_1` (`idsupplier`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=353 ;

--
-- Dumping data for table `tbl_order_import`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_order_import_detail`
--

CREATE TABLE IF NOT EXISTS `tbl_order_import_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idorder` int(11) NOT NULL,
  `idresource` int(11) NOT NULL,
  `count` float NOT NULL,
  `price` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_order_import_detail_1` (`idorder`),
  KEY `tbl_order_import_detail_2` (`idresource`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=641 ;

--
-- Dumping data for table `tbl_order_import_detail`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_paid_customer`
--

CREATE TABLE IF NOT EXISTS `tbl_paid_customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idcustomer` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_customer_paid_1` (`idcustomer`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tbl_paid_customer`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_paid_employee`
--

CREATE TABLE IF NOT EXISTS `tbl_paid_employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_employee` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(150) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_employee` (`id_employee`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `tbl_paid_employee`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_paid_general`
--

CREATE TABLE IF NOT EXISTS `tbl_paid_general` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_term` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_paid_1` (`id_term`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=183 ;

--
-- Dumping data for table `tbl_paid_general`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_paid_pay_roll`
--

CREATE TABLE IF NOT EXISTS `tbl_paid_pay_roll` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_employee` int(11) NOT NULL,
  `date` date NOT NULL,
  `value_base` int(11) NOT NULL,
  `value_sub` int(11) NOT NULL,
  `value_pre` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_paid_pay_roll_1` (`id_employee`),
  KEY `id_employee` (`id_employee`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tbl_paid_pay_roll`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_paid_supplier`
--

CREATE TABLE IF NOT EXISTS `tbl_paid_supplier` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idsupplier` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_supplier_paid_1` (`idsupplier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tbl_paid_supplier`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_pay_roll`
--

CREATE TABLE IF NOT EXISTS `tbl_pay_roll` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_employee` int(11) NOT NULL,
  `id_tracking` int(11) NOT NULL,
  `absent` int(11) NOT NULL,
  `base_value` int(11) NOT NULL,
  `extra_value` int(11) NOT NULL,
  `punish_value` int(11) NOT NULL,
  `note` varchar(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_employee` (`id_employee`),
  KEY `id_tracking` (`id_tracking`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=131 ;

--
-- Dumping data for table `tbl_pay_roll`
--

INSERT INTO `tbl_pay_roll` (`id`, `id_employee`, `id_tracking`, `absent`, `base_value`, `extra_value`, `punish_value`, `note`) VALUES
(97, 2, 13, 2, 3000000, 0, 0, 'ung 1000000'),
(98, 6, 13, 0, 2500000, 0, 0, 'Ghi chú'),
(99, 7, 13, 0, 5500000, 0, 0, 'Ghi chú'),
(100, 8, 13, 0, 2500000, 0, 0, 'Ghi chú'),
(101, 9, 13, 0, 2500000, 0, 0, 'Ghi chú'),
(102, 10, 13, 0, 1300000, 0, 0, 'Ghi chú'),
(103, 2, 15, 0, 3000000, 0, 0, 'Ghi chú'),
(104, 6, 15, 0, 2500000, 0, 0, 'Ghi chú'),
(105, 7, 15, 0, 5500000, 0, 0, 'Ghi chú'),
(106, 8, 15, 5, 3000000, 0, 0, 'Ghi chú'),
(107, 9, 15, 0, 2800000, 0, 0, 'Ghi chú'),
(108, 10, 15, 0, 6000000, 0, 0, 'Ghi chú'),
(109, 11, 15, 0, 3500000, 0, 0, 'Ghi chú'),
(110, 12, 15, 0, 3000000, 0, 0, 'Ghi chú'),
(111, 13, 15, 0, 3500000, 0, 0, 'Ghi chú'),
(112, 14, 15, 0, 3000000, 0, 0, 'Ghi chú'),
(113, 15, 15, 0, 2800000, 0, 0, 'Ghi chú'),
(114, 16, 15, 0, 2800000, 0, 0, 'Ghi chú'),
(115, 17, 15, 0, 4500000, 0, 0, 'Ghi chú'),
(116, 18, 15, 0, 5500000, 0, 0, 'Ghi chú'),
(117, 2, 14, 3, 3000000, 400000, 0, 'Ghi chú'),
(118, 6, 14, 19, 2500000, 0, 0, 'Ghi chú'),
(119, 7, 14, 4, 2800000, 0, 0, 'Ghi chú'),
(120, 8, 14, 5, 3000000, 0, 0, 'Ghi chú'),
(121, 9, 14, 1, 2800000, 100000, 0, 'Ghi chú'),
(122, 10, 14, 2, 6000000, 0, 0, 'Ghi chú'),
(123, 11, 14, 1, 3500000, 0, 0, 'Ghi chú'),
(124, 12, 14, 0, 3000000, 0, 0, 'Ghi chú'),
(125, 13, 14, 4, 3500000, 0, 0, 'Ghi chú'),
(126, 14, 14, 0, 3000000, 100000, 0, 'Ghi chú'),
(127, 15, 14, 10, 1500000, 900000, 0, 'tang ca '),
(128, 16, 14, 7, 2100000, 400000, 0, 'tang ca'),
(129, 17, 14, 3, 4500000, 0, 0, 'Ghi chú'),
(130, 18, 14, 5, 5500000, 0, 0, 'Ghi chú');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_r2c`
--

CREATE TABLE IF NOT EXISTS `tbl_r2c` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_course` int(11) NOT NULL,
  `id_resource` int(11) NOT NULL,
  `value1` double NOT NULL,
  `value2` double NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_r2c_1` (`id_course`),
  KEY `tbl_r2c_2` (`id_resource`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tbl_r2c`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_resource`
--

CREATE TABLE IF NOT EXISTS `tbl_resource` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `idsupplier` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `unit` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `price` int(10) NOT NULL,
  `description` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_resource_1` (`idsupplier`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=211 ;

--
-- Dumping data for table `tbl_resource`
--

INSERT INTO `tbl_resource` (`id`, `idsupplier`, `name`, `unit`, `price`, `description`) VALUES
(105, 21, 'SG special chai', 'Chai', 9600, ''),
(106, 21, 'SG special lon', 'Lon', 11000, ''),
(107, 21, 'SG đỏ', 'Chai', 6600, ''),
(108, 21, 'Heneiken chai', 'Chai', 12050, ''),
(109, 21, 'Heneiken lon', 'Lon', 14000, ''),
(110, 21, 'Tiger nâu', 'Chai', 11000, ''),
(111, 21, 'Tiger bạc', 'Chai', 12000, ''),
(112, 28, 'Sagota', 'Lon', 12500, ''),
(113, 28, 'Sagota vàng', 'Lon', 11000, ''),
(114, 13, 'Cua biển', 'Kg', 230000, ''),
(115, 13, 'Ghẹ', 'Kg', 230000, ''),
(116, 13, 'Cá nhám', 'Kg', 90000, ''),
(117, 13, 'Cá đuối', 'Kg', 230000, ''),
(118, 13, 'Cá chạch quế', 'Kg', 270000, ''),
(119, 13, 'Cá quế', 'Kg', 270000, ''),
(120, 18, 'Gà ', 'Kg', 90000, ''),
(121, 19, 'Cá sapa ', 'Kg', 57000, ''),
(122, 19, 'Cá cam', 'Kg', 1, ''),
(123, 19, 'Cá bò da', 'Kg', 1, ''),
(124, 15, 'Sò huyết', 'Kg', 90000, ''),
(125, 15, 'Nghêu', 'Kg', 35000, ''),
(126, 14, 'Đá cắt', 'Kg', 800, ''),
(127, 14, 'Đá xay', 'Kg', 750, ''),
(128, 14, 'Đá cây', 'Kg', 600, ''),
(129, 22, 'Pepsi ', 'Lon', 6900, ''),
(130, 22, 'Sting lon', 'Lon', 6300, ''),
(131, 22, 'Trà C2', 'Chai', 4300, ''),
(132, 22, 'Suối lavie(500ml)', 'Chai', 3500, ''),
(133, 23, 'Rượu volka men', 'Chai', 1, ''),
(134, 23, 'Rượu phú lễ', 'Chai', 1, ''),
(135, 23, 'Rượu bồ đào đá', 'Chai', 1, ''),
(136, 17, 'Đường', 'Kg', 16000, ''),
(137, 17, 'Muối bọt', 'Bịch', 1, ''),
(138, 17, 'Muối hột', 'Bịch', 1, ''),
(139, 17, 'Bột ngọt', 'Bịch', 45000, ''),
(140, 17, 'Tương ớt', 'Chai', 52000, ''),
(141, 17, 'Tương cà', 'Chai', 1, ''),
(142, 17, 'Tương xí muội', 'Chai', 1, ''),
(143, 17, 'Dầu hào', 'Chai', 30000, ''),
(144, 17, 'Nước tương', 'Chai', 1, ''),
(145, 17, 'Mù tạt nhật', 'Chai', 1, ''),
(146, 17, 'Sữa ngôi sao', 'Hộp', 16000, ''),
(147, 17, 'Bột chiên giòn', 'Bịch', 5000, ''),
(148, 17, 'Bột chiên xù(lớn)', 'Bịch', 1, ''),
(149, 17, 'Bột chiên xù(nhỏ)', 'Bịch', 7000, ''),
(150, 17, 'Dầu ăn', 'Thùng', 650000, ''),
(151, 17, 'Dầu mè', 'Chai', 1, ''),
(152, 17, 'Bột tàu xì', 'Kg', 1, ''),
(153, 17, 'Sa tế', 'Chai', 1, ''),
(154, 17, 'Ngũ vị hương', 'Bịch', 1, ''),
(155, 17, 'Nước tương nam dương', 'Chai', 1, ''),
(156, 17, 'Bột nghệ', 'Kg', 1, ''),
(157, 17, 'Tiêu xay', 'Kg', 1, ''),
(158, 17, 'Tiêu sọ', 'Kg', 1, ''),
(159, 17, 'Bột cà ri', 'Bịch', 1, ''),
(160, 17, 'Đậu hà lan ', 'Lon', 1, ''),
(161, 16, 'Cần tàu', 'Kg', 20000, ''),
(162, 16, 'Gừng', 'Kg', 26000, ''),
(163, 16, 'Ghiền', 'Kg', 0, ''),
(164, 16, 'Rau muống', 'Kg', 8000, ''),
(165, 16, 'Salad lụa', 'Kg', 14000, ''),
(166, 16, 'Cà rốt', 'Kg', 17500, ''),
(167, 16, 'Rau sống', 'Kg', 18000, ''),
(168, 16, 'Hành lá', 'Kg', 15000, ''),
(169, 16, 'Hành tây', 'Kg', 16000, ''),
(170, 16, 'Hành tím', 'Kg', 25000, ''),
(171, 16, 'Rau râm', 'Kg', 10000, ''),
(172, 16, 'Rau nhúc', 'Kg', 0, ''),
(173, 16, 'Cù nèo', 'Kg', 0, ''),
(174, 16, 'Cải ngọt', 'Kg', 0, ''),
(175, 16, 'Cải thìa', 'Kg', 10000, ''),
(176, 17, 'Tỏi củ', 'Kg', 18000, ''),
(177, 16, 'Sả cộng', 'Kg', 10000, ''),
(178, 16, 'Ớt đà lạt', 'Kg', 0, ''),
(179, 16, 'Ớt hiểm xanh', 'Kg', 40000, ''),
(180, 16, 'Ớt sừng', 'Kg', 50000, ''),
(181, 16, 'Khoai môn', 'Kg', 20000, ''),
(182, 16, 'Khoai tây', 'Kg', 28000, ''),
(183, 16, 'Khổ hoa', 'Kg', 0, ''),
(184, 16, 'Dưa leo', 'Kg', 9000, ''),
(185, 16, 'Cà chua', 'Kg', 13000, ''),
(186, 16, 'Đậu bắp', 'Kg', 0, ''),
(187, 16, 'Khóm ', 'Trái', 9000, ''),
(188, 16, 'Cải thảo', 'Kg', 0, ''),
(189, 16, 'Chanh', 'Kg', 8000, ''),
(190, 16, 'Hạnh', 'Kg', 0, ''),
(191, 16, 'Khế', 'Kg', 0, ''),
(192, 16, 'Mồng tơi', 'Kg', 0, ''),
(193, 16, 'Mướp ', 'Kg', 0, ''),
(194, 16, 'Bầu', 'Kg', 0, ''),
(195, 16, 'Ngò rai', 'Kg', 0, ''),
(196, 16, 'Ngò ôm', 'Kg', 0, ''),
(197, 26, 'Đồ khui', 'Cái', 5000, ''),
(198, 26, 'Xô đá', 'Cái', 0, ''),
(199, 26, 'Gấp đá', 'Cái', 0, ''),
(200, 13, 'Cá chép giòn', 'Kg', 280000, ''),
(201, 13, 'Cá lăng', 'Kg', 75000, ''),
(202, 13, 'Cá lăng vàng', 'Kg', 250000, ''),
(203, 15, 'Mực ống', 'Kg', 160000, ''),
(205, 16, 'Nấm rơm', 'Kg', 50000, ''),
(206, 16, 'Củ cải trắng', 'Kg', 8000, ''),
(207, 16, 'Ngò rí', 'Kg', 40000, ''),
(208, 27, 'Mì gói', 'Gói', 2400, ''),
(209, 27, 'Phô mai', 'Miếng', 5000, ''),
(210, 16, 'Bắp chuối', 'Kg', 20000, '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_session`
--

CREATE TABLE IF NOT EXISTS `tbl_session` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idtable` int(11) NOT NULL,
  `iduser` int(11) NOT NULL,
  `idcustomer` int(11) NOT NULL,
  `idemployee` int(11) NOT NULL,
  `datetime` datetime NOT NULL,
  `datetimeend` datetime DEFAULT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  `discount_value` int(11) NOT NULL,
  `discount_percent` int(11) NOT NULL,
  `surtax` int(11) NOT NULL,
  `payment` int(11) NOT NULL,
  `value` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idtable` (`idtable`),
  KEY `iduser` (`iduser`),
  KEY `tbl_session_3` (`idcustomer`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2276 ;

--
-- Dumping data for table `tbl_session`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_session_detail`
--

CREATE TABLE IF NOT EXISTS `tbl_session_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idsession` int(11) NOT NULL,
  `idcourse` int(11) NOT NULL,
  `count` float NOT NULL,
  `price` bigint(20) NOT NULL,
  `enable` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idsession` (`idsession`),
  KEY `idcourse` (`idcourse`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=12760 ;

--
-- Dumping data for table `tbl_session_detail`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_store`
--

CREATE TABLE IF NOT EXISTS `tbl_store` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(125) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_store`
--

INSERT INTO `tbl_store` (`id`, `name`, `note`) VALUES
(1, 'Kho nhà', 'Ghi chú gì đây ?');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_supplier`
--

CREATE TABLE IF NOT EXISTS `tbl_supplier` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `debt` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=29 ;

--
-- Dumping data for table `tbl_supplier`
--

INSERT INTO `tbl_supplier` (`id`, `name`, `phone`, `address`, `note`, `debt`) VALUES
(13, 'CÁ - CUA - GHẸ SỐNG', '', 'Can Tho', '', 0),
(14, 'NƯỚC ĐÁ - ĐL TRÍ', '', 'Vĩnh Long', '', 0),
(15, 'NGHÊU - SÒ - MỰC', '', 'Cần thơ', '', 0),
(16, 'RAU QUẢ', '', 'Chợ Vĩnh long', '', 0),
(17, 'GIA VỊ - TẠP HÓA A', '', 'Chợ Vĩnh long', '', 0),
(18, 'GIA CẦM - CH A', '', 'Vĩnh long', '', 0),
(19, 'HÀNG CẤP ĐÔNG - METRO CẦN THƠ', '', 'Metro Cần Thơ', '', 0),
(20, 'GAS - CTY A', '', 'Vĩnh long', '', 0),
(21, 'BIA - CTY CP DU LỊCH CỬU LONG', '0703 828 042', 'Chưa cập nhật', '', 0),
(22, 'NƯỚC GIẢI KHÁT - NPP ĐOAN TRANG', '', 'Đoan trang', '', 0),
(23, 'RƯỢU - NPP CẦN THƠ', '', '', '', 0),
(24, 'Rượu nội', '', '', '', 0),
(25, 'Vật dụng bếp', '', '', '', 0),
(26, 'Vật dụng tổ bàn', '', '', '', 0),
(27, 'TẠP HÓA 01', '', 'Chợ  Vĩnh long', '', 0),
(28, 'BIA - CTY SAGOTA', 'Chưa cập nhật', 'Chưa cập nhật', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_table`
--

CREATE TABLE IF NOT EXISTS `tbl_table` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iddomain` int(11) NOT NULL,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `iduser` int(11) DEFAULT NULL,
  `type` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `iddomain` (`iddomain`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=75 ;

--
-- Dumping data for table `tbl_table`
--

INSERT INTO `tbl_table` (`id`, `iddomain`, `name`, `iduser`, `type`) VALUES
(1, 1, 'B01', 1, '0'),
(2, 1, 'B02', 1, '0'),
(14, 2, 'VIP01', 1, '0'),
(15, 2, 'VIP02', 1, '0'),
(16, 2, 'VIP03', 1, '0'),
(26, 3, '001', 1, '0'),
(27, 3, '002', 1, '0'),
(28, 3, '003', 1, '0'),
(29, 3, '004', 1, '0'),
(30, 3, '005', 1, '0'),
(31, 3, '006', 1, '0'),
(32, 3, '007', 1, '0'),
(33, 3, '008', 1, '0'),
(34, 4, '015', 1, '0'),
(35, 4, '016', 1, '0'),
(36, 4, '017', 1, '0'),
(37, 4, '018', 1, '0'),
(38, 4, '019', 1, '0'),
(39, 4, '020', 1, '0'),
(40, 4, '021', 1, '0'),
(41, 4, '022', 1, '0'),
(44, 1, 'B03', 1, '0'),
(46, 5, 'MANG VỀ 01', 1, '0'),
(49, 3, '009', 1, '0'),
(50, 3, '010', 1, '0'),
(51, 3, '011', 1, '0'),
(52, 3, '012', 1, '0'),
(53, 3, 'KT13', 1, '0'),
(54, 3, 'KT14', 1, '0'),
(55, 4, '023', 1, '0'),
(56, 4, '024', 1, '0'),
(57, 4, '025', 1, '0'),
(58, 4, '026', 1, '0'),
(59, 4, 'KN27', 1, '0'),
(60, 4, 'KN28', 1, '0'),
(61, 4, 'KN29', 1, '0'),
(62, 4, 'KN30', 1, '0'),
(63, 4, 'KN31', 1, '0'),
(64, 4, 'KN32', 1, '0'),
(65, 4, 'KN33', 1, '0'),
(66, 4, 'KN34', 1, '0'),
(67, 4, 'KN35', 1, '0'),
(68, 4, 'KN36', 1, '0'),
(69, 4, 'KN37', 1, '0'),
(70, 5, 'MANG VỀ 02', 1, '0'),
(71, 5, 'MANG VỀ 03', 1, '0'),
(72, 7, 'ĐẶT TIỆC 01', 1, '0'),
(73, 7, 'ĐẶT TIỆC 02', 1, '0'),
(74, 7, 'ĐẶT TIỆC 03', 1, '0');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_table_log`
--

CREATE TABLE IF NOT EXISTS `tbl_table_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iduser` int(11) NOT NULL,
  `idtable` int(11) NOT NULL,
  `datetime` datetime NOT NULL,
  `note` varchar(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tbl_table_log`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_term`
--

CREATE TABLE IF NOT EXISTS `tbl_term` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=12 ;

--
-- Dumping data for table `tbl_term`
--

INSERT INTO `tbl_term` (`id`, `name`, `type`) VALUES
(1, 'Tiền Điện', 0),
(2, 'Tiền Nước', 0),
(3, 'Thuế', 0),
(10, 'Tiền Ăn Nhân Viên', 0),
(11, 'CP Khác', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_term_collect`
--

CREATE TABLE IF NOT EXISTS `tbl_term_collect` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Dumping data for table `tbl_term_collect`
--

INSERT INTO `tbl_term_collect` (`id`, `name`) VALUES
(2, 'Phụ Phẩm'),
(3, 'Đặc Biệt'),
(4, 'Ung luong NV');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tracking`
--

CREATE TABLE IF NOT EXISTS `tbl_tracking` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_start` date NOT NULL,
  `date_end` date NOT NULL,
  `paid_general` int(11) NOT NULL,
  `paid_pay_roll` int(11) NOT NULL,
  `paid_import` int(11) NOT NULL,
  `collect_general` int(11) NOT NULL,
  `collect_customer` int(11) NOT NULL,
  `collect_selling_debt` int(11) NOT NULL,
  `collect_selling_nodebt` int(11) NOT NULL,
  `estate_rate` int(11) NOT NULL,
  `store_value` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=16 ;

--
-- Dumping data for table `tbl_tracking`
--

INSERT INTO `tbl_tracking` (`id`, `date_start`, `date_end`, `paid_general`, `paid_pay_roll`, `paid_import`, `collect_general`, `collect_customer`, `collect_selling_debt`, `collect_selling_nodebt`, `estate_rate`, `store_value`) VALUES
(13, '2014-01-01', '2014-01-31', 0, 0, 0, 0, 0, 0, 0, 0, 0),
(14, '2014-02-01', '2014-02-28', 0, 0, 0, 0, 0, 0, 0, 0, 0),
(15, '2014-03-01', '2014-03-31', 0, 0, 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tracking_course`
--

CREATE TABLE IF NOT EXISTS `tbl_tracking_course` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tracking` int(11) NOT NULL,
  `id_td` int(11) NOT NULL,
  `id_course` int(11) NOT NULL,
  `count` float NOT NULL,
  `price` int(11) NOT NULL,
  `value` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tbl_tracking_course`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_tracking_customer`
--

CREATE TABLE IF NOT EXISTS `tbl_tracking_customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tracking` int(11) NOT NULL,
  `id_customer` int(11) NOT NULL,
  `value_session1` int(11) NOT NULL,
  `value_session2` int(11) NOT NULL,
  `value_collect` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_tracking_customer`
--

INSERT INTO `tbl_tracking_customer` (`id`, `id_tracking`, `id_customer`, `value_session1`, `value_session2`, `value_collect`) VALUES
(1, 14, 24, 0, 28000, 18000);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tracking_daily`
--

CREATE TABLE IF NOT EXISTS `tbl_tracking_daily` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tracking` int(11) NOT NULL,
  `date` date NOT NULL,
  `selling` bigint(20) NOT NULL,
  `import` bigint(20) NOT NULL,
  `store` bigint(20) NOT NULL,
  `paid` bigint(20) NOT NULL,
  `collect` bigint(20) NOT NULL,
  `time1` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tbl_tracking_daily`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_tracking_store`
--

CREATE TABLE IF NOT EXISTS `tbl_tracking_store` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tracking` int(11) NOT NULL,
  `id_td` int(11) NOT NULL,
  `id_resource` int(11) NOT NULL,
  `count_old` float NOT NULL,
  `count_import` float NOT NULL,
  `count_export` float NOT NULL,
  `price` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tbl_tracking_store`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_unit`
--

CREATE TABLE IF NOT EXISTS `tbl_unit` (
  `id` int(25) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=32 ;

--
-- Dumping data for table `tbl_unit`
--

INSERT INTO `tbl_unit` (`id`, `name`) VALUES
(1, 'Ly'),
(2, 'Điếu'),
(3, 'Chai'),
(4, 'Lon'),
(5, 'Dĩa'),
(6, 'Thùng'),
(7, 'Két'),
(9, 'Bịch'),
(10, 'Gói'),
(20, 'Trái'),
(21, 'Cái'),
(22, 'Hủ'),
(23, 'Kg'),
(24, 'Con'),
(25, 'Bao'),
(26, 'Cây'),
(27, 'Hộp'),
(28, 'Miếng'),
(29, 'Bó'),
(30, 'Phần'),
(31, 'Thố');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE IF NOT EXISTS `tbl_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pass` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gender` int(11) NOT NULL,
  `note` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `datecreate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dateupdate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `dateactivity` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `type` tinyint(4) NOT NULL,
  `code` varchar(13) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `name`, `email`, `pass`, `gender`, `note`, `datecreate`, `dateupdate`, `dateactivity`, `type`, `code`) VALUES
(1, 'Quản lý', 'quanly@gmail.com', '123456', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 4, ''),
(3, 'Quân', 'quan@gmail.com', '123456', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 2, '');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_collect_customer`
--
ALTER TABLE `tbl_collect_customer`
  ADD CONSTRAINT `tbl_customer_collect_1` FOREIGN KEY (`idcustomer`) REFERENCES `tbl_customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_collect_general`
--
ALTER TABLE `tbl_collect_general`
  ADD CONSTRAINT `tbl_collect_general_1` FOREIGN KEY (`id_term`) REFERENCES `tbl_term_collect` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_course`
--
ALTER TABLE `tbl_course`
  ADD CONSTRAINT `tbl_course_1` FOREIGN KEY (`idcategory`) REFERENCES `tbl_category` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_order_import`
--
ALTER TABLE `tbl_order_import`
  ADD CONSTRAINT `tbl_order_import_1` FOREIGN KEY (`idsupplier`) REFERENCES `tbl_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_order_import_detail`
--
ALTER TABLE `tbl_order_import_detail`
  ADD CONSTRAINT `tbl_order_import_detail_1` FOREIGN KEY (`idorder`) REFERENCES `tbl_order_import` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_order_import_detail_2` FOREIGN KEY (`idresource`) REFERENCES `tbl_resource` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_paid_customer`
--
ALTER TABLE `tbl_paid_customer`
  ADD CONSTRAINT `tbl_customer_paid_1` FOREIGN KEY (`idcustomer`) REFERENCES `tbl_customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_paid_employee`
--
ALTER TABLE `tbl_paid_employee`
  ADD CONSTRAINT `tbl_paid_employee_ibfk_1` FOREIGN KEY (`id_employee`) REFERENCES `tbl_employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_paid_general`
--
ALTER TABLE `tbl_paid_general`
  ADD CONSTRAINT `tbl_paid_general_1` FOREIGN KEY (`id_term`) REFERENCES `tbl_term` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_paid_pay_roll`
--
ALTER TABLE `tbl_paid_pay_roll`
  ADD CONSTRAINT `tbl_paid_pay_roll_ibfk_1` FOREIGN KEY (`id_employee`) REFERENCES `tbl_employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_paid_supplier`
--
ALTER TABLE `tbl_paid_supplier`
  ADD CONSTRAINT `tbl_supplier_paid_1` FOREIGN KEY (`idsupplier`) REFERENCES `tbl_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_pay_roll`
--
ALTER TABLE `tbl_pay_roll`
  ADD CONSTRAINT `tbl_pay_roll_ibfk_1` FOREIGN KEY (`id_employee`) REFERENCES `tbl_employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_pay_roll_ibfk_2` FOREIGN KEY (`id_tracking`) REFERENCES `tbl_tracking` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_r2c`
--
ALTER TABLE `tbl_r2c`
  ADD CONSTRAINT `tbl_r2c_1` FOREIGN KEY (`id_course`) REFERENCES `tbl_course` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_r2c_2` FOREIGN KEY (`id_resource`) REFERENCES `tbl_resource` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_resource`
--
ALTER TABLE `tbl_resource`
  ADD CONSTRAINT `tbl_resource_1` FOREIGN KEY (`idsupplier`) REFERENCES `tbl_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_session`
--
ALTER TABLE `tbl_session`
  ADD CONSTRAINT `tbl_session_1` FOREIGN KEY (`idtable`) REFERENCES `tbl_table` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_session_2` FOREIGN KEY (`iduser`) REFERENCES `tbl_user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_session_3` FOREIGN KEY (`idcustomer`) REFERENCES `tbl_customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_session_detail`
--
ALTER TABLE `tbl_session_detail`
  ADD CONSTRAINT `tbl_session_detail_1` FOREIGN KEY (`idsession`) REFERENCES `tbl_session` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_session_detail_2` FOREIGN KEY (`idcourse`) REFERENCES `tbl_course` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_table`
--
ALTER TABLE `tbl_table`
  ADD CONSTRAINT `tbl_table_1` FOREIGN KEY (`iddomain`) REFERENCES `tbl_domain` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
