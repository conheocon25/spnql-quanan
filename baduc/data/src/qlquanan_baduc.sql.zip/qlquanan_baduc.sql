-- phpMyAdmin SQL Dump
-- version 4.0.8
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 29, 2013 at 01:54 AM
-- Server version: 5.1.72-cll
-- PHP Version: 5.3.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `qlquanan_baduc`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_app`
--

CREATE TABLE IF NOT EXISTS `tbl_app` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(125) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(50) CHARACTER SET utf8 NOT NULL,
  `banner` varchar(125) CHARACTER SET utf8 NOT NULL,
  `prefix` varchar(50) CHARACTER SET utf8 NOT NULL,
  `alias` varchar(256) CHARACTER SET utf8 NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_activity` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `type` tinyint(4) NOT NULL,
  `page_view` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_app`
--

INSERT INTO `tbl_app` (`id`, `name`, `phone`, `address`, `email`, `banner`, `prefix`, `alias`, `date_created`, `date_modified`, `date_activity`, `type`, `page_view`) VALUES
(1, 'Karaoke Ba Đức', '0945 03 07 09', 'Phó Cơ Điều P3 - TPVL', '', 'data/images/banner/logo.png', 'tbl_', 'tbl_', '2012-06-30 10:00:00', '0000-00-00 00:00:00', '2012-12-26 00:28:02', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

CREATE TABLE IF NOT EXISTS `tbl_category` (
  `id` int(25) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `picture` binary(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=34 ;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`id`, `name`, `picture`) VALUES
(3, 'Mực', NULL),
(8, 'Cá biển', NULL),
(11, 'BIA', NULL),
(12, 'Cá sông', NULL),
(13, 'Lẩu', NULL),
(15, 'Nghêu - sò ', NULL),
(16, 'Bò', NULL),
(17, 'Xào', NULL),
(18, 'Rượu', NULL),
(19, 'Gỏi', NULL),
(20, 'Cơm', NULL),
(21, 'Tôm - hàu', NULL),
(22, 'Tự nhâp', NULL),
(23, 'NƯỚC GIẢI KHÁT', NULL),
(24, 'Khai Vị', NULL),
(25, 'Cua - Ghẹ', NULL),
(26, 'Gà', NULL),
(27, 'Se Sẻ', NULL),
(28, 'Nai', NULL),
(30, 'Thuốc Hút', NULL),
(31, 'Đậu nành rau', NULL),
(32, 'TRÁI CÂY', NULL),
(33, 'Khăn lạnh', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_collect_customer`
--

CREATE TABLE IF NOT EXISTS `tbl_collect_customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idcustomer` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_customer_collect_1` (`idcustomer`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_collect_general`
--

CREATE TABLE IF NOT EXISTS `tbl_collect_general` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_term` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_collect_1` (`id_term`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

--
-- Dumping data for table `tbl_collect_general`
--

INSERT INTO `tbl_collect_general` (`id`, `id_term`, `date`, `value`, `note`) VALUES
(5, 2, '2013-05-18', 10, 'd'),
(6, 3, '2013-12-04', 10000000, 'Bổ sung tiền quỹ');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_config`
--

CREATE TABLE IF NOT EXISTS `tbl_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `param` varchar(125) COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=10 ;

--
-- Dumping data for table `tbl_config`
--

INSERT INTO `tbl_config` (`id`, `param`, `value`) VALUES
(5, 'DISCOUNT', '0'),
(6, 'ROW_PER_PAGE', '12'),
(7, 'GUEST_VISIT', '9247'),
(8, 'EVERY_5_MINUTES', '2000'),
(9, 'CATEGORY_AUTO', '22');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_course`
--

CREATE TABLE IF NOT EXISTS `tbl_course` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idcategory` int(25) DEFAULT NULL,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `shortname` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `unit` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `price1` bigint(20) NOT NULL,
  `price2` bigint(20) NOT NULL,
  `price3` bigint(20) NOT NULL,
  `price4` bigint(20) NOT NULL,
  `picture` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `prepare` int(11) NOT NULL,
  `is_discount` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `foreign_field` (`idcategory`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=425 ;

--
-- Dumping data for table `tbl_course`
--

INSERT INTO `tbl_course` (`id`, `idcategory`, `name`, `shortname`, `unit`, `price1`, `price2`, `price3`, `price4`, `picture`, `prepare`, `is_discount`) VALUES
(107, 3, 'Mực hấp gừng', 'hấp gừng', 'Dĩa', 58000, 58000, 58000, 58000, '', 1, 0),
(108, 3, 'Mực chiên nước mắm', 'chiên nước mắm', 'Dĩa', 58000, 58000, 58000, 58000, '', 1, 0),
(111, 3, 'Mực Nướng Sa Tế', 'Mực Nướng Sa Tế', 'Kg', 58000, 58000, 58000, 58000, '', 1, 0),
(115, 11, 'SG special chai', 'SG chai xanh', 'Chai', 13000, 13000, 13000, 13000, '', 0, 0),
(116, 11, 'SG đỏ', 'SG đỏ', 'Chai', 10000, 10000, 10000, 10000, '', 0, 0),
(165, 18, 'Phú Lễ', 'Phú Lễ', 'Chai', 80000, 80000, 80000, 80000, '', 0, 0),
(167, 18, 'Volka Men', 'Volka Men', 'Chai', 80000, 80000, 80000, 80000, '', 0, 0),
(188, 11, 'Heneiken chai', 'Ken chai', 'Chai', 16000, 16000, 16000, 16000, '', 0, 0),
(189, 11, 'Heneiken lon', 'Ken lon', 'Lon', 18000, 18000, 18000, 18000, '', 0, 0),
(190, 11, 'Tiger nâu', 'Tiger nâu', 'Chai', 14000, 14000, 14000, 14000, '', 0, 0),
(191, 11, 'Tiger bạc', 'Tiger bạc', 'Chai', 15000, 15000, 15000, 15000, '', 0, 0),
(243, 22, 'gà ta quay', 'gà ta quay', 'Dĩa', 100000, 100000, 100000, 100000, '', 0, 0),
(244, 23, 'Lavie 500ml', 'Lavie 500ml', 'Chai', 10000, 10000, 10000, 10000, '', 1, 1),
(245, 23, 'Pepsi', 'Pepsi', 'Lon', 12000, 12000, 12000, 12000, '', 1, 1),
(246, 23, 'Sting', 'Sting', 'Lon', 12000, 12000, 12000, 12000, '', 1, 0),
(247, 22, 'khoai mon chien', '', 'Dĩa', 25000, 25000, 25000, 25000, '', 0, 0),
(248, 24, 'Cà Tím Nướng Mỡ Hành', 'cà tím nướng mỡ hành', 'Dĩa', 30000, 30000, 30000, 30000, '', 1, 0),
(249, 24, 'Khoai Môn Chiên Nước Mắm', 'Khoai môn chiên nước mắm', 'Dĩa', 38000, 38000, 38000, 38000, '', 1, 0),
(250, 24, 'Khoai Tây Chiên', 'Khoai tây chiên', 'Dĩa', 38000, 38000, 38000, 38000, '', 1, 0),
(251, 24, 'Đậu Hủ Non Chiên Giòn', 'Đậu hủ non chiên giòn', 'Dĩa', 48000, 48000, 48000, 48000, '', 1, 0),
(252, 24, 'Đậu Hủ Hấp Cải Thìa', 'Đậu hủ hấp cải thìa', 'Dĩa', 48000, 48000, 48000, 48000, '', 1, 0),
(253, 24, 'Chả Giò Hải Sản', 'Chả giò hải sản', 'Dĩa', 58000, 58000, 58000, 58000, '', 1, 0),
(254, 24, 'Tôm Sú Rang Muối Hồng Kông', 'Tôm sú rang muối hồng kông', 'Dĩa', 68000, 68000, 68000, 68000, '', 1, 0),
(255, 24, 'Tôm Lăn Bột', 'Tôm lăn bột', 'Dĩa', 68000, 68000, 68000, 68000, '', 1, 0),
(256, 24, 'Khô Mực Rang Tiêu', 'Khô mực rang tiêu', 'Dĩa', 58000, 58000, 58000, 58000, '', 1, 0),
(257, 24, 'Khô Mực Chiên Giòn', 'Khô mực chiên giòn', 'Dĩa', 58000, 58000, 58000, 58000, '', 1, 0),
(258, 24, 'Khô Mực Nướng', 'Khô mực nướng', 'Dĩa', 58000, 58000, 58000, 58000, '', 1, 0),
(259, 24, 'Rau Luộc + Trứng Hồng Đào', 'Rau luộc + trứng hồng đào', 'Dĩa', 38000, 38000, 38000, 38000, '', 1, 0),
(260, 24, 'Rau Muống Xào Tỏi', 'Rau muống xào tỏi', 'Dĩa', 38000, 38000, 38000, 38000, '', 1, 0),
(261, 24, 'Rau Luộc Kho Qụet', 'Rau luộc kho quẹt', 'Dĩa', 38000, 38000, 38000, 38000, '', 1, 0),
(262, 24, 'Cơm Cháy Kho Qụet', 'Cơm cháy kho quẹt ', 'Dĩa', 48000, 48000, 48000, 48000, '', 1, 0),
(263, 24, 'Salad Hải Sản', 'Salad hải sản', 'Dĩa', 58000, 58000, 58000, 58000, '', 1, 0),
(264, 24, 'Salad Dầu Giấm', 'Salad dầu giấm', 'Dĩa', 58000, 58000, 58000, 58000, '', 1, 0),
(265, 19, 'Gỏi Mực Thái', 'Gỏi mực thái', 'Dĩa', 58000, 58000, 58000, 58000, '', 1, 0),
(266, 19, 'Gỏi Dưa Leo Hải Sản', 'Gỏi dưa leo hải sản', 'Dĩa', 58000, 58000, 58000, 58000, '', 1, 0),
(267, 19, 'Gỏi Tôm Thái', 'Gỏi tôm thái', 'Dĩa', 58000, 58000, 58000, 58000, '', 1, 0),
(268, 17, 'Mì Xào Hải Sản', 'Mì xào hải sản', 'Dĩa', 58000, 58000, 58000, 58000, '', 1, 0),
(269, 17, 'Mì Xào Tôm', 'Mì xào tôm', 'Dĩa', 58000, 58000, 58000, 58000, '', 1, 0),
(270, 20, 'Cơm Chiên Hải Sản', 'Cơm Chiên Hải Sản', 'Dĩa', 58000, 58000, 58000, 58000, '', 1, 0),
(271, 20, 'Cơm Chiên Trứng', 'Cơm Chiên Trứng', 'Dĩa', 48000, 48000, 48000, 48000, '', 10, 0),
(272, 20, 'Cơm Xào Hải Sản', 'Cơm Xào Hải Sản', 'Dĩa', 58000, 58000, 58000, 58000, '', 10, 0),
(273, 8, 'Cá Bóng Mú Đen Ăn Sống Mù Tạt', 'Cá Bóng Mú Đen Ăn Sống Mù Tạt', 'Kg', 380000, 380000, 380000, 380000, '', 1, 0),
(274, 8, 'Cá Bóng Mú Đen Nướng Muối Ớt', 'Cá Bóng Mú Đen Nướng Muối Ớt', 'Kg', 380000, 380000, 380000, 380000, '', 1, 0),
(275, 8, 'Cá Bóng Mú Đen Nướng Sa Tế Cay', 'Cá Bóng Mú Đen Nướng Sa Tế Cay', 'Kg', 380000, 380000, 380000, 380000, '', 1, 0),
(276, 8, 'Cá Bóng Mú Đen Chưng Tương', 'Cá Bóng Mú Đen Chưng Tương', 'Kg', 380000, 380000, 380000, 380000, '', 1, 0),
(277, 8, 'Cá Bống Mú Đen Hấp Hồng kông', 'Cá Bống Mú Đen Hấp Hồng kông', 'Kg', 380000, 380000, 380000, 380000, '', 1, 0),
(278, 8, 'Cá Bống Mú Đen Hấp Tàu Xì', 'Cá Bống Mú Đen Hấp Tàu Xì', 'Kg', 380000, 380000, 380000, 380000, '', 1, 0),
(279, 8, 'Cá Bống Mú Đen Hấp Kỳ Lân', 'Cá Bống Mú Đen Hấp  Kỳ Lân', 'Kg', 380000, 380000, 380000, 380000, '', 1, 0),
(280, 8, 'Cá Bóng Mú Đen Nấu Lẩu', 'Cá Bóng Mú Đen Nấu Lẩu', 'Kg', 380000, 380000, 380000, 380000, '', 1, 0),
(281, 8, 'Cá  Tầm Ăn Sống Mù Tạt', 'Cá  Tầm Ăn Sống Mù Tạt', 'Kg', 350000, 350000, 350000, 350000, '', 1, 0),
(282, 8, 'Cá Tầm Nướng Muối Ớt ', 'Cá Tầm Nướng Muối Ớt ', 'Kg', 350000, 350000, 350000, 350000, '', 1, 0),
(283, 8, 'Cá Tầm Nướng Xa Tế Cay', 'Cá Tầm Nướng Xa Tế Cay', 'Kg', 350000, 350000, 350000, 350000, '', 1, 0),
(284, 8, 'Cá Tầm Chưng Tương', 'Cá Tầm Chưng Tương', 'Kg', 350000, 350000, 350000, 350000, '', 1, 0),
(285, 8, 'Cá Tầm Hấp Hồng Kông', 'Cá Tầm Hấp Hồng Kông', 'Kg', 350000, 350000, 350000, 350000, '', 1, 0),
(286, 8, 'Cá Tầm Hấp Kỳ Lân', 'Cá Tầm Hấp Kỳ Lân', 'Kg', 350000, 350000, 350000, 350000, '', 1, 0),
(287, 8, 'Cá Tầm Nấu Lẩu', 'Cá Tầm Nấu Lẩu', 'Kg', 350000, 350000, 350000, 350000, '', 1, 0),
(288, 12, 'Cá Chạch Quế Chiên Nước Mắm', 'Cá Chạch Quế Chiên Nước Mắm', 'Kg', 380000, 380000, 380000, 380000, '', 1, 0),
(289, 12, 'Cá Chạch Quế Chiên Giòn', 'Cá Chạch Quế Chiên Giòn', 'Kg', 380000, 380000, 380000, 380000, '', 1, 0),
(290, 12, 'Cá Chạch Quế Nướng Muối Ớt', 'Cá Chạch Quế Nướng Muối Ớt', 'Kg', 380000, 380000, 380000, 380000, '', 1, 0),
(292, 12, 'Cá Chạch Quế Nướng Xa Tế Cay', 'Cá Chạch Quế Nướng Xa Tế Cay', 'Kg', 380000, 380000, 380000, 380000, '', 1, 0),
(293, 12, 'Cá Chạch Quế Nướng Mọi', 'Cá Chạch Quế Nướng Mọi', 'Kg', 380000, 380000, 380000, 380000, '', 1, 0),
(295, 12, 'Cá Chạch Quế Nấu Lẩu', 'Cá Chạch Quế Nấu Lẩu', 'Kg', 380000, 380000, 380000, 380000, '', 1, 0),
(300, 12, 'Cá Chép Giòn Ăn Sống Mù Tạt', 'Cá Chép Giòn Ăn Sống Mù Tạt', 'Kg', 380000, 380000, 380000, 380000, '', 1, 0),
(301, 12, 'Cá Chép Giòn Nướng Muối Ớt', 'Cá Chép Giòn Nướng Muối Ớt', 'Kg', 380000, 380000, 380000, 380000, '', 1, 0),
(303, 12, 'Cá Chép Giòn Nướng xa Tế Cay', 'Cá Chép Giòn Nướng xa Tế Cay', 'Kg', 380000, 380000, 380000, 380000, '', 1, 0),
(304, 12, 'Cá Chép Giòn Chưng Tương', 'Cá Chép Giòn Chưng Tương', 'Kg', 380000, 380000, 380000, 380000, '', 1, 0),
(305, 12, 'Cá Chép Giòn Hấp Hồng Kông', 'Cá Chép Giòn Hấp Hồng Kông', 'Kg', 380000, 380000, 380000, 380000, '', 1, 0),
(306, 12, 'Cá Chép Giòn Hấp Kỳ Lân', 'Cá Chép Giòn Hấp Kỳ Lân', 'Kg', 380000, 380000, 380000, 380000, '', 1, 0),
(307, 12, 'Cá Chép Giòn Nấu Lẩu', 'Cá Chép Giòn Nấu Lẩu', 'Kg', 380000, 380000, 380000, 380000, '', 1, 0),
(308, 12, 'Cá Heo Nhỏ Ăn Sống Mù Tạt', 'CHNMT', 'Kg', 1, 1, 1, 1, '', 10, 0),
(309, 12, 'Cá Heo Nhỏ Nướng Muối Ớt', 'CHNNMO', 'Kg', 1, 1, 1, 1, '', 15, 0),
(310, 12, 'Cá Heo Nhỏ Nướng Sa Tế Cay', ' CHNNSTC', 'Kg', 1, 1, 1, 1, '', 15, 0),
(311, 12, 'Cá Heo Nhỏ Chưng Tương', 'CHNCT', 'Kg', 1, 1, 1, 1, '', 10, 0),
(312, 12, 'Cá Heo Nhỏ Hấp Hồng Kông-Hấp Tàu Xì', 'CHNHHK', 'Kg', 1, 1, 1, 1, '', 10, 0),
(313, 12, 'Cá Heo Nhỏ Hấp Kỳ Lân', 'CHNHKL', 'Kg', 1, 1, 1, 1, '', 10, 0),
(314, 12, 'Cá Heo Nhỏ Nấu Lẩu', 'CHNNL', 'Kg', 1, 1, 1, 1, '', 10, 0),
(315, 8, 'Cá Hồng Biển Ăn Sống Mù Tạt', 'Cá Hồng Biển Ăn Sống Mù Tạt', 'Kg', 280000, 280000, 280000, 280000, '', 1, 0),
(316, 8, 'Cá Hồng Biển Nướng Muối Ớt', 'Cá Hồng Biển Nướng Muối Ớt', 'Kg', 280000, 280000, 280000, 280000, '', 1, 0),
(317, 8, 'Cá Hồng Biển Nướng Sa Tế Cay', 'Cá Hồng Biển Nướng Sa Tế Cay', 'Kg', 280000, 280000, 280000, 280000, '', 1, 0),
(318, 8, 'Cá Hồng Biển Chưng Tương', 'Cá Hồng Biển Chưng Tương', 'Kg', 280000, 280000, 280000, 280000, '', 1, 0),
(319, 8, 'Cá Hồng Biển Hấp Hồng Kông', 'Cá Hồng Biển Hấp Hồng Kông', 'Kg', 280000, 280000, 280000, 280000, '', 1, 0),
(320, 8, 'Cá Hồng Biển Hấp Kỳ Lân', 'Cá Hồng Biển Hấp Kỳ Lân', 'Kg', 280000, 280000, 280000, 280000, '', 1, 0),
(321, 8, 'Cá Hồng Biển Nấu Lẩu', 'Cá Hồng Biển Nấu Lẩu', 'Kg', 280000, 280000, 280000, 280000, '', 1, 0),
(322, 8, 'Cá Bốp Nướng Muối Ớt', 'Cá Bốp Nướng Muối Ớt', 'Kg', 188000, 188000, 188000, 188000, '', 1, 0),
(323, 8, 'Cá Bốp Nướng Sa Tế Cay', 'Cá Bốp Nướng Sa Tế Cay', 'Kg', 188000, 188000, 188000, 188000, '', 1, 0),
(324, 8, 'Cá Bốp Lúc Lắc', 'Cá Bốp Lúc Lắc', 'Kg', 188000, 188000, 188000, 188000, '', 1, 0),
(325, 8, 'Cá Bốp Chưng Tương ', 'Cá Bốp Chưng Tương ', 'Kg', 188000, 188000, 188000, 188000, '', 1, 0),
(326, 8, 'Cá Bốp Nấu Lẩu', 'Cá Bốp Nấu Lẩu', 'Kg', 188000, 188000, 188000, 188000, '', 1, 0),
(327, 8, 'Cá Cam Nướng Sa Tế Cay', 'Cá Cam Nướng Sa Tế Cay', 'Kg', 108000, 108000, 108000, 108000, '', 1, 0),
(328, 8, 'Cá Cam Nướng Muối Ớt', 'Cá Cam Nướng Muối Ớt', 'Kg', 108000, 108000, 108000, 108000, '', 1, 0),
(329, 8, 'Cá Cam Hấp Hành', 'Cá Cam Hấp Hành', 'Kg', 108000, 108000, 108000, 108000, '', 1, 0),
(330, 8, 'Cá Sapa Nướng Muối Ớt', 'Cá Sapa Nướng Muối Ớt', 'Kg', 108000, 108000, 108000, 108000, '', 1, 0),
(331, 8, 'Cá Sapa Nướng Sa Tế Cay', 'Cá Sapa Nướng Sa Tế Cay', 'Kg', 108000, 108000, 108000, 108000, '', 1, 0),
(332, 8, 'Cá Bò Da Nướng Muối Ớt', 'Cá Bò Da Nướng Muối Ớt', 'Kg', 158000, 158000, 158000, 158000, '', 1, 0),
(333, 8, 'Cá Bò Da Nướng Sa Tế Cay', 'Cá Bò Da Nướng Sa Tế Cay', 'Kg', 158000, 158000, 158000, 158000, '', 1, 0),
(334, 21, 'Tôm Lóng Ăn Sống Mù Tạt', 'Tôm Lóng Ăn Sống Mù Tạt', 'Kg', 290000, 290000, 290000, 290000, '', 1, 0),
(335, 21, 'Tôm Lóng Nướng Muối Ớt', 'Tôm Lóng Nướng Muối Ớt', 'Kg', 290000, 290000, 290000, 290000, '', 15, 0),
(336, 21, 'Tôm Lóng Nướng Sa Tế Cay', 'Tôm Lóng Nướng Sa Tế Cay', 'Kg', 290000, 290000, 290000, 290000, '', 1, 0),
(337, 21, 'Tôm Lóng Hấp Bia', 'Tôm Lóng Hấp Bia', 'Kg', 290000, 290000, 290000, 290000, '', 1, 0),
(339, 21, 'Tôm Sú Nướng Muối Ớt', 'Tôm Sú Nướng Muối Ớt', 'Kg', 280000, 280000, 280000, 280000, '', 1, 0),
(340, 21, 'Tôm Sú Nướng Sa Tế  Cay', 'Tôm Sú Nướng Sa Tế  Cay', 'Kg', 280000, 280000, 280000, 280000, '', 1, 0),
(341, 25, 'Cua Rang Muối', 'Cua Rang Muối', 'Kg', 280000, 280000, 280000, 280000, '', 1, 0),
(342, 25, 'Cua Hấp Bia ', 'Cua Hấp Bia ', 'Kg', 280000, 280000, 280000, 280000, '', 1, 0),
(343, 25, 'Cua Hấp Nước Dừa', 'Cua Hấp Nước Dừa', 'Kg', 280000, 280000, 280000, 280000, '', 1, 0),
(344, 25, 'Cua Luộc', 'Cua Luộc', 'Kg', 280000, 280000, 280000, 280000, '', 1, 0),
(345, 25, 'Cua Nấu Lẩu', 'Cua Nấu Lẩu', 'Kg', 280000, 280000, 280000, 280000, '', 1, 0),
(346, 25, 'Ghẹ Rang Muối', 'Ghẹ Rang Muối', 'Kg', 380000, 380000, 380000, 380000, '', 1, 0),
(347, 25, 'Ghẹ Hấp Bia', 'Ghẹ Hấp Bia', 'Kg', 380000, 380000, 380000, 380000, '', 1, 0),
(348, 25, 'Ghẹ Hấp Nước Dừa', 'Ghẹ Hấp Nước Dừa', 'Kg', 380000, 380000, 380000, 380000, '', 1, 0),
(349, 25, 'Ghẹ Luộc', 'Ghẹ Luộc', 'Kg', 380000, 380000, 380000, 380000, '', 1, 0),
(350, 25, 'Ghẹ Nấu Lẩu', 'Ghẹ Nấu Lẩu', 'Kg', 380000, 380000, 380000, 380000, '', 1, 0),
(351, 15, 'Sò Huyết Rang Muối', 'Sò Huyết Rang Muối', 'Kg', 180000, 180000, 180000, 180000, '', 1, 0),
(352, 15, 'Sò Huyết Rang Muối Hồng Kông', 'Sò Huyết Rang Muối Hồng Kông', 'Kg', 180000, 180000, 180000, 180000, '', 1, 0),
(353, 15, 'Sò Huyết Rang Me ', 'Sò Huyết Rang Me ', 'Kg', 180000, 180000, 180000, 180000, '', 1, 0),
(354, 15, 'Sò Huyết Cháy Tỏi', 'Sò Huyết Cháy Tỏi', 'Kg', 180000, 180000, 180000, 180000, '', 1, 0),
(355, 15, 'Sò Huyết Lacost', 'Sò Huyết Lacost', 'Kg', 180000, 180000, 180000, 180000, '', 1, 0),
(356, 15, 'Sò Huyết Tứ Xuyên', 'Sò Huyết Tứ Xuyên', 'Kg', 180000, 180000, 180000, 180000, '', 1, 0),
(357, 15, 'Sò Huyết Xào Rau Râm', 'Sò Huyết Xào Rau Râm', 'Kg', 180000, 180000, 180000, 180000, '', 1, 0),
(358, 15, 'Sò Huyết Nướng Mọi', 'Sò Huyết Nướng Mọi', 'Kg', 180000, 180000, 180000, 180000, '', 1, 0),
(359, 15, 'Nghêu Hấp Gừng', 'Nghêu Hấp Gừng', 'Kg', 118000, 118000, 118000, 118000, '', 1, 0),
(360, 15, 'Nghêu Hấp Thái', 'Nghêu Hấp Thái', 'Kg', 118000, 118000, 118000, 118000, '', 1, 0),
(361, 21, 'Hàu Sữa Nướng Mỡ Hành', 'Hàu Sữa Nướng Mỡ Hành', 'Con', 18000, 18000, 18000, 18000, '', 1, 0),
(362, 21, 'Hàu Sữa Đút Lò', 'Hàu Sữa Đút Lò', 'Con', 18000, 18000, 18000, 18000, '', 1, 0),
(363, 21, 'Hàu Sữa Nướng Phô Mai', 'Hàu Sữa Nướng Phô Mai', 'Con', 18000, 18000, 18000, 18000, '', 1, 0),
(364, 21, 'Hàu Sữa Nướng Trứng Cúc', 'Hàu Sữa Nướng Trứng Cúc', 'Con', 18000, 18000, 18000, 18000, '', 1, 0),
(365, 26, 'Gà Hấp Bia', 'Gà Hấp Bia', 'Dĩa', 118000, 118000, 118000, 118000, '', 1, 0),
(366, 26, 'Gà Hấp Cải Thìa', 'Gà Hấp Cải Thìa', 'Dĩa', 118000, 118000, 118000, 118000, '', 1, 0),
(367, 26, 'Gà Nướng Muối Ớt', 'Gà Nướng Muối Ớt', 'Dĩa', 118000, 118000, 118000, 118000, '', 1, 0),
(368, 26, 'Cánh Gà Chiên Nước Mắm', 'Cánh Gà Chiên Nước Mắm', 'Dĩa', 58000, 58000, 58000, 58000, '', 1, 0),
(369, 26, 'Chân Gà Chiên Nước Mắm', 'Chân Gà Chiên Nước Mắm', 'Dĩa', 58000, 58000, 58000, 58000, '', 1, 0),
(370, 13, 'Lẩu Gà Chanh ỚT', 'Lẩu Gà Chanh ỚT', 'Cái', 148000, 148000, 148000, 148000, '', 1, 0),
(371, 13, 'Lẩu Gà Lá Giang', 'Lẩu Gà Lá Giang', 'Cái', 148000, 148000, 148000, 148000, '', 1, 0),
(372, 16, 'Bò Lúc Lắc + Khoai Tây', 'Bò Lúc Lắc + Khoai Tây', 'Dĩa', 68000, 68000, 68000, 68000, '', 1, 0),
(373, 16, 'Bò Xào Chua Ngọt', 'Bò Xào Chua Ngọt', 'Dĩa', 58000, 58000, 58000, 58000, '', 1, 0),
(374, 16, 'Bò Xào Củ Hành', 'Bò Xào Củ Hành', 'Dĩa', 58000, 58000, 58000, 58000, '', 1, 0),
(375, 16, 'Bò Xào Khổ Qua', 'Bò Xào Khổ Qua', 'Dĩa', 58000, 58000, 58000, 58000, '', 1, 0),
(376, 16, 'Bò Tái Chanh', 'Bò Tái Chanh', 'Dĩa', 58000, 58000, 58000, 58000, '', 1, 0),
(377, 16, 'Bò Nướng Muối Ớt', 'Bò Nướng Muối Ớt', 'Dĩa', 58000, 58000, 58000, 58000, '', 1, 0),
(378, 16, 'Bò Nướng Sa Tế', 'Bò Nướng Sa Tế', 'Dĩa', 58000, 58000, 58000, 58000, '', 1, 0),
(379, 16, 'Bò Né', 'Bò Né', 'Dĩa', 88000, 88000, 88000, 88000, '', 1, 0),
(380, 16, 'Bò Bốp Thấu', 'Bò Bốp Thấu', 'Dĩa', 58000, 58000, 58000, 58000, '', 1, 0),
(381, 3, 'Mực Nướng Muối Ớt', 'Mực Nướng Muối Ớt', 'Kg', 58000, 58000, 58000, 58000, '', 1, 0),
(382, 3, 'Mực Chiên Giòn', 'Mực Chiên Giòn', 'Kg', 58000, 58000, 58000, 58000, '', 1, 0),
(383, 17, 'Mì xào giòn', 'Mì xào giòn', 'Dĩa', 58000, 58000, 58000, 58000, '', 1, 0),
(384, 27, 'Se Sẻ Nướng Muối Ớt', 'Se Sẻ Nướng Muối Ớt', 'Dĩa', 58000, 58000, 58000, 58000, '', 1, 0),
(385, 27, 'Se Sẻ Rôti', 'rôti', 'Dĩa', 58000, 58000, 58000, 58000, '', 1, 0),
(386, 27, 'Se Sẻ Nướng Sa Tế', 'Nướng Sa tế', 'Dĩa', 58000, 58000, 58000, 58000, '', 1, 0),
(387, 8, 'Cá Tầm Hấp Tàu Xì', 'Cá Tầm Hấp Tàu Xì', 'Kg', 350000, 350000, 350000, 350000, '', 1, 0),
(388, 8, 'Cá Hồng Biển Hấp Tàu Xì', 'Cá Hồng Biển Hấp Tàu Xì', 'Kg', 280000, 280000, 280000, 280000, '', 1, 0),
(389, 8, 'Cá Đuối Nướng Muối Ớt', 'Cá Đuối Nướng Muối Ớt', 'Kg', 350000, 350000, 350000, 350000, '', 1, 0),
(390, 8, 'Cá Đuối Nướng Xa tế Cay', 'Cá Đuối Nướng Xa tế Cay', 'Kg', 350000, 350000, 350000, 350000, '', 1, 0),
(391, 8, 'Cá Đuối Hấp Hành', 'Cá Đuối Hấp Hành', 'Kg', 350000, 350000, 350000, 350000, '', 1, 0),
(392, 8, 'Cá Đuối Nấu Lẩu', 'Cá Đuối Nấu Lẩu', 'Kg', 350000, 350000, 350000, 350000, '', 1, 0),
(393, 12, 'Cá chép Giòn Hấp Tàu Xì', 'Cá chép Giòn Hấp Tàu Xì', 'Kg', 380000, 380000, 380000, 380000, '', 1, 0),
(394, 21, 'Tôm Lóng Hấp Nước Dừa', 'Tôm Lóng Hấp Nước Dừa', 'Kg', 290000, 290000, 290000, 290000, '', 1, 0),
(395, 21, 'Tôm Sú Hấp Bia', 'Tôm Sú Hấp Bia', 'Kg', 280000, 280000, 280000, 280000, '', 1, 0),
(396, 21, 'Tôm Sú Hấp Nước Dừa', 'Tôm Sú Hấp Nước Dừa', 'Kg', 280000, 280000, 280000, 280000, '', 1, 0),
(398, 21, 'Hàu Sữa Nướng Mọi', 'Hàu Sữa Nướng Mọi', 'Con', 18000, 18000, 18000, 18000, '', 1, 0),
(399, 26, 'Lẩu Gà Chanh Ớt', 'Lẩu Gà Chanh Ớt', 'Cái', 148000, 148000, 148000, 148000, '', 1, 0),
(400, 26, 'Lẩu Gà Lá Giang', 'Lẩu Gà Lá Giang', 'Cái', 148000, 148000, 148000, 148000, '', 1, 0),
(401, 28, 'Nai Nướng Ngũ Vị', 'Nai Nướng Ngũ Vị', 'Dĩa', 58000, 58000, 58000, 58000, '', 1, 0),
(402, 28, 'Nai Xào Sa tế', 'Nai Xào Sa tế', 'Dĩa', 58000, 58000, 58000, 58000, '', 1, 0),
(404, 28, 'Nai Né', 'Nai Né', 'Cái', 88000, 88000, 88000, 88000, '', 1, 0),
(405, 11, 'Sagota', 'Sagota', 'Chai', 14000, 14000, 14000, 14000, '', 0, 0),
(406, 23, 'Trà C2', 'Trà C2', 'Chai', 10000, 10000, 10000, 10000, '', 0, 0),
(407, 18, ' Bồ Đào Đá', ' Bồ Đào Đá', 'Chai', 108000, 108000, 108000, 108000, '', 0, 0),
(408, 30, 'Thuốc Mèo', 'Thuốc Mèo', 'Gói', 22000, 22000, 22000, 22000, '', 0, 0),
(409, 30, 'Thuốc 555', 'Thuốc 555', 'Cái', 30000, 30000, 30000, 30000, '', 0, 0),
(410, 30, 'Quẹt gas', 'Quẹt gas', 'Cái', 5000, 5000, 5000, 5000, '', 0, 0),
(411, 11, 'Sagota Vàng', 'Sagota Vàng', 'Chai', 11000, 11000, 11000, 11000, '', 0, 0),
(412, 31, 'Đậu nành rau', 'Đậu nành rau', 'Bịch', 20000, 20000, 20000, 20000, '', 0, 0),
(414, 8, 'Cá  Quế Nướng Sa Tế', 'Cá  Quế Nướng Sa Tế', 'Kg', 380000, 380000, 380000, 380000, '', 1, 0),
(415, 8, 'Cá  Quế Nướng Muối Ớt Cay', 'Cá  Quế Nướng Muối Ớt Cay', 'Kg', 380000, 380000, 380000, 380000, '', 1, 0),
(416, 8, 'Cá  Quế Nấu Lẩu', 'Cá  Quế Nấu Lẩu', 'Kg', 380000, 380000, 380000, 380000, '', 1, 0),
(417, 22, 'Karaoke', '', 'Bịch', 460000, 460000, 460000, 460000, '', 0, 0),
(418, 22, 'Kho quẹt thêm', 'Kho quẹt thêm', 'Cái', 30000, 30000, 30000, 30000, '', 1, 0),
(419, 22, 'Mì khô', 'Mì khô', 'Dĩa', 15, 15, 15, 15, '', 1, 0),
(420, 32, 'Trái cây', 'Trái cây', 'Dĩa', 38000, 38000, 38000, 38000, '', 1, 0),
(421, 13, 'Lẩu Hải sản', 'Lẩu Hải sản', 'Cái', 130000, 130000, 130000, 130000, '', 1, 0),
(422, 13, 'Mì Gói', 'Mì Gói', 'Gói', 5000, 5000, 5000, 5000, '', 1, 0),
(423, 22, 'Mì khô', '', 'Dĩa', 15000, 15000, 15000, 15000, '', 0, 0),
(424, 33, 'Khăn lạnh', 'Khăn lạnh', 'Cái', 2000, 2000, 2000, 2000, '', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_course_log`
--

CREATE TABLE IF NOT EXISTS `tbl_course_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_table` int(11) NOT NULL,
  `id_course` int(11) NOT NULL,
  `date_time` datetime NOT NULL,
  `count` int(11) NOT NULL,
  `state` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=128 ;

--
-- Dumping data for table `tbl_course_log`
--

INSERT INTO `tbl_course_log` (`id`, `id_table`, `id_course`, `date_time`, `count`, `state`) VALUES
(7, 1, 333, '2013-12-25 18:51:26', 1, 2),
(8, 1, 333, '2013-12-25 18:51:28', 1, 2),
(9, 1, 276, '2013-12-25 18:51:31', 1, 2),
(10, 1, 279, '2013-12-25 18:51:37', 1, 2),
(11, 1, 380, '2013-12-27 17:53:06', 1, 2),
(12, 1, 372, '2013-12-27 17:53:07', 1, 2),
(13, 1, 289, '2013-12-27 17:55:45', 1, 1),
(14, 26, 379, '2013-12-27 17:56:54', 1, 1),
(15, 26, 372, '2013-12-27 17:56:56', 1, 1),
(16, 26, 380, '2013-12-27 17:57:00', 1, 1),
(17, 1, 370, '2013-12-27 22:59:19', 1, 1),
(18, 1, 371, '2013-12-27 22:59:26', 1, 1),
(19, 2, 370, '2013-12-27 23:10:18', 1, 1),
(20, 2, 371, '2013-12-27 23:10:22', 1, 1),
(21, 1, 268, '2013-12-27 23:13:39', 1, 1),
(22, 1, 268, '2013-12-27 23:14:13', 1, 1),
(23, 2, 371, '2013-12-28 01:51:17', 1, 1),
(24, 2, 372, '2013-12-28 01:51:19', 1, 1),
(25, 14, 377, '2013-12-28 02:40:54', 1, 1),
(26, 14, 377, '2013-12-28 02:40:54', 1, 1),
(27, 14, 377, '2013-12-28 02:40:54', 1, 1),
(28, 14, 379, '2013-12-28 02:41:17', 1, 1),
(29, 2, 273, '2013-12-28 07:35:29', 1, 1),
(30, 2, 389, '2013-12-28 07:35:38', 1, 1),
(31, 2, 261, '2013-12-28 07:35:44', 1, 1),
(32, 2, 260, '2013-12-28 07:35:49', 1, 1),
(33, 14, 354, '2013-12-28 11:40:32', 1, 1),
(34, 14, 354, '2013-12-28 11:40:36', 1, 1),
(35, 14, 277, '2013-12-28 11:41:08', 1, 1),
(36, 14, 270, '2013-12-28 11:41:29', 1, 1),
(37, 14, 270, '2013-12-28 11:41:31', 1, 1),
(38, 14, 246, '2013-12-28 11:45:08', 1, 1),
(39, 31, 248, '2013-12-28 11:59:37', 1, 1),
(40, 31, 328, '2013-12-28 12:00:12', 1, 1),
(41, 31, 268, '2013-12-28 12:00:23', 1, 1),
(42, 31, 353, '2013-12-28 12:02:05', 1, 1),
(43, 31, 289, '2013-12-28 12:02:24', 1, 1),
(44, 30, 330, '2013-12-28 12:28:18', 1, 1),
(45, 30, 334, '2013-12-28 12:36:09', 1, 1),
(46, 16, 354, '2013-12-28 12:44:52', 1, 1),
(47, 16, 354, '2013-12-28 12:44:55', 1, 1),
(48, 16, 277, '2013-12-28 12:45:05', 1, 1),
(49, 16, 270, '2013-12-28 12:45:15', 1, 1),
(50, 16, 270, '2013-12-28 12:45:17', 1, 1),
(51, 16, 415, '2013-12-28 12:55:52', 1, 1),
(52, 16, 391, '2013-12-28 12:57:16', 1, 1),
(53, 16, 334, '2013-12-28 12:57:56', 1, 1),
(54, 16, 246, '2013-12-28 13:00:16', 1, 1),
(55, 30, 368, '2013-12-28 13:02:51', 1, 1),
(56, 30, 349, '2013-12-28 13:03:05', 1, 1),
(57, 31, 415, '2013-12-28 13:05:43', 1, 1),
(58, 14, 368, '2013-12-28 14:38:09', 1, 1),
(59, 14, 361, '2013-12-28 14:38:22', 1, 1),
(60, 14, 262, '2013-12-28 14:44:04', 1, 1),
(61, 1, 270, '2013-12-28 14:50:47', 1, 1),
(62, 28, 330, '2013-12-28 14:55:37', 1, 1),
(63, 14, 248, '2013-12-28 15:00:10', 1, 1),
(64, 1, 351, '2013-12-28 15:09:35', 1, 1),
(65, 28, 351, '2013-12-28 15:10:01', 1, 1),
(66, 14, 353, '2013-12-28 16:08:01', 1, 1),
(67, 15, 295, '2013-12-28 17:45:59', 1, 1),
(68, 15, 359, '2013-12-28 17:46:44', 1, 1),
(69, 16, 381, '2013-12-28 17:47:31', 1, 1),
(70, 16, 373, '2013-12-28 17:47:41', 1, 1),
(71, 14, 290, '2013-12-28 18:02:10', 1, 1),
(72, 15, 290, '2013-12-28 18:07:41', 1, 1),
(73, 15, 322, '2013-12-28 18:12:27', 1, 1),
(74, 45, 381, '2013-12-28 18:27:18', 1, 1),
(75, 45, 349, '2013-12-28 18:32:09', 1, 1),
(76, 14, 363, '2013-12-28 18:32:29', 1, 1),
(77, 45, 363, '2013-12-28 18:33:26', 1, 1),
(78, 15, 420, '2013-12-28 18:39:59', 1, 1),
(79, 31, 421, '2013-12-28 18:53:27', 1, 1),
(80, 31, 422, '2013-12-28 18:53:32', 1, 1),
(81, 31, 368, '2013-12-28 18:54:36', 1, 1),
(82, 31, 381, '2013-12-28 18:54:53', 1, 1),
(83, 14, 372, '2013-12-28 19:07:20', 1, 1),
(84, 33, 382, '2013-12-28 19:10:30', 1, 1),
(85, 31, 245, '2013-12-28 19:17:16', 1, 1),
(86, 45, 251, '2013-12-28 19:33:41', 1, 1),
(87, 33, 351, '2013-12-28 19:46:40', 1, 1),
(88, 15, 424, '2013-12-28 19:55:17', 1, 1),
(89, 15, 422, '2013-12-28 19:55:57', 1, 1),
(90, 32, 392, '2013-12-28 20:02:33', 1, 1),
(91, 32, 389, '2013-12-28 20:02:37', 1, 1),
(92, 32, 363, '2013-12-28 20:02:50', 1, 1),
(93, 32, 351, '2013-12-28 20:03:38', 1, 1),
(94, 14, 347, '2013-12-28 20:10:39', 1, 1),
(95, 14, 268, '2013-12-28 20:11:16', 1, 1),
(96, 14, 368, '2013-12-28 20:11:23', 1, 1),
(97, 33, 254, '2013-12-28 20:22:47', 1, 1),
(98, 33, 245, '2013-12-28 20:23:01', 1, 1),
(99, 33, 345, '2013-12-28 20:23:44', 1, 1),
(100, 33, 422, '2013-12-28 20:24:05', 1, 1),
(101, 33, 422, '2013-12-28 20:24:23', 1, 1),
(102, 32, 245, '2013-12-28 20:38:54', 1, 1),
(103, 32, 415, '2013-12-28 20:39:12', 1, 1),
(104, 32, 244, '2013-12-28 20:42:55', 1, 1),
(105, 32, 422, '2013-12-28 20:48:11', 1, 1),
(106, 32, 335, '2013-12-28 20:48:40', 1, 1),
(107, 32, 389, '2013-12-28 20:58:07', 1, 1),
(108, 32, 392, '2013-12-28 20:58:10', 1, 1),
(109, 32, 363, '2013-12-28 20:58:37', 1, 1),
(110, 32, 351, '2013-12-28 20:59:48', 1, 1),
(111, 32, 245, '2013-12-28 21:00:14', 1, 1),
(112, 32, 290, '2013-12-28 21:01:02', 1, 1),
(113, 32, 422, '2013-12-28 21:02:20', 1, 1),
(114, 32, 244, '2013-12-28 21:03:25', 1, 1),
(115, 32, 244, '2013-12-28 21:03:27', 1, 1),
(116, 32, 335, '2013-12-28 21:03:48', 1, 1),
(117, 16, 385, '2013-12-28 22:06:08', 1, 1),
(118, 1, 385, '2013-12-28 22:08:33', 1, 1),
(119, 1, 270, '2013-12-28 22:10:24', 1, 1),
(120, 1, 368, '2013-12-28 22:10:39', 1, 1),
(121, 1, 246, '2013-12-28 22:29:49', 1, 0),
(122, 16, 385, '2013-12-28 22:34:48', 1, 0),
(123, 16, 270, '2013-12-28 22:37:36', 1, 0),
(124, 16, 368, '2013-12-28 22:37:47', 1, 0),
(125, 16, 246, '2013-12-28 22:37:55', 1, 0),
(126, 14, 349, '2013-12-28 22:39:23', 1, 0),
(127, 14, 351, '2013-12-28 23:18:49', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_customer`
--

CREATE TABLE IF NOT EXISTS `tbl_customer` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  `card` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `discount` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=15 ;

--
-- Dumping data for table `tbl_customer`
--

INSERT INTO `tbl_customer` (`id`, `name`, `type`, `card`, `phone`, `address`, `note`, `discount`) VALUES
(1, 'KHÁCH LẺ', 0, '1', '', '', '', 0),
(12, 'Khách VIP1', 1, 'vip1', '0919 111 222', 'Vĩnh Long', '', 5),
(13, 'Khách VIP2', 1, 'vip2', '0949 959997', 'Đồng Tháp', '', 10),
(14, 'Phạm minh tuấn anh', 0, '4', '', '', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_domain`
--

CREATE TABLE IF NOT EXISTS `tbl_domain` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Dumping data for table `tbl_domain`
--

INSERT INTO `tbl_domain` (`id`, `name`) VALUES
(1, 'KHU PHÒNG LẠNH'),
(2, 'KHU CHÒI'),
(3, 'KHU NGOÀI TRỜI'),
(4, 'KHU HỘI TRƯỜNG');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_employee`
--

CREATE TABLE IF NOT EXISTS `tbl_employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `job` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `gender` tinyint(2) NOT NULL,
  `phone` varchar(13) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `salary_base` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

--
-- Dumping data for table `tbl_employee`
--

INSERT INTO `tbl_employee` (`id`, `name`, `job`, `gender`, `phone`, `address`, `salary_base`) VALUES
(1, 'Thiện', 'Phục vụ', 0, '01867206889', '', 1500000),
(2, 'Hữu Thiện', 'Phục vụ', 0, '', 'Châu Thành, Đồng Tháp', 3000000),
(3, 'Định', 'Phục vụ', 0, '01863611643', '', 0),
(4, 'Hà Xuân', 'Phục vụ', 1, '', 'Châu Thành, Đồng Tháp', 0),
(5, 'Cường Anh', 'Phục vụ', 0, '', '', 0),
(6, 'Hải', 'nv', 0, '', '', 1000000);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_guest`
--

CREATE TABLE IF NOT EXISTS `tbl_guest` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(16) CHARACTER SET latin1 NOT NULL,
  `entry_time` varchar(32) CHARACTER SET latin1 NOT NULL,
  `exit_time` varchar(32) CHARACTER SET latin1 NOT NULL,
  `agent` varchar(16) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=150 ;

--
-- Dumping data for table `tbl_guest`
--

INSERT INTO `tbl_guest` (`id`, `ip`, `entry_time`, `exit_time`, `agent`) VALUES
(149, '115.78.94.118', '1383319305', '1383322905', '115.78.94.118');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_notify`
--

CREATE TABLE IF NOT EXISTS `tbl_notify` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  `message` varchar(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order_import`
--

CREATE TABLE IF NOT EXISTS `tbl_order_import` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idsupplier` int(11) NOT NULL,
  `date` date NOT NULL,
  `description` varchar(50) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_order_import_1` (`idsupplier`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=350 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order_import_detail`
--

CREATE TABLE IF NOT EXISTS `tbl_order_import_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idorder` int(11) NOT NULL,
  `idresource` int(11) NOT NULL,
  `count` float NOT NULL,
  `price` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_order_import_detail_1` (`idorder`),
  KEY `tbl_order_import_detail_2` (`idresource`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=636 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_paid_customer`
--

CREATE TABLE IF NOT EXISTS `tbl_paid_customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idcustomer` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_customer_paid_1` (`idcustomer`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=19 ;

--
-- Dumping data for table `tbl_paid_customer`
--

INSERT INTO `tbl_paid_customer` (`id`, `idcustomer`, `date`, `value`, `note`) VALUES
(18, 1, '2013-05-16', 1, '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_paid_employee`
--

CREATE TABLE IF NOT EXISTS `tbl_paid_employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_employee` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(150) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_employee` (`id_employee`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `tbl_paid_employee`
--

INSERT INTO `tbl_paid_employee` (`id`, `id_employee`, `date`, `value`, `note`) VALUES
(1, 1, '2013-10-05', 100000, 'Ứng đợt 2'),
(2, 1, '2013-10-01', 200000, 'Ứng đợt 1');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_paid_general`
--

CREATE TABLE IF NOT EXISTS `tbl_paid_general` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_term` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_paid_1` (`id_term`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=167 ;

--
-- Dumping data for table `tbl_paid_general`
--

INSERT INTO `tbl_paid_general` (`id`, `id_term`, `date`, `value`, `note`) VALUES
(9, 10, '2013-04-01', 157000, 'Chi tiền chợ'),
(10, 10, '2013-04-02', 146000, 'Tiền chợ'),
(11, 10, '2013-04-03', 189000, 'Tiền chợ'),
(12, 10, '2013-04-04', 184000, 'Tiền chợ'),
(20, 11, '2013-04-06', 163000, 'Chi mua đồ điện '),
(21, 11, '2013-12-04', 250000, 'Mua CB'),
(22, 11, '2013-04-07', 57000, 'Trái cây cúng+bao kiếng trái cây'),
(66, 2, '2013-04-30', 2100000, 'Tạm tính'),
(111, 3, '2013-07-31', 1500000, 'Thuế TTĐB Tháng 07'),
(112, 1, '2013-07-31', 4000000, 'Tiền điện T07'),
(113, 2, '2013-07-31', 2000000, 'Tiền nước T07'),
(155, 3, '2013-08-31', 800000, 'Thuế TTĐB T08'),
(156, 3, '2013-09-30', 850000, 'Thuế TTĐB T09'),
(158, 1, '2013-08-31', 5800000, 'Tiền điện T08'),
(159, 1, '2013-09-30', 3700000, 'Tiền điện T09'),
(160, 2, '2013-08-31', 2200000, 'Tiền nước T08'),
(161, 2, '2013-09-30', 2300000, 'Tiền nước T09'),
(163, 1, '2013-05-31', 4700000, 'Tiền điện T05'),
(164, 1, '2013-06-30', 3900000, 'Tiền điện T06'),
(165, 2, '2013-05-31', 2350000, 'Tiền nước T05'),
(166, 2, '2013-06-30', 2260000, 'Tiền nước T06');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_paid_pay_roll`
--

CREATE TABLE IF NOT EXISTS `tbl_paid_pay_roll` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_employee` int(11) NOT NULL,
  `date` date NOT NULL,
  `value_base` int(11) NOT NULL,
  `value_sub` int(11) NOT NULL,
  `value_pre` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_paid_pay_roll_1` (`id_employee`),
  KEY `id_employee` (`id_employee`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_paid_supplier`
--

CREATE TABLE IF NOT EXISTS `tbl_paid_supplier` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idsupplier` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_supplier_paid_1` (`idsupplier`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=18 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_pay_roll`
--

CREATE TABLE IF NOT EXISTS `tbl_pay_roll` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_employee` int(11) NOT NULL,
  `date` date NOT NULL,
  `state` int(11) NOT NULL,
  `extra` int(11) NOT NULL,
  `late` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_employee` (`id_employee`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=63 ;

--
-- Dumping data for table `tbl_pay_roll`
--

INSERT INTO `tbl_pay_roll` (`id`, `id_employee`, `date`, `state`, `extra`, `late`) VALUES
(1, 1, '2013-10-01', 1, 0, 0),
(2, 1, '2013-10-02', 1, 0, 0),
(3, 1, '2013-10-03', 1, 0, 0),
(4, 1, '2013-10-04', 1, 0, 0),
(5, 1, '2013-10-05', 1, 0, 0),
(6, 1, '2013-10-06', 1, 0, 0),
(7, 1, '2013-10-07', 1, 0, 0),
(8, 1, '2013-10-08', 1, 0, 0),
(9, 1, '2013-10-09', 1, 0, 0),
(10, 1, '2013-10-10', 1, 0, 0),
(11, 1, '2013-10-11', 1, 0, 0),
(12, 1, '2013-10-12', 1, 0, 0),
(13, 1, '2013-10-13', 1, 0, 0),
(14, 1, '2013-10-14', 1, 0, 0),
(15, 1, '2013-10-31', 1, 0, 0),
(16, 1, '2013-10-30', 1, 0, 0),
(17, 1, '2013-10-15', 1, 0, 0),
(18, 1, '2013-10-16', 1, 0, 0),
(19, 1, '2013-10-17', 1, 0, 0),
(20, 1, '2013-10-18', 1, 0, 0),
(21, 1, '2013-10-19', 1, 0, 0),
(22, 1, '2013-10-25', 1, 0, 0),
(23, 1, '2013-10-27', 1, 0, 0),
(24, 1, '2013-10-24', 1, 0, 0),
(25, 1, '2013-10-21', 1, 0, 0),
(26, 1, '2013-10-20', 1, 0, 0),
(27, 1, '2013-10-23', 1, 0, 0),
(28, 1, '2013-10-22', 1, 0, 0),
(29, 1, '2013-10-26', 1, 0, 0),
(30, 1, '2013-10-28', 1, 0, 0),
(31, 1, '2013-10-29', 1, 0, 0),
(32, 2, '2013-10-01', 1, 0, 0),
(33, 2, '2013-10-02', 1, 0, 0),
(34, 2, '2013-10-03', 1, 0, 0),
(35, 2, '2013-10-04', 1, 0, 0),
(36, 2, '2013-10-05', 1, 0, 0),
(37, 2, '2013-10-06', 1, 0, 0),
(38, 2, '2013-10-07', 1, 0, 0),
(39, 2, '2013-10-08', 1, 0, 0),
(40, 2, '2013-10-09', 1, 0, 0),
(41, 2, '2013-10-10', 1, 0, 0),
(42, 2, '2013-10-11', 1, 0, 0),
(43, 2, '2013-10-12', 1, 0, 0),
(44, 2, '2013-10-13', 1, 0, 0),
(45, 2, '2013-10-14', 1, 0, 0),
(46, 2, '2013-10-15', 1, 0, 0),
(47, 2, '2013-10-16', 1, 0, 0),
(48, 2, '2013-10-17', 1, 0, 0),
(49, 2, '2013-10-18', 1, 0, 0),
(50, 2, '2013-10-19', 1, 0, 0),
(51, 2, '2013-10-20', 1, 0, 0),
(52, 2, '2013-10-21', 1, 0, 0),
(53, 2, '2013-10-22', 1, 0, 0),
(54, 2, '2013-10-23', 1, 0, 0),
(55, 2, '2013-10-24', 1, 0, 0),
(56, 2, '2013-10-25', 1, 0, 0),
(57, 2, '2013-10-26', 1, 0, 0),
(58, 2, '2013-10-27', 1, 0, 0),
(59, 2, '2013-10-28', 1, 0, 0),
(60, 2, '2013-10-29', 1, 0, 0),
(61, 2, '2013-10-30', 1, 0, 0),
(62, 2, '2013-10-31', 1, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_r2c`
--

CREATE TABLE IF NOT EXISTS `tbl_r2c` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_course` int(11) NOT NULL,
  `id_resource` int(11) NOT NULL,
  `value1` double NOT NULL,
  `value2` double NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_r2c_1` (`id_course`),
  KEY `tbl_r2c_2` (`id_resource`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=160 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_resource`
--

CREATE TABLE IF NOT EXISTS `tbl_resource` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `idsupplier` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `unit` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `price` int(10) NOT NULL,
  `description` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_resource_1` (`idsupplier`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=105 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_session`
--

CREATE TABLE IF NOT EXISTS `tbl_session` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idtable` int(11) NOT NULL,
  `iduser` int(11) NOT NULL,
  `idcustomer` int(11) NOT NULL,
  `idemployee` int(11) NOT NULL,
  `datetime` datetime NOT NULL,
  `datetimeend` datetime DEFAULT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  `discount_value` int(11) NOT NULL,
  `discount_percent` int(11) NOT NULL,
  `surtax` int(11) NOT NULL,
  `payment` int(11) NOT NULL,
  `value` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idtable` (`idtable`),
  KEY `iduser` (`iduser`),
  KEY `tbl_session_3` (`idcustomer`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=50 ;

--
-- Dumping data for table `tbl_session`
--

INSERT INTO `tbl_session` (`id`, `idtable`, `iduser`, `idcustomer`, `idemployee`, `datetime`, `datetimeend`, `note`, `status`, `discount_value`, `discount_percent`, `surtax`, `payment`, `value`) VALUES
(29, 26, 1, 1, 1, '2013-12-27 17:56:54', '2013-12-27 17:56:54', '', 1, 0, 0, 0, 0, 0),
(34, 31, 1, 1, 3, '2013-12-28 11:59:37', '2013-12-28 11:59:37', '', 1, 0, 0, 0, 0, 0),
(35, 30, 1, 1, 5, '2013-12-28 12:28:18', '2013-12-28 12:28:18', '', 1, 0, 0, 0, 0, 0),
(36, 16, 1, 1, 4, '2013-12-28 12:44:52', '2013-12-28 12:44:52', '', 1, 0, 0, 0, 0, 0),
(37, 14, 1, 1, 1, '2013-12-28 14:38:09', '2013-12-28 14:38:09', '', 1, 0, 0, 0, 0, 0),
(39, 28, 1, 1, 4, '2013-12-28 14:55:37', '2013-12-28 14:55:37', '', 1, 0, 0, 0, 0, 0),
(40, 15, 1, 1, 6, '2013-12-28 17:45:58', '2013-12-28 17:45:58', '', 1, 0, 0, 0, 0, 0),
(41, 14, 1, 14, 1, '2013-12-28 17:47:31', '2013-12-28 17:47:31', '', 1, 0, 0, 0, 0, 0),
(42, 45, 1, 1, 1, '2013-12-28 18:27:18', '2013-12-28 18:27:18', '', 1, 0, 0, 0, 0, 0),
(43, 31, 1, 1, 1, '2013-12-28 18:53:27', '2013-12-28 18:53:27', '', 1, 0, 0, 0, 0, 0),
(44, 33, 1, 1, 1, '2013-12-28 19:10:30', '2013-12-28 19:10:30', '', 1, 0, 10, 0, 0, 0),
(46, 32, 1, 1, 1, '2013-12-28 20:58:07', '2013-12-28 20:58:07', '', 1, 0, 0, 0, 0, 0),
(47, 16, 1, 1, 3, '2013-12-28 22:06:07', '2013-12-28 22:06:07', '', 1, 0, 0, 0, 0, 0),
(49, 14, 1, 1, 1, '2013-12-28 22:39:23', '2013-12-28 22:39:23', '', 1, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_session_detail`
--

CREATE TABLE IF NOT EXISTS `tbl_session_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idsession` int(11) NOT NULL,
  `idcourse` int(11) NOT NULL,
  `count` float NOT NULL,
  `price` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idsession` (`idsession`),
  KEY `idcourse` (`idcourse`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=227 ;

--
-- Dumping data for table `tbl_session_detail`
--

INSERT INTO `tbl_session_detail` (`id`, `idsession`, `idcourse`, `count`, `price`) VALUES
(90, 29, 379, 1, 1),
(91, 29, 372, 1, 1),
(92, 29, 380, 1, 1),
(111, 34, 248, 1, 30000),
(112, 34, 328, 0.55, 108000),
(113, 34, 268, 1, 58000),
(114, 34, 353, 1, 180000),
(115, 34, 289, 0.4, 380000),
(116, 35, 330, 0.55, 108000),
(118, 36, 354, 0.7, 180000),
(119, 36, 277, 1, 380000),
(120, 36, 270, 2, 58000),
(121, 36, 415, 0.65, 380000),
(122, 36, 391, 1.05, 350000),
(123, 36, 334, 0.5, 290000),
(124, 36, 405, 23, 14000),
(125, 36, 115, 34, 13000),
(126, 36, 246, 1, 12000),
(127, 36, 412, 2, 20000),
(128, 35, 368, 1, 58000),
(129, 35, 349, 0.5, 380000),
(130, 35, 405, 15, 14000),
(131, 34, 415, 0.75, 380000),
(132, 34, 408, 1, 22000),
(133, 34, 410, 1, 5000),
(134, 34, 405, 24, 14000),
(135, 34, 412, 1, 20000),
(136, 37, 368, 2, 58000),
(137, 37, 361, 5, 18000),
(139, 37, 262, 1, 78000),
(141, 39, 330, 0.8, 108000),
(142, 39, 405, 33, 14000),
(143, 37, 248, 1, 30000),
(144, 37, 412, 1, 20000),
(145, 37, 405, 3, 14000),
(146, 37, 411, 36, 11000),
(148, 39, 351, 0.35, 180000),
(149, 37, 353, 0.35, 180000),
(150, 39, 411, 1, 11000),
(151, 39, 412, 1, 20000),
(152, 40, 295, 0.5, 380000),
(153, 40, 359, 0.5, 118000),
(154, 41, 381, 0.5, 216000),
(155, 41, 373, 1, 58000),
(156, 41, 405, 42, 14000),
(157, 41, 290, 0.5, 380000),
(158, 40, 405, 11, 14000),
(159, 40, 290, 0.5, 380000),
(160, 40, 322, 1, 188000),
(161, 42, 381, 0.5, 216000),
(162, 42, 349, 0.5, 380000),
(164, 42, 363, 4, 18000),
(165, 42, 188, 5, 16000),
(166, 40, 420, 1, 38000),
(167, 43, 421, 1, 130000),
(168, 43, 422, 2, 5000),
(169, 43, 368, 1, 58000),
(170, 43, 381, 0.5, 216000),
(171, 43, 405, 3, 14000),
(172, 41, 372, 1, 68000),
(173, 44, 382, 1, 58000),
(174, 43, 245, 1, 12000),
(175, 42, 251, 1, 48000),
(176, 42, 405, 1, 14000),
(177, 42, 411, 1, 11000),
(178, 44, 351, 0.35, 180000),
(179, 41, 411, 2, 11000),
(180, 40, 424, 4, 2000),
(181, 40, 422, 6, 5000),
(182, 40, 411, 5, 11000),
(187, 41, 408, 1, 22000),
(188, 41, 347, 1.1, 380000),
(189, 41, 268, 1, 58000),
(190, 41, 368, 2, 58000),
(192, 44, 245, 2, 12000),
(193, 44, 345, 1.1, 280000),
(194, 44, 422, 2, 5000),
(202, 46, 389, 0.5, 350000),
(203, 46, 392, 0.5, 350000),
(204, 46, 363, 4, 18000),
(205, 46, 351, 0.35, 180000),
(206, 46, 408, 1, 22000),
(207, 46, 245, 4, 12000),
(208, 46, 290, 0.45, 380000),
(209, 46, 165, 2, 80000),
(210, 46, 422, 1, 5000),
(211, 46, 244, 4, 10000),
(212, 46, 335, 0.5, 290000),
(219, 47, 385, 1, 58000),
(220, 47, 270, 1, 58000),
(221, 47, 368, 1, 58000),
(222, 47, 246, 1, 12000),
(223, 47, 115, 2, 13000),
(226, 49, 351, 0.7, 180000);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_store`
--

CREATE TABLE IF NOT EXISTS `tbl_store` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(125) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_store`
--

INSERT INTO `tbl_store` (`id`, `name`, `note`) VALUES
(1, 'Kho nhà', 'Ghi chú gì đây ?');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_supplier`
--

CREATE TABLE IF NOT EXISTS `tbl_supplier` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `debt` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=28 ;

--
-- Dumping data for table `tbl_supplier`
--

INSERT INTO `tbl_supplier` (`id`, `name`, `phone`, `address`, `note`, `debt`) VALUES
(13, 'Cá sống-cua ghẹ', '', 'Can Tho', '', 0),
(14, 'Nước Đá', '', '', '', 0),
(15, 'Nghêu sò', '', '', '', 0),
(16, 'Rau quả', '', '', '', 0),
(17, 'Gia vị', '', '', '', 0),
(18, 'Gia cầm', '', '', '', 0),
(19, 'Hàng đông lạnh', '', '', '', 0),
(20, 'Gas...', '', '', '', 0),
(21, 'Bia..', '', '', '', 0),
(22, 'Nước ngọt', '', '', '', 0),
(23, 'Rượu ngoại', '', '', '', 0),
(24, 'Rượu nội', '', '', '', 0),
(25, 'Vật dụng bếp', '', '', '', 0),
(26, 'Vật dụng tổ bàn', '', '', '', 0),
(27, 'khăn giấy-tăm tre', '', '', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_table`
--

CREATE TABLE IF NOT EXISTS `tbl_table` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iddomain` int(11) NOT NULL,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `iduser` int(11) DEFAULT NULL,
  `type` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `iddomain` (`iddomain`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=46 ;

--
-- Dumping data for table `tbl_table`
--

INSERT INTO `tbl_table` (`id`, `iddomain`, `name`, `iduser`, `type`) VALUES
(1, 1, 'P. 01', 1, '0'),
(2, 1, 'P. 02', 1, '0'),
(14, 2, 'C. 07', 1, '0'),
(15, 2, 'C. 08', 1, '0'),
(16, 2, 'C. 09', 1, '0'),
(26, 3, 'B. 18', 1, '0'),
(27, 3, 'B. 19', 1, '0'),
(28, 3, 'B. 20', 1, '0'),
(29, 3, 'B. 21', 1, '0'),
(30, 3, 'B. 22', 1, '0'),
(31, 3, 'B. 23', 1, '0'),
(32, 3, 'B. 24', 1, '0'),
(33, 3, 'B. 25', 1, '0'),
(34, 4, 'HT. 10', 1, '0'),
(35, 4, 'HT. 11', 1, '0'),
(36, 4, 'HT. 12', 1, '0'),
(37, 4, 'HT. 13', 1, '0'),
(38, 4, 'HT. 14', 1, '0'),
(39, 4, 'HT. 15', 1, '0'),
(40, 4, 'HT. 16', 1, '0'),
(41, 4, 'HT. 17', 1, '0'),
(44, 1, 'P. 03', 1, '0'),
(45, 2, 'C10', 1, '0');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_term`
--

CREATE TABLE IF NOT EXISTS `tbl_term` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=13 ;

--
-- Dumping data for table `tbl_term`
--

INSERT INTO `tbl_term` (`id`, `name`, `type`) VALUES
(1, 'Tiền Điện', 0),
(2, 'Tiền Nước', 0),
(3, 'Thuế', 0),
(10, 'Tiền Ăn Nhân Viên', 0),
(11, 'CP Khác', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_term_collect`
--

CREATE TABLE IF NOT EXISTS `tbl_term_collect` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `tbl_term_collect`
--

INSERT INTO `tbl_term_collect` (`id`, `name`) VALUES
(2, 'Phụ Phẩm'),
(3, 'Đặc Biệt');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tracking`
--

CREATE TABLE IF NOT EXISTS `tbl_tracking` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_start` date NOT NULL,
  `date_end` date NOT NULL,
  `paid_general` int(11) NOT NULL,
  `paid_pay_roll` int(11) NOT NULL,
  `paid_import` int(11) NOT NULL,
  `collect_general` int(11) NOT NULL,
  `collect_customer` int(11) NOT NULL,
  `collect_selling_debt` int(11) NOT NULL,
  `collect_selling_nodebt` int(11) NOT NULL,
  `estate_rate` int(11) NOT NULL,
  `store_value` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=15 ;

--
-- Dumping data for table `tbl_tracking`
--

INSERT INTO `tbl_tracking` (`id`, `date_start`, `date_end`, `paid_general`, `paid_pay_roll`, `paid_import`, `collect_general`, `collect_customer`, `collect_selling_debt`, `collect_selling_nodebt`, `estate_rate`, `store_value`) VALUES
(10, '2013-10-01', '2013-10-31', 0, 0, 0, 0, 0, 0, 0, 0, 0),
(11, '2013-11-01', '2013-11-30', 0, 0, 0, 0, 0, 0, 0, 0, 0),
(12, '2013-12-01', '2013-12-31', 0, 0, 0, 0, 0, 0, 0, 0, 0),
(13, '2014-01-01', '2014-01-31', 0, 0, 0, 0, 0, 0, 0, 0, 0),
(14, '2014-02-01', '2014-02-28', 0, 0, 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tracking_course`
--

CREATE TABLE IF NOT EXISTS `tbl_tracking_course` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tracking` int(11) NOT NULL,
  `id_td` int(11) NOT NULL,
  `id_course` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `value` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=209 ;

--
-- Dumping data for table `tbl_tracking_course`
--

INSERT INTO `tbl_tracking_course` (`id`, `id_tracking`, `id_td`, `id_course`, `count`, `price`, `value`) VALUES
(197, 12, 67, 187, 40, 0, 0),
(198, 12, 67, 55, 5, 0, 0),
(199, 12, 67, 243, 1, 0, 0),
(200, 12, 67, 188, 1, 0, 0),
(201, 12, 67, 227, 6, 0, 0),
(202, 12, 67, 161, 2, 0, 0),
(203, 12, 67, 111, 1, 0, 0),
(204, 12, 67, 15, 1, 0, 0),
(205, 12, 66, 187, 4, 0, 0),
(206, 12, 66, 165, 1, 0, 0),
(207, 12, 66, 240, 1, 0, 0),
(208, 12, 66, 238, 2, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tracking_customer`
--

CREATE TABLE IF NOT EXISTS `tbl_tracking_customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tracking` int(11) NOT NULL,
  `id_customer` int(11) NOT NULL,
  `value_session1` int(11) NOT NULL,
  `value_session2` int(11) NOT NULL,
  `value_collect` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tracking_daily`
--

CREATE TABLE IF NOT EXISTS `tbl_tracking_daily` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tracking` int(11) NOT NULL,
  `date` date NOT NULL,
  `selling` bigint(20) NOT NULL,
  `import` bigint(20) NOT NULL,
  `store` bigint(20) NOT NULL,
  `paid` bigint(20) NOT NULL,
  `collect` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=152 ;

--
-- Dumping data for table `tbl_tracking_daily`
--

INSERT INTO `tbl_tracking_daily` (`id`, `id_tracking`, `date`, `selling`, `import`, `store`, `paid`, `collect`) VALUES
(1, 10, '2013-10-01', 0, 0, 0, 0, 0),
(2, 10, '2013-10-02', 0, 0, 0, 0, 0),
(3, 10, '2013-10-03', 0, 0, 0, 0, 0),
(4, 10, '2013-10-04', 0, 0, 0, 0, 0),
(5, 10, '2013-10-05', 0, 0, 0, 0, 0),
(6, 10, '2013-10-06', 0, 0, 0, 0, 0),
(7, 10, '2013-10-07', 0, 0, 0, 0, 0),
(8, 10, '2013-10-08', 0, 0, 0, 0, 0),
(9, 10, '2013-10-09', 0, 0, 0, 0, 0),
(10, 10, '2013-10-10', 0, 0, 0, 0, 0),
(11, 10, '2013-10-11', 0, 0, 0, 0, 0),
(12, 10, '2013-10-12', 0, 0, 0, 0, 0),
(13, 10, '2013-10-13', 0, 0, 0, 0, 0),
(14, 10, '2013-10-14', 0, 0, 0, 0, 0),
(15, 10, '2013-10-15', 0, 0, 0, 0, 0),
(16, 10, '2013-10-16', 0, 0, 0, 0, 0),
(17, 10, '2013-10-17', 0, 0, 0, 0, 0),
(18, 10, '2013-10-18', 0, 0, 0, 0, 0),
(19, 10, '2013-10-19', 0, 0, 0, 0, 0),
(20, 10, '2013-10-20', 0, 0, 0, 0, 0),
(21, 10, '2013-10-21', 0, 0, 0, 0, 0),
(22, 10, '2013-10-22', 0, 0, 0, 0, 0),
(23, 10, '2013-10-23', 0, 0, 0, 0, 0),
(24, 10, '2013-10-24', 0, 0, 0, 0, 0),
(25, 10, '2013-10-25', 0, 0, 0, 0, 0),
(26, 10, '2013-10-26', 0, 0, 0, 0, 0),
(27, 10, '2013-10-27', 0, 0, 0, 0, 0),
(28, 10, '2013-10-28', 0, 0, 0, 0, 0),
(29, 10, '2013-10-29', 0, 0, 0, 0, 0),
(30, 10, '2013-10-30', 0, 0, 0, 0, 0),
(31, 10, '2013-10-31', 0, 0, 0, 0, 0),
(32, 11, '2013-11-01', 0, 0, 0, 0, 0),
(33, 11, '2013-11-02', 0, 0, 0, 0, 0),
(34, 11, '2013-11-03', 0, 0, 0, 0, 0),
(35, 11, '2013-11-04', 0, 0, 0, 0, 0),
(36, 11, '2013-11-05', 0, 0, 0, 0, 0),
(37, 11, '2013-11-06', 0, 0, 0, 0, 0),
(38, 11, '2013-11-07', 0, 0, 0, 0, 0),
(39, 11, '2013-11-08', 0, 0, 0, 0, 0),
(40, 11, '2013-11-09', 0, 0, 0, 0, 0),
(41, 11, '2013-11-10', 0, 0, 0, 0, 0),
(42, 11, '2013-11-11', 0, 0, 0, 0, 0),
(43, 11, '2013-11-12', 0, 0, 0, 0, 0),
(44, 11, '2013-11-13', 0, 0, 0, 0, 0),
(45, 11, '2013-11-14', 0, 0, 0, 0, 0),
(46, 11, '2013-11-15', 0, 0, 0, 0, 0),
(47, 11, '2013-11-16', 0, 0, 0, 0, 0),
(48, 11, '2013-11-17', 0, 0, 0, 0, 0),
(49, 11, '2013-11-18', 0, 0, 0, 0, 0),
(50, 11, '2013-11-19', 0, 0, 0, 0, 0),
(51, 11, '2013-11-20', 0, 0, 0, 0, 0),
(52, 11, '2013-11-21', 0, 0, 0, 0, 0),
(53, 11, '2013-11-22', 0, 0, 0, 0, 0),
(54, 11, '2013-11-23', 0, 0, 0, 0, 0),
(55, 11, '2013-11-24', 0, 0, 0, 0, 0),
(56, 11, '2013-11-25', 0, 0, 0, 0, 0),
(57, 11, '2013-11-26', 0, 0, 0, 0, 0),
(58, 11, '2013-11-27', 0, 0, 0, 0, 0),
(59, 11, '2013-11-28', 0, 0, 0, 0, 0),
(60, 11, '2013-11-29', 0, 0, 0, 0, 0),
(61, 11, '2013-11-30', 0, 0, 0, 0, 0),
(62, 12, '2013-12-01', 0, 0, 0, 0, 0),
(63, 12, '2013-12-02', 0, 0, 0, 0, 0),
(64, 12, '2013-12-03', 0, 0, 0, 0, 0),
(65, 12, '2013-12-04', 0, 0, 0, 250000, 10000000),
(66, 12, '2013-12-05', 58000, 0, 0, 0, 0),
(67, 12, '2013-12-06', 620000, 0, 0, 0, 0),
(68, 12, '2013-12-07', 0, 0, 0, 0, 0),
(69, 12, '2013-12-08', 0, 0, 0, 0, 0),
(70, 12, '2013-12-09', 0, 0, 0, 0, 0),
(71, 12, '2013-12-10', 0, 0, 0, 0, 0),
(72, 12, '2013-12-11', 0, 0, 0, 0, 0),
(73, 12, '2013-12-12', 0, 0, 0, 0, 0),
(74, 12, '2013-12-13', 0, 0, 0, 0, 0),
(75, 12, '2013-12-14', 0, 0, 0, 0, 0),
(76, 12, '2013-12-15', 0, 0, 0, 0, 0),
(77, 12, '2013-12-16', 0, 0, 0, 0, 0),
(78, 12, '2013-12-17', 0, 0, 0, 0, 0),
(79, 12, '2013-12-18', 0, 0, 0, 0, 0),
(80, 12, '2013-12-19', 0, 0, 0, 0, 0),
(81, 12, '2013-12-20', 0, 0, 0, 0, 0),
(82, 12, '2013-12-21', 0, 0, 0, 0, 0),
(83, 12, '2013-12-22', 0, 0, 0, 0, 0),
(84, 12, '2013-12-23', 0, 0, 0, 0, 0),
(85, 12, '2013-12-24', 0, 0, 0, 0, 0),
(86, 12, '2013-12-25', 0, 0, 0, 0, 0),
(87, 12, '2013-12-26', 0, 0, 0, 0, 0),
(88, 12, '2013-12-27', 0, 0, 0, 0, 0),
(89, 12, '2013-12-28', 0, 0, 0, 0, 0),
(90, 12, '2013-12-29', 0, 0, 0, 0, 0),
(91, 12, '2013-12-30', 0, 0, 0, 0, 0),
(92, 12, '2013-12-31', 0, 0, 0, 0, 0),
(93, 13, '2014-01-01', 0, 0, 0, 0, 0),
(94, 13, '2014-01-02', 0, 0, 0, 0, 0),
(95, 13, '2014-01-03', 0, 0, 0, 0, 0),
(96, 13, '2014-01-04', 0, 0, 0, 0, 0),
(97, 13, '2014-01-05', 0, 0, 0, 0, 0),
(98, 13, '2014-01-06', 0, 0, 0, 0, 0),
(99, 13, '2014-01-07', 0, 0, 0, 0, 0),
(100, 13, '2014-01-08', 0, 0, 0, 0, 0),
(101, 13, '2014-01-09', 0, 0, 0, 0, 0),
(102, 13, '2014-01-10', 0, 0, 0, 0, 0),
(103, 13, '2014-01-11', 0, 0, 0, 0, 0),
(104, 13, '2014-01-12', 0, 0, 0, 0, 0),
(105, 13, '2014-01-13', 0, 0, 0, 0, 0),
(106, 13, '2014-01-14', 0, 0, 0, 0, 0),
(107, 13, '2014-01-15', 0, 0, 0, 0, 0),
(108, 13, '2014-01-16', 0, 0, 0, 0, 0),
(109, 13, '2014-01-17', 0, 0, 0, 0, 0),
(110, 13, '2014-01-18', 0, 0, 0, 0, 0),
(111, 13, '2014-01-19', 0, 0, 0, 0, 0),
(112, 13, '2014-01-20', 0, 0, 0, 0, 0),
(113, 13, '2014-01-21', 0, 0, 0, 0, 0),
(114, 13, '2014-01-22', 0, 0, 0, 0, 0),
(115, 13, '2014-01-23', 0, 0, 0, 0, 0),
(116, 13, '2014-01-24', 0, 0, 0, 0, 0),
(117, 13, '2014-01-25', 0, 0, 0, 0, 0),
(118, 13, '2014-01-26', 0, 0, 0, 0, 0),
(119, 13, '2014-01-27', 0, 0, 0, 0, 0),
(120, 13, '2014-01-28', 0, 0, 0, 0, 0),
(121, 13, '2014-01-29', 0, 0, 0, 0, 0),
(122, 13, '2014-01-30', 0, 0, 0, 0, 0),
(123, 13, '2014-01-31', 0, 0, 0, 0, 0),
(124, 14, '2014-02-01', 0, 0, 0, 0, 0),
(125, 14, '2014-02-02', 0, 0, 0, 0, 0),
(126, 14, '2014-02-03', 0, 0, 0, 0, 0),
(127, 14, '2014-02-04', 0, 0, 0, 0, 0),
(128, 14, '2014-02-05', 0, 0, 0, 0, 0),
(129, 14, '2014-02-06', 0, 0, 0, 0, 0),
(130, 14, '2014-02-07', 0, 0, 0, 0, 0),
(131, 14, '2014-02-08', 0, 0, 0, 0, 0),
(132, 14, '2014-02-09', 0, 0, 0, 0, 0),
(133, 14, '2014-02-10', 0, 0, 0, 0, 0),
(134, 14, '2014-02-11', 0, 0, 0, 0, 0),
(135, 14, '2014-02-12', 0, 0, 0, 0, 0),
(136, 14, '2014-02-13', 0, 0, 0, 0, 0),
(137, 14, '2014-02-14', 0, 0, 0, 0, 0),
(138, 14, '2014-02-15', 0, 0, 0, 0, 0),
(139, 14, '2014-02-16', 0, 0, 0, 0, 0),
(140, 14, '2014-02-17', 0, 0, 0, 0, 0),
(141, 14, '2014-02-18', 0, 0, 0, 0, 0),
(142, 14, '2014-02-19', 0, 0, 0, 0, 0),
(143, 14, '2014-02-20', 0, 0, 0, 0, 0),
(144, 14, '2014-02-21', 0, 0, 0, 0, 0),
(145, 14, '2014-02-22', 0, 0, 0, 0, 0),
(146, 14, '2014-02-23', 0, 0, 0, 0, 0),
(147, 14, '2014-02-24', 0, 0, 0, 0, 0),
(148, 14, '2014-02-25', 0, 0, 0, 0, 0),
(149, 14, '2014-02-26', 0, 0, 0, 0, 0),
(150, 14, '2014-02-27', 0, 0, 0, 0, 0),
(151, 14, '2014-02-28', 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tracking_store`
--

CREATE TABLE IF NOT EXISTS `tbl_tracking_store` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tracking` int(11) NOT NULL,
  `id_td` int(11) NOT NULL,
  `id_resource` int(11) NOT NULL,
  `count_old` float NOT NULL,
  `count_import` float NOT NULL,
  `count_export` float NOT NULL,
  `price` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1875 ;

--
-- Dumping data for table `tbl_tracking_store`
--

INSERT INTO `tbl_tracking_store` (`id`, `id_tracking`, `id_td`, `id_resource`, `count_old`, `count_import`, `count_export`, `price`) VALUES
(1860, 11, 65, 19, 0, 1, 0.3, 150000);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_unit`
--

CREATE TABLE IF NOT EXISTS `tbl_unit` (
  `id` int(25) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=25 ;

--
-- Dumping data for table `tbl_unit`
--

INSERT INTO `tbl_unit` (`id`, `name`) VALUES
(1, 'Ly'),
(2, 'Điếu'),
(3, 'Chai'),
(4, 'Lon'),
(5, 'Dĩa'),
(6, 'Thùng'),
(7, 'Két'),
(9, 'Bịch'),
(10, 'Gói'),
(20, 'Trái'),
(21, 'Cái'),
(22, 'Hủ'),
(23, 'Kg'),
(24, 'Con');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE IF NOT EXISTS `tbl_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pass` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gender` int(11) NOT NULL,
  `note` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `datecreate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dateupdate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `dateactivity` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `type` tinyint(4) NOT NULL,
  `code` varchar(13) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=6 ;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `name`, `email`, `pass`, `gender`, `note`, `datecreate`, `dateupdate`, `dateactivity`, `type`, `code`) VALUES
(1, 'Tuấn', 'tuanbuithanh@gmail.com', 'admin068368', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 4, ''),
(3, 'Khoa', 'lekhoa.bdc@gmail.com', 'lenguyen0945030709...', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 4, ''),
(4, 'Mai', 'maiphan.bdc@gmail.com', 'admin123456', 1, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 4, '');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_collect_customer`
--
ALTER TABLE `tbl_collect_customer`
  ADD CONSTRAINT `tbl_customer_collect_1` FOREIGN KEY (`idcustomer`) REFERENCES `tbl_customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_collect_general`
--
ALTER TABLE `tbl_collect_general`
  ADD CONSTRAINT `tbl_collect_general_1` FOREIGN KEY (`id_term`) REFERENCES `tbl_term_collect` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_course`
--
ALTER TABLE `tbl_course`
  ADD CONSTRAINT `tbl_course_1` FOREIGN KEY (`idcategory`) REFERENCES `tbl_category` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_order_import`
--
ALTER TABLE `tbl_order_import`
  ADD CONSTRAINT `tbl_order_import_1` FOREIGN KEY (`idsupplier`) REFERENCES `tbl_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_order_import_detail`
--
ALTER TABLE `tbl_order_import_detail`
  ADD CONSTRAINT `tbl_order_import_detail_1` FOREIGN KEY (`idorder`) REFERENCES `tbl_order_import` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_order_import_detail_2` FOREIGN KEY (`idresource`) REFERENCES `tbl_resource` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_paid_customer`
--
ALTER TABLE `tbl_paid_customer`
  ADD CONSTRAINT `tbl_customer_paid_1` FOREIGN KEY (`idcustomer`) REFERENCES `tbl_customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_paid_employee`
--
ALTER TABLE `tbl_paid_employee`
  ADD CONSTRAINT `tbl_paid_employee_ibfk_1` FOREIGN KEY (`id_employee`) REFERENCES `tbl_employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_paid_general`
--
ALTER TABLE `tbl_paid_general`
  ADD CONSTRAINT `tbl_paid_general_1` FOREIGN KEY (`id_term`) REFERENCES `tbl_term` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_paid_pay_roll`
--
ALTER TABLE `tbl_paid_pay_roll`
  ADD CONSTRAINT `tbl_paid_pay_roll_ibfk_1` FOREIGN KEY (`id_employee`) REFERENCES `tbl_employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_paid_supplier`
--
ALTER TABLE `tbl_paid_supplier`
  ADD CONSTRAINT `tbl_supplier_paid_1` FOREIGN KEY (`idsupplier`) REFERENCES `tbl_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_pay_roll`
--
ALTER TABLE `tbl_pay_roll`
  ADD CONSTRAINT `tbl_pay_roll_ibfk_1` FOREIGN KEY (`id_employee`) REFERENCES `tbl_employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_r2c`
--
ALTER TABLE `tbl_r2c`
  ADD CONSTRAINT `tbl_r2c_1` FOREIGN KEY (`id_course`) REFERENCES `tbl_course` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_r2c_2` FOREIGN KEY (`id_resource`) REFERENCES `tbl_resource` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_resource`
--
ALTER TABLE `tbl_resource`
  ADD CONSTRAINT `tbl_resource_1` FOREIGN KEY (`idsupplier`) REFERENCES `tbl_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_session`
--
ALTER TABLE `tbl_session`
  ADD CONSTRAINT `tbl_session_1` FOREIGN KEY (`idtable`) REFERENCES `tbl_table` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_session_2` FOREIGN KEY (`iduser`) REFERENCES `tbl_user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_session_3` FOREIGN KEY (`idcustomer`) REFERENCES `tbl_customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_session_detail`
--
ALTER TABLE `tbl_session_detail`
  ADD CONSTRAINT `tbl_session_detail_1` FOREIGN KEY (`idsession`) REFERENCES `tbl_session` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_session_detail_2` FOREIGN KEY (`idcourse`) REFERENCES `tbl_course` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_table`
--
ALTER TABLE `tbl_table`
  ADD CONSTRAINT `tbl_table_1` FOREIGN KEY (`iddomain`) REFERENCES `tbl_domain` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
